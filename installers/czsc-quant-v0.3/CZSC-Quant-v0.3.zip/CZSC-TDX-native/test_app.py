"""Control-center helpers are testable without Windows or a graphical display."""
import json
from pathlib import Path
import tempfile
import unittest

from app import build_command, formula_for_slot, save_config, status_from_metadata, validate_config


class AppConfigurationTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.exe = self.root / "通达信程序.exe"
        self.exe.write_bytes(b"test fixture; validation does not load the executable")
        (self.root / "T0002").mkdir()
        self.source = self.root / "行情 & $(do-not-run) ; 'x'.csv"
        self.source.write_text("fixture", encoding="utf-8")
        self.config = {"tdx_exe": str(self.exe), "source": str(self.source), "output_dir": str(self.root / "输出 & 文件"), "market": "sz", "code": "000001", "period": "30m", "slot": "2"}

    def test_command_keeps_shell_metacharacters_in_single_argument(self):
        command = build_command(self.config, root=self.root, python="test-python")
        self.assertEqual(command[:3], ["test-python", str(self.root / "run_bridge.py"), "--watch"])
        self.assertEqual(command[command.index("--source") + 1], str(self.source))
        self.assertEqual(command[command.index("--output-dir") + 1], self.config["output_dir"])
        self.assertEqual(len(command), 13)
        self.assertNotIn("--slot", command)

    def test_invalid_fields_are_rejected(self):
        for key, value in (("slot", 0), ("slot", "10"), ("code", "1"), ("code", "000001;calc"), ("market", "us"), ("period", "1m"), ("source", "missing.csv"), ("tdx_exe", ""), ("output_dir", "")):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                validate_config({**self.config, key: value})

    def test_native_file_must_match_symbol_and_period(self):
        source = self.root / "sh600000.day"
        source.write_bytes(b"test")
        config = {**self.config, "source": str(source), "market": "sh", "code": "600000", "period": "daily"}
        self.assertEqual(validate_config(config)["period"], "daily")
        for patch in ({"code": "600001"}, {"market": "sz"}, {"period": "30m"}):
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                validate_config({**config, **patch})

    def test_executable_requires_t0002(self):
        (self.root / "T0002").rmdir()
        with self.assertRaisesRegex(ValueError, "T0002"):
            validate_config(self.config)

    def test_save_compatible_fields_and_exclude_unknown_fields(self):
        path = self.root / "runtime" / "windows-config.json"
        save_config({**self.config, "unknown": "ignored"}, path)
        self.assertEqual(json.loads(path.read_text(encoding="utf-8")), self.config)
        self.assertFalse(path.with_suffix(".json.tmp").exists())
        self.assertEqual(validate_config({key: value for key, value in self.config.items() if key != "slot"})["slot"], 1)


class FormulaTests(unittest.TestCase):
    def test_selected_slot_replaces_only_function_identifier(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            formulas = root / "formulas" / "utf8"
            formulas.mkdir(parents=True)
            (formulas / "CZSCMAIN.txt").write_text("A:TDXDLL1(1,C,0,0);B:TDXDLL1 (2,C,0,0);\n{TDXDLL10 unchanged}", encoding="utf-8-sig")
            actual = formula_for_slot("CZSCMAIN", 9, root)
            self.assertEqual(actual, "A:TDXDLL9(1,C,0,0);B:TDXDLL9 (2,C,0,0);\n{TDXDLL10 unchanged}")

    def test_reject_invalid_formula_and_slot_before_file_access(self):
        for name, slot in (("../private", 1), ("CZSCMAIN", 0), ("CZSCMAIN", "1);calc(")):
            with self.subTest(name=name, slot=slot), self.assertRaises(ValueError):
                formula_for_slot(name, slot)


class FreshnessTests(unittest.TestCase):
    def test_fresh_source_does_not_claim_quotes_are_collected_or_alarm_activated(self):
        state = status_from_metadata({"newest_bar_end_utc": 1000, "generated_at_utc": 1000}, now=1001)
        self.assertEqual(state["state"], "fresh")
        self.assertIn("需在通达信内启用", state["message"])
        self.assertIn("08:16:40（上海）", state["latest"])

    def test_stale_source_does_not_become_fresh_when_cache_rebuilt(self):
        state = status_from_metadata({"newest_bar_end_utc": 900, "generated_at_utc": 1000}, now=1000)
        self.assertEqual(state["state"], "stale")
        self.assertIn("历史数据可画，实时预警关闭", state["message"])

    def test_stopped_engine_cache_expires_even_if_source_was_recent(self):
        metadata = {"newest_bar_end_utc": 1000, "generated_at_utc": 1000}
        self.assertEqual(status_from_metadata(metadata, now=1015)["state"], "fresh")
        self.assertEqual(status_from_metadata(metadata, now=1016)["state"], "cache_stale")

    def test_future_or_missing_timestamps_cannot_enable_alarm(self):
        for metadata, expected in (({"newest_bar_end_utc": 1001, "generated_at_utc": 1000}, "future"), ({"newest_bar_end_utc": 1000, "generated_at_utc": 1001}, "future"), ({"newest_bar_end_utc": "nan", "generated_at_utc": 1000}, "unknown"), ({"newest_bar_end_utc": 1000}, "unknown"), ({}, "unknown")):
            with self.subTest(metadata=metadata):
                self.assertEqual(status_from_metadata(metadata, now=1000)["state"], expected)

    def test_engine_error_is_visible(self):
        state = status_from_metadata({"error": "missing file"}, now=1000)
        self.assertEqual(state["state"], "error")
        self.assertIn("missing file", state["message"])
        self.assertIn("实时预警关闭", state["message"])


if __name__ == "__main__":
    unittest.main()
