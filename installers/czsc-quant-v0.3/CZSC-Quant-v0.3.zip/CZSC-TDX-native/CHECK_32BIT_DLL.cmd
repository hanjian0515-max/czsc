@echo off
cd /d "%~dp0"
bin\x86\CZSCCheck.exe
echo.
pause
