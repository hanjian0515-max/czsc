"""Persistent CZSC paper/replay account.  This module never sends broker orders.

Signals are observed at a completed bar and may fill only at the next fresh
completed bar's close, with adverse slippage.  This is a delayed bar-close
simulation, not a promise of executable market prices or stop prices.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_FLOOR
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import time
from typing import Any


@dataclass(frozen=True)
class Config:
    market: str = "ashare"
    mode: str = "paper"
    capital: float = 1_000_000.0
    currency: str | None = None
    commission: float | None = None
    min_fee: float | None = None
    sell_tax: float | None = None
    slippage: float = 0.0005
    allocation_limit: float = 0.10
    trade_risk_limit: float = 0.0025
    portfolio_risk_limit: float = 0.01
    daily_loss_limit: float = 0.01
    max_bar_age: float = 90.0
    pending_ttl: float = 600.0
    quantity_step: float | None = None

    def __post_init__(self) -> None:
        if self.market not in {"ashare", "crypto"}:
            raise ValueError("market must be ashare or crypto")
        if self.mode not in {"paper", "replay"}:
            raise ValueError("mode must be paper or replay")
        defaults = ({"currency": "CNY", "commission": 0.0003,
                     "min_fee": 5.0, "sell_tax": 0.0005, "quantity_step": 100.0}
                    if self.market == "ashare" else
                    {"currency": "USD", "commission": 0.001,
                     "min_fee": 0.0, "sell_tax": 0.0, "quantity_step": 0.00001})
        for key, default in defaults.items():
            if getattr(self, key) is None:
                object.__setattr__(self, key, default)
        if self.currency != defaults["currency"]:
            raise ValueError("ashare requires CNY; crypto requires USD (not USDT)")
        for key in ("capital", "quantity_step", "max_bar_age", "pending_ttl"):
            _number(getattr(self, key), key, positive=True)
        for key in ("commission", "min_fee", "sell_tax", "slippage"):
            _number(getattr(self, key), key)
            if getattr(self, key) < 0:
                raise ValueError(f"{key} cannot be negative")
        for key in ("allocation_limit", "trade_risk_limit", "portfolio_risk_limit",
                    "daily_loss_limit"):
            value = _number(getattr(self, key), key, positive=True)
            if value > 1:
                raise ValueError(f"{key} must be at most 1")
        if self.slippage >= 1 or self.commission >= 1 or self.sell_tax >= 1:
            raise ValueError("slippage, commission and tax must be below 1")
        if self.market == "ashare" and self.quantity_step != 100:
            raise ValueError("this A-share simulator uses 100-share lots")


def _number(value: Any, name: str, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be a finite number")
    value = float(value)
    if not math.isfinite(value) or (positive and value <= 0):
        raise ValueError(f"{name} must be finite" + (" and positive" if positive else ""))
    return value


def _epoch(value: Any, name: str) -> int:
    number = _number(value, name, positive=True)
    if number != int(number):
        raise ValueError(f"{name} must be integer UTC epoch seconds")
    try:
        datetime.fromtimestamp(number, timezone.utc)
    except (OverflowError, OSError, ValueError) as exc:
        raise ValueError(f"{name} is outside the supported date range") from exc
    return int(number)


class QuantLedger:
    """A single-currency, long-only SQLite simulation account.

    Each ``process_bar`` is one atomic transaction.  A different market, mode or
    configuration needs a different database; reopening never silently resets
    an account.  A-share lots/fees are simulation assumptions, not full exchange
    eligibility rules. STAR board entries require at least 200 shares here.
    """

    def __init__(self, path: str | Path, config: Config | None = None):
        self.config = config or Config()
        if not isinstance(self.config, Config):
            raise TypeError("config must be Config")
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=10)
        self.db.row_factory = sqlite3.Row
        try:
            self.db.execute("PRAGMA journal_mode=WAL")
            self.db.execute("PRAGMA foreign_keys=ON")
            self.db.executescript("""
                CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS account (id INTEGER PRIMARY KEY CHECK(id=1), state TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS signals (
                    symbol TEXT NOT NULL, signal_id TEXT NOT NULL, action TEXT NOT NULL,
                    at INTEGER NOT NULL, status TEXT NOT NULL,
                    PRIMARY KEY(symbol, signal_id));
                CREATE TABLE IF NOT EXISTS orders (
                    order_id TEXT PRIMARY KEY, symbol TEXT NOT NULL, action TEXT NOT NULL,
                    status TEXT NOT NULL, updated_at REAL NOT NULL, details TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS executions (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, details TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT, details TEXT NOT NULL);
            """)
            self.db.execute("BEGIN IMMEDIATE")
            encoded = self._encode(asdict(self.config))
            row = self.db.execute("SELECT value FROM metadata WHERE key='config'").fetchone()
            if row and json.loads(row[0]) != json.loads(encoded):
                raise ValueError("database configuration differs; use a separate account database")
            if not row:
                self.db.execute("INSERT INTO metadata VALUES ('config', ?)", (encoded,))
                self.db.execute("INSERT INTO metadata VALUES ('schema', '1')")
                state = {"cash": float(self.config.capital), "positions": {}, "pending": {},
                         "deferred_exits": {}, "last_bars": {}, "marks": {}, "day": None,
                         "day_start_equity": float(self.config.capital), "daily_loss_locked": False,
                         "last_status": "new_account"}
                self.db.execute("INSERT INTO account VALUES (1, ?)", (self._encode(state),))
            self.db.execute("COMMIT")
        except Exception:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK")
            self.db.close()
            raise

    @staticmethod
    def _encode(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True)

    def close(self) -> None:
        self.db.close()

    def __enter__(self) -> "QuantLedger":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def _symbol(self, symbol: str) -> str:
        if not isinstance(symbol, str):
            raise ValueError("symbol must be a string")
        if self.config.market == "ashare":
            if not re.fullmatch(r"(?:sh(?:60|68)|sz(?:00|30))\d{4}", symbol):
                raise ValueError("A-share stock required: sh60xxxx/sh68xxxx/sz00xxxx/sz30xxxx; indices unsupported")
        elif not re.fullmatch(r"[A-Z0-9]{2,16}-USD", symbol):
            raise ValueError("crypto spot symbol must be BASE-USD, for example BTC-USD")
        return symbol

    def _validate_bar(self, bar: dict) -> dict:
        if not isinstance(bar, dict):
            raise ValueError("bar must be a dict")
        clean = {"end": _epoch(bar.get("end"), "bar.end")}
        for key in ("open", "high", "low", "close"):
            clean[key] = _number(bar.get(key), f"bar.{key}", positive=True)
        clean["volume"] = _number(bar.get("volume"), "bar.volume")
        if clean["volume"] < 0 or not (clean["low"] <= min(clean["open"], clean["close"])
                                       <= max(clean["open"], clean["close"]) <= clean["high"]):
            raise ValueError("bar has inconsistent OHLC or negative volume")
        return clean

    def _validate_signal(self, signal: dict | None) -> dict | None:
        if signal is None:
            return None
        if not isinstance(signal, dict):
            raise ValueError("signal must be a dict")
        signal_id = signal.get("id")
        if not isinstance(signal_id, str) or not signal_id.strip() or len(signal_id) > 256:
            raise ValueError("signal.id must be a nonempty string of at most 256 characters")
        action = signal.get("action")
        if action not in {"buy", "sell"}:
            raise ValueError("signal.action must be buy or sell")
        clean = {"id": signal_id, "action": action, "at": _epoch(signal.get("at"), "signal.at")}
        if action == "buy":
            clean["stop"] = _number(signal.get("stop"), "signal.stop", positive=True)
        return clean

    def _date(self, epoch: float) -> str:
        tz = timezone(timedelta(hours=8)) if self.config.market == "ashare" else timezone.utc
        return datetime.fromtimestamp(epoch, tz).date().isoformat()

    def _session(self, epoch: float) -> str | None:
        """Conservative stock sessions; exchange holiday calendars are not inferred."""
        if self.config.market == "crypto":
            return self._date(epoch)
        dt = datetime.fromtimestamp(epoch, timezone(timedelta(hours=8)))
        minutes = dt.hour * 60 + dt.minute
        if dt.weekday() >= 5:
            return None
        part = "am" if 570 <= minutes <= 690 else "pm" if 780 <= minutes <= 900 else None
        return f"{dt.date().isoformat()}:{part}" if part else None

    @staticmethod
    def _equity(state: dict) -> float:
        return state["cash"] + sum(p["qty"] * state["marks"].get(s, p["entry"])
                                   for s, p in state["positions"].items())

    def _lock_daily_loss(self, state: dict) -> None:
        start = state["day_start_equity"]
        if start > 0 and self._equity(state) <= start * (1 - self.config.daily_loss_limit):
            state["daily_loss_locked"] = True

    def _event(self, events: list, kind: str, symbol: str, **fields: Any) -> None:
        event = {"kind": kind, "symbol": symbol, **fields}
        events.append(event)
        self.db.execute("INSERT INTO events(details) VALUES (?)", (self._encode(event),))

    @staticmethod
    def _order_id(symbol: str, signal_id: str) -> str:
        return "signal:" + hashlib.sha256((symbol + "\0" + signal_id).encode()).hexdigest()

    def _order(self, order_id: str, symbol: str, action: str, status: str, now: float, **details: Any) -> None:
        self.db.execute("""INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(order_id) DO UPDATE SET status=excluded.status,
                updated_at=excluded.updated_at, details=excluded.details""",
                        (order_id, symbol, action, status, now, self._encode(details)))

    def _pending_done(self, state: dict, symbol: str, status: str, now: float,
                      events: list, **details: Any) -> dict | None:
        pending = state["pending"].pop(symbol, None)
        if pending:
            self._order(pending["order_id"], symbol, pending["action"], status, now, **details)
            self.db.execute("UPDATE signals SET status=? WHERE symbol=? AND signal_id=?",
                            (status, symbol, pending["id"]))
            self._event(events, status, symbol, signal_id=pending["id"], **details)
        return pending

    def _fee(self, notional: float) -> float:
        return max(self.config.min_fee, notional * self.config.commission)

    def _size(self, state: dict, entry: float, stop: float, symbol: str) -> tuple[float, float]:
        eq = self._equity(state)
        remaining = eq * self.config.portfolio_risk_limit - sum(
            p["planned_risk"] for p in state["positions"].values())
        budget = min(eq * self.config.trade_risk_limit, remaining)
        stop_price = stop * (1 - self.config.slippage)
        if budget <= 0 or stop_price >= entry:
            return 0.0, 0.0
        cap = min(float(self.config.capital), eq) * self.config.allocation_limit
        upper = min(cap / entry, state["cash"] / entry, budget / (entry - stop_price))
        step = Decimal(str(self.config.quantity_step))
        upper_units = int((Decimal(str(max(0.0, upper))) / step).to_integral_value(rounding=ROUND_FLOOR))
        existing_risk = sum(p["planned_risk"] for p in state["positions"].values())

        def allowed(units: int) -> tuple[bool, float]:
            qty = float(step * units)
            buy_fee = self._fee(qty * entry)
            risk = qty * (entry - stop_price) + buy_fee + self._fee(qty * stop_price)
            risk += qty * stop_price * self.config.sell_tax
            # Mark the acquired position at the observed close, not the slipped fill.
            projected_eq = eq - buy_fee - qty * (entry - entry / (1 + self.config.slippage))
            projected_cap = min(float(self.config.capital), projected_eq) * self.config.allocation_limit
            permitted = (qty * entry <= projected_cap + 1e-8
                         and qty * entry + buy_fee <= state["cash"] + 1e-8
                         and risk <= projected_eq * self.config.trade_risk_limit + 1e-8
                         and existing_risk + risk <= projected_eq * self.config.portfolio_risk_limit + 1e-8)
            return permitted, risk

        lo, hi = 0, upper_units
        while lo < hi:
            middle = (lo + hi + 1) // 2
            if allowed(middle)[0]:
                lo = middle
            else:
                hi = middle - 1
        qty = float(step * lo)
        if qty <= 0 or (self.config.market == "ashare" and symbol.startswith("sh68") and qty < 200):
            return 0.0, 0.0
        return qty, allowed(lo)[1]

    def _execution(self, executions: list, **fields: Any) -> None:
        fill = {"mode": self.config.mode, "paper_only": True, "pricing": "delayed_bar_close", **fields}
        cursor = self.db.execute("INSERT INTO executions(details) VALUES (?)", (self._encode(fill),))
        fill["seq"] = cursor.lastrowid
        executions.append(fill)

    def _sell(self, state: dict, symbol: str, bar: dict, now: float, order_id: str,
              reason: str, executions: list, events: list, signal_id: str | None = None) -> None:
        position = state["positions"][symbol]
        if self.config.market == "ashare" and self._date(bar["end"]) <= position["opened_day"]:
            if symbol not in state["deferred_exits"]:
                state["deferred_exits"][symbol] = {"order_id": order_id, "reason": reason,
                    "signal_id": signal_id, "at": bar["end"]}
                self._event(events, "deferred_t1", symbol, reason=reason, at=bar["end"])
            self._order(order_id, symbol, "sell", "deferred_t1", now, reason=reason)
            if signal_id:
                self.db.execute("UPDATE signals SET status='deferred_t1' WHERE symbol=? AND signal_id=?",
                                (symbol, signal_id))
            return
        price = bar["close"] * (1 - self.config.slippage)
        qty = position["qty"]
        fee, tax = self._fee(qty * price), qty * price * self.config.sell_tax
        state["cash"] += qty * price - fee - tax
        del state["positions"][symbol]
        state["deferred_exits"].pop(symbol, None)
        self._order(order_id, symbol, "sell", "filled", now, reason=reason)
        if signal_id:
            self.db.execute("UPDATE signals SET status='filled' WHERE symbol=? AND signal_id=?",
                            (symbol, signal_id))
        self._execution(executions, symbol=symbol, side="sell", action="sell", qty=qty, quantity=qty,
                        price=price, reference_close=bar["close"], fees=fee, tax=tax,
                        notional=qty * price, bar_end=bar["end"], observed_at=now,
                        order_id=order_id, signal_id=signal_id, reason=reason,
                        realized_pnl=qty * (price - position["entry"]) - fee - tax - position["entry_fee"])
        self._event(events, "filled_sell", symbol, reason=reason, price=price, qty=qty)

    def _process_fresh(self, state: dict, symbol: str, bar: dict, signal: dict | None,
                       now: float, events: list, executions: list) -> str:
        bar_day = self._date(bar["end"])
        if state["day"] is not None and bar_day < state["day"]:
            self._pending_done(state, symbol, "cancelled_old_account_day", now, events)
            return "older_account_day"
        if state["day"] != bar_day:
            state["day"], state["day_start_equity"] = bar_day, self._equity(state)
            state["daily_loss_locked"] = False
        state["marks"][symbol] = bar["close"]
        self._lock_daily_loss(state)
        if bar["volume"] <= 0:
            self._pending_done(state, symbol, "cancelled_no_volume", now, events)
            self._observe_signal(state, symbol, bar, signal, now, events, "rejected_no_volume")
            return "no_volume"
        if self._session(bar["end"]) is None:
            self._pending_done(state, symbol, "cancelled_outside_session", now, events)
            self._observe_signal(state, symbol, bar, signal, now, events, "outside_session")
            return "outside_session"

        position = state["positions"].get(symbol)
        deferred = state["deferred_exits"].get(symbol)
        if position and deferred:
            self._sell(state, symbol, bar, now, deferred["order_id"], deferred["reason"],
                       executions, events, deferred.get("signal_id"))
        elif position and bar["low"] <= position["stop"]:
            order_id = f"stop:{symbol}:{position['opened_at']}"
            self._sell(state, symbol, bar, now, order_id, "observed_stop_touch", executions, events)

        self._lock_daily_loss(state)

        pending = state["pending"].get(symbol)
        if pending:
            if now - pending["at"] > self.config.pending_ttl:
                self._pending_done(state, symbol, "cancelled_expired", now, events)
            elif pending["action"] == "buy" and self._session(pending["at"]) != self._session(bar["end"]):
                self._pending_done(state, symbol, "cancelled_session_boundary", now, events)
            elif bar["end"] > pending["at"]:
                if pending["action"] == "sell":
                    if symbol not in state["positions"]:
                        self._pending_done(state, symbol, "cancelled_no_position", now, events)
                    else:
                        self._pending_done(state, symbol, "submitted_exit", now, events)
                        self._sell(state, symbol, bar, now, pending["order_id"], "strategy_exit",
                                   executions, events, pending["id"])
                elif state["daily_loss_locked"]:
                    self._pending_done(state, symbol, "rejected_daily_loss", now, events)
                elif symbol in state["positions"]:
                    self._pending_done(state, symbol, "rejected_no_additions", now, events)
                elif pending["stop"] >= bar["close"]:
                    self._pending_done(state, symbol, "rejected_stop_above_fill", now, events)
                else:
                    entry = bar["close"] * (1 + self.config.slippage)
                    qty, risk = self._size(state, entry, pending["stop"], symbol)
                    if qty <= 0:
                        self._pending_done(state, symbol, "rejected_size_or_risk", now, events)
                    else:
                        fee = self._fee(qty * entry)
                        state["cash"] -= qty * entry + fee
                        state["positions"][symbol] = {"qty": qty, "quantity": qty, "entry": entry,
                            "entry_fee": fee, "stop": pending["stop"], "opened_day": bar_day,
                            "opened_at": bar["end"], "planned_risk": risk,
                            "entry_signal": pending["id"]}
                        self._pending_done(state, symbol, "filled", now, events)
                        self._execution(executions, symbol=symbol, side="buy", action="buy", qty=qty,
                            quantity=qty, price=entry, reference_close=bar["close"], fees=fee, tax=0.0,
                            notional=qty * entry, planned_risk=risk, bar_end=bar["end"], observed_at=now,
                            order_id=pending["order_id"], signal_id=pending["id"], reason="strategy_entry")
        self._lock_daily_loss(state)
        if state["daily_loss_locked"]:
            for pending_symbol, order in list(state["pending"].items()):
                if order["action"] == "buy":
                    self._pending_done(state, pending_symbol, "rejected_daily_loss", now, events)
        self._observe_signal(state, symbol, bar, signal, now, events)
        return "processed"

    def _observe_signal(self, state: dict, symbol: str, bar: dict, signal: dict | None,
                        now: float, events: list, rejection: str | None = None) -> None:
        if signal is None:
            return
        exists = self.db.execute("SELECT 1 FROM signals WHERE symbol=? AND signal_id=?",
                                 (symbol, signal["id"])).fetchone()
        if exists:
            self._event(events, "duplicate_signal", symbol, signal_id=signal["id"])
            return
        status = rejection
        if signal["at"] != bar["end"]:
            status = "rejected_signal_time"
        elif status is None and signal["action"] == "buy":
            if state["daily_loss_locked"]:
                status = "rejected_daily_loss"
            elif symbol in state["positions"]:
                status = "rejected_no_additions"
            elif signal["stop"] >= bar["close"]:
                status = "rejected_stop_above_signal"
        elif status is None and signal["action"] == "sell" and symbol not in state["positions"]:
            status = "rejected_no_position"
        elif status is None and signal["action"] == "sell" and symbol in state["deferred_exits"]:
            status = "rejected_exit_already_deferred"
        status = status or "pending"
        self.db.execute("INSERT INTO signals VALUES (?, ?, ?, ?, ?)",
                        (symbol, signal["id"], signal["action"], signal["at"], status))
        order_id = self._order_id(symbol, signal["id"])
        if status == "pending":
            self._pending_done(state, symbol, "cancelled_replaced", now, events)
            state["pending"][symbol] = {**signal, "order_id": order_id}
        self._order(order_id, symbol, signal["action"], status, now, at=signal["at"])
        self._event(events, status, symbol, signal_id=signal["id"], action=signal["action"])

    def process_bar(self, symbol: str, bar: dict, signal: dict | None = None,
                    now: float | None = None) -> dict:
        """Observe one completed OHLCV bar and an optional same-bar signal.

        ``bar.end``/``signal.at`` are UTC epoch seconds.  In replay mode the
        caller must supply the simulation clock, normally ``now=bar['end']``.
        The first bar for each symbol only establishes a watermark.  Old bars
        never generate catch-up orders.  Returned executions are from this call.
        """
        symbol = self._symbol(symbol)
        bar = self._validate_bar(bar)
        signal = self._validate_signal(signal)
        if now is None and self.config.mode == "replay":
            raise ValueError("replay requires an explicit simulation clock (now=bar.end)")
        now = _number(time.time() if now is None else now, "now", positive=True)
        events: list[dict] = []
        executions: list[dict] = []
        self.db.execute("BEGIN IMMEDIATE")
        try:
            state = json.loads(self.db.execute("SELECT state FROM account WHERE id=1").fetchone()[0])
            previous = state["last_bars"].get(symbol)
            if bar["end"] > now:
                status = "future_bar"
            elif previous is not None and bar["end"] <= previous:
                status = "duplicate_bar" if bar["end"] == previous else "out_of_order_bar"
            else:
                state["last_bars"][symbol] = bar["end"]
                if previous is None:
                    state["marks"][symbol] = bar["close"]
                    self._observe_signal(state, symbol, bar, signal, now, events, "warmup_skipped")
                    status = "warmup_no_trade"
                elif now - bar["end"] > self.config.max_bar_age:
                    state["marks"][symbol] = bar["close"]
                    self._pending_done(state, symbol, "cancelled_stale_bar", now, events)
                    self._observe_signal(state, symbol, bar, signal, now, events, "stale_signal_skipped")
                    status = "stale_bar"
                else:
                    status = self._process_fresh(state, symbol, bar, signal, now, events, executions)
            state["last_status"] = status
            self.db.execute("UPDATE account SET state=? WHERE id=1", (self._encode(state),))
            snapshot = self._snapshot(state)
            self.db.execute("COMMIT")
            return {"status": status, "events": events, "executions": executions, "snapshot": snapshot}
        except Exception:
            self.db.execute("ROLLBACK")
            raise

    def _snapshot(self, state: dict) -> dict:
        eq = self._equity(state)
        positions = {}
        for symbol, position in state["positions"].items():
            mark = state["marks"].get(symbol, position["entry"])
            positions[symbol] = {**position, "mark": mark, "market_value": position["qty"] * mark,
                                 "unrealized_pnl": position["qty"] * (mark - position["entry"]),
                                 "mark_at": state["last_bars"].get(symbol)}
        rows = self.db.execute("SELECT seq, details FROM executions ORDER BY seq DESC LIMIT 1000").fetchall()
        executions = [{**json.loads(row["details"]), "seq": row["seq"]} for row in reversed(rows)]
        count = self.db.execute("SELECT COUNT(*) FROM executions").fetchone()[0]
        start = state["day_start_equity"]
        return {"paper_only": True, "pricing": "delayed_bar_close", "mode": self.config.mode,
                "market": self.config.market, "currency": self.config.currency,
                "capital": self.config.capital, "cash": state["cash"], "equity": eq,
                "positions": positions, "pending": state["pending"], "deferred_exits": state["deferred_exits"],
                "last_bars": state["last_bars"], "last_status": state["last_status"],
                "day": state["day"], "account_day": state["day"], "day_start_equity": start,
                "daily_loss_locked": state["daily_loss_locked"],
                "daily_loss_pct": max(0.0, (start - eq) / start) if start else 0.0,
                "planned_risk": sum(p["planned_risk"] for p in state["positions"].values()),
                "executions": executions, "execution_count": count, "config": asdict(self.config),
                "valuation": "latest observed bar closes; marks may be stale",
                "risk_basis": "planned entry-to-stop loss including assumed fees; gap losses can exceed it"}

    def snapshot(self) -> dict:
        self.db.execute("BEGIN")
        try:
            state = json.loads(self.db.execute("SELECT state FROM account WHERE id=1").fetchone()[0])
            result = self._snapshot(state)
            self.db.execute("COMMIT")
            return result
        except Exception:
            self.db.execute("ROLLBACK")
            raise
