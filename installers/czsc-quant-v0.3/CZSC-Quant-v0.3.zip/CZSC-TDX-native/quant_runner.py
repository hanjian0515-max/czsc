"""Local CZSC historical replay and persistent automatic PAPER execution.

No broker or account connection is implemented. Paper orders are filled at a
later completed candle's close by quant_ledger, never at an earlier price.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import time

SHANGHAI = timezone(timedelta(hours=8))
UTC = timezone.utc
ROOT = Path(__file__).resolve().parent
MAX_SOURCE_AGE = 90


def bool_value(value):
    if isinstance(value, bool):
        return value
    if str(value).strip().lower() in ("1", "true", "yes", "on"):
        return True
    if str(value).strip().lower() in ("0", "false", "no", "off", "", "none"):
        return False
    raise ValueError("公开行情自动更新选项必须为开或关。")


def validate_config(config):
    """Normalize user input before opening a ledger or starting a subprocess."""
    result = {key: str(config.get(key, default)).strip() for key, default in (
        ("source", ""), ("asset_market", "ashare"), ("market", "sz"),
        ("code", "000001"), ("mode", "paper"), ("ledger", ""), ("report", ""))}
    if result["asset_market"] not in ("ashare", "crypto"):
        raise ValueError("交易市场必须为ashare或crypto。")
    if result["mode"] not in ("paper", "replay"):
        raise ValueError("模式必须为paper（自动模拟）或replay（历史回放）。")
    result["online"] = bool_value(config.get("online", False)) and result["asset_market"] == "crypto" and result["mode"] == "paper"
    try:
        result["capital"] = float(config.get("capital", 1_000_000))
        interval = config.get("interval")
        result["interval"] = float((10 if result["online"] else 5) if interval in (None, "") else interval)
    except (TypeError, ValueError) as error:
        raise ValueError("初始资金和轮询间隔必须为数字。") from error
    if not math.isfinite(result["capital"]) or not 0 < result["capital"] <= 1e12:
        raise ValueError("初始资金必须大于0，且不超过一万亿元。")
    if not math.isfinite(result["interval"]) or not 1 <= result["interval"] <= 60:
        raise ValueError("轮询间隔须在1至60秒之间。")
    source = Path(result["source"])
    if not result["source"] or not source.is_file():
        raise ValueError("请先选择已有的行情源文件。")
    if result["asset_market"] == "ashare":
        if result["market"] not in ("sh", "sz"):
            raise ValueError("A股市场必须为sh或sz。")
        if not re.fullmatch(r"[0-9]{6}", result["code"]):
            raise ValueError("A股代码必须为六位数字。")
        tradable = ((result["market"] == "sh" and result["code"][:2] in ("60", "68")) or
                    (result["market"] == "sz" and result["code"][:2] in ("00", "30")))
        if not tradable:
            raise ValueError("此模拟器仅支持沪深A股股票；指数、基金和其他产品不可作为股票成交。请自行选择股票。")
        identity = re.fullmatch(r"(sh|sz)([0-9]{6})\.lc5", source.name.lower())
        if not identity or identity.groups() != (result["market"], result["code"]):
            raise ValueError("A股请选.lc5文件，且文件名市场、代码须与所选股票完全一致。")
        result["symbol"] = result["market"] + result["code"]
        result["currency"] = "CNY"
    else:
        result["code"] = result["code"].upper()
        if result["code"] != "BTC-USD":
            raise ValueError("当前加密货币模块只支持BTC-USD现货做多。")
        if source.suffix.lower() not in (".json", ".csv"):
            raise ValueError("BTC-USD请选本地5分钟CSV或公开行情JSON文件。")
        if result["online"] and source.suffix.lower() != ".json":
            raise ValueError("自动更新需先下载公开历史行情JSON以暖机；CSV请取消自动更新。")
        result["symbol"], result["currency"] = "BTC-USD", "USD"
    if not result["ledger"]:
        raise ValueError("请选择或新建SQLite模拟账本。")
    ledger = Path(result["ledger"])
    if ledger.exists() and not ledger.is_file():
        raise ValueError("账本路径必须为文件。")
    if ledger.resolve() == source.resolve():
        raise ValueError("账本不能覆盖行情文件。")
    result["source"], result["ledger"] = str(source.resolve()), str(ledger.resolve())
    if result["report"]:
        report = Path(result["report"])
        if report.resolve() in (source.resolve(), ledger.resolve()):
            raise ValueError("报告路径不能覆盖行情或账本。")
        result["report"] = str(report.resolve())
    return result


def candle_bar(candle):
    """Candle uses naive Shanghai close times; the ledger uses UTC seconds."""
    if candle.end.tzinfo is not None:
        raise ValueError("K线结束时间须为上海本地无时区时间。")
    return {"end": int(candle.end.replace(tzinfo=SHANGHAI).timestamp()),
            **{key: float(getattr(candle, key)) for key in ("open", "high", "low", "close", "volume")}}


def load_data(config, now):
    clock = datetime.fromtimestamp(now, UTC)
    if config["asset_market"] == "crypto":
        from quant_crypto import load_crypto_data
        source = config["source"]
        if config.get("online"):
            from quant_crypto import refresh_crypto_file
            source = live_quote_path(config)
            # A failed network refresh raises here. Never trade using an old
            # file merely because its last candle happens to look recent.
            refresh_crypto_file(config["source"], source, product=config["code"], now=clock)
        return load_crypto_data(source, symbol=config["code"], now=clock)
    from quant_strategy import load_quant_data
    return load_quant_data(config["source"], symbol=config["code"], market=config["market"], now=clock)


def live_quote_path(config, root=ROOT):
    identity = str(Path(config["ledger"]).resolve()) + "\0" + config["symbol"]
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
    return Path(root) / "runtime" / "quotes" / (digest + "-BTC-USD-live.json")


def signals_for(five, thirty, daily, symbol):
    from quant_strategy import signal_series
    return signal_series(five, thirty, daily, symbol=symbol)


def signal_map(signals, symbol=None):
    """Reject conflicting simultaneous signals instead of choosing silently."""
    result = {}
    for item in signals:
        if not isinstance(item, dict) or item.get("action") not in ("buy", "sell"):
            raise ValueError("策略返回了无效的交易信号。")
        if symbol is not None and item.get("symbol", symbol) != symbol:
            raise ValueError("策略信号的证券与当前账本不一致。")
        stamp = int(item["at"])
        if stamp in result and result[stamp] != item:
            raise ValueError("同一收盘出现冲突信号，已暂停模拟。")
        result[stamp] = item
    return result


def _base(config, now):
    return {"paper_only": True, "mode": config["mode"], "market": config["asset_market"],
            "symbol": config["symbol"], "currency": config["currency"],
            "generated_at": now, "source_at": None, "source_at_utc": None, "source_age": None,
            "source_kind": "coinbase_public_online" if config.get("online") else "local_file",
            "pricing": "delayed_bar_close", "signal": None, "errors": [], "executions": []}


def _source_info(output, bar, now):
    output.update(source_at=datetime.fromtimestamp(bar["end"], SHANGHAI).isoformat(),
                  source_at_utc=bar["end"], source_age=round(now - bar["end"], 3))


def _last_end(snapshot, symbol):
    value = snapshot.get("last_bars", {}).get(symbol)
    if isinstance(value, dict):
        value = value.get("end")
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def require_single_symbol(snapshot, symbol):
    """The UI/runner monitor one source; never leave other account symbols idle."""
    bound = set(snapshot.get("last_bars", {})) | set(snapshot.get("positions", {})) | set(snapshot.get("pending", {}))
    if bound - {symbol}:
        raise ValueError("此账本已绑定其他证券（{}）；单证券模式必须新建独立账本。".format("、".join(sorted(bound))))


def refresh(config, ledger, first=False, now=None):
    """One paper poll; observe only the newest completed bar, never catch up."""
    live_clock = now is None
    now = time.time() if live_clock else float(now)
    output = _base(config, now)
    try:
        before = ledger.snapshot()
        require_single_symbol(before, config["symbol"])
        five, thirty, daily = load_data(config, now)
        if not five:
            raise ValueError("尚无已收盘5分钟K线。")
        latest = candle_bar(five[-1])
        if live_clock:
            now = time.time()
        _source_info(output, latest, now)
        age = now - latest["end"]
        previous = _last_end(before, config["symbol"])
        # First observation initializes/restores a watermark, without old signals.
        # The ledger independently checks freshness, deduplication and pending expiry.
        if first:
            result = ledger.process_bar(config["symbol"], latest, signal=None, now=now)
            output.update(status="initialized", message="账本已恢复；不补发历史信号，既有模拟委托按时效处理。")
        elif age < 0 or age > MAX_SOURCE_AGE:
            result = ledger.process_bar(config["symbol"], latest, signal=None, now=now)
            output.update(status="paused_stale", message="行情不在90秒时效内；历史数据不触发自动模拟。")
        elif previous is not None and latest["end"] <= previous:
            result = {"snapshot": before, "executions": [], "status": "same_bar"}
            output.update(status="waiting_bar", message="等待下一根已收盘5分钟K线。")
        else:
            candidate = signal_map(signals_for(five, thirty, daily, config["symbol"]), config["symbol"]).get(latest["end"])
            if live_clock:
                now = time.time()
                _source_info(output, latest, now)
                age = now - latest["end"]
                if age < 0 or age > MAX_SOURCE_AGE:
                    candidate = None
            output["signal"] = candidate
            result = ledger.process_bar(config["symbol"], latest, signal=candidate, now=now)
            output.update(status=result.get("status", "processed"),
                          message="已处理最新K线；策略委托延后一根有效收盘，保护退出按观测柱收盘模拟（A股T+1可延期）。")
        output["ledger"] = result["snapshot"] if "snapshot" in result else ledger.snapshot()
        output["executions"] = result.get("executions", [])
        output["ledger_status"] = result.get("status")
        if age < 0 or age > MAX_SOURCE_AGE:
            output.update(status="paused_stale", message="行情不在90秒时效内；历史数据不触发自动模拟。")
    except Exception as error:
        output.update(status="error", message="模拟暂停：" + str(error), errors=[str(error)])
        output["ledger"] = ledger.snapshot()
    return output


def replay(config, ledger, now=None, progress=None):
    """Causal historical replay in a separate new ledger, without end liquidation."""
    now = time.time() if now is None else float(now)
    output = _base(config, now)
    require_single_symbol(ledger.snapshot(), config["symbol"])
    five, thirty, daily = load_data(config, now)
    if not five:
        raise ValueError("没有可回放的已收盘K线。")
    by_time = signal_map(signals_for(five, thirty, daily, config["symbol"]), config["symbol"])
    actual = []
    for index, candle in enumerate(five):
        bar = candle_bar(candle)
        candidate = None if index == 0 else by_time.get(bar["end"])
        result = ledger.process_bar(config["symbol"], bar, signal=candidate, now=bar["end"])
        actual.extend(result.get("executions", []))
        if progress is not None and (index + 1) % 500 == 0:
            progress({"paper_only": True, "mode": "replay", "status": "replay_progress",
                      "processed": index + 1, "total": len(five)})
    _source_info(output, candle_bar(five[-1]), now)
    snapshot = ledger.snapshot()
    output.update(status="replay_complete", message="历史回放完成；未强制期末平仓。",
                  processed=len(five), executions=actual, ledger=snapshot,
                  execution_count=snapshot.get("execution_count", len(actual)),
                  open_positions=snapshot.get("positions", {}), final_equity=snapshot.get("equity"),
                  net_pnl=snapshot.get("equity", config["capital"]) - config["capital"],
                  signal_count=len(by_time), historical=True)
    return output


def write_report(report, output):
    """Create a report exclusively; replay reports cannot overwrite old results."""
    report = Path(report)
    report.parent.mkdir(parents=True, exist_ok=True)
    with report.open("x", encoding="utf-8") as file:
        json.dump(output, file, ensure_ascii=False, indent=2, allow_nan=False)
        file.write("\n")


def _emit(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description="CZSC本地历史回放 / 自动模拟；无实盘交易接口")
    parser.add_argument("--source", required=True)
    parser.add_argument("--asset-market", choices=("ashare", "crypto"), default="ashare")
    parser.add_argument("--market", choices=("sh", "sz"), default="sz")
    parser.add_argument("--code", default="000001")
    parser.add_argument("--capital", type=float, default=1_000_000)
    parser.add_argument("--ledger", required=True)
    parser.add_argument("--mode", choices=("paper", "replay"), default="paper")
    parser.add_argument("--report", default="")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=float, default=None)
    parser.add_argument("--online", action="store_true", help="BTC自动模拟时只读更新公开行情；失败暂停")
    args = parser.parse_args(argv)
    ledger = None
    try:
        config = validate_config(vars(args))
        if config["mode"] == "replay":
            if args.watch:
                raise ValueError("历史回放为单次执行，不能使用--watch。")
            path = Path(config["ledger"])
            if path.exists() and path.stat().st_size:
                raise ValueError("历史回放须使用新账本；请选择新的SQLite路径。")
            if config["report"] and Path(config["report"]).exists():
                raise ValueError("报告已存在；请选择新的报告路径。")
        from quant_ledger import Config, QuantLedger
        account = Config(market=config["asset_market"], mode=config["mode"], capital=config["capital"])
        ledger = QuantLedger(config["ledger"], account)
        if config["mode"] == "replay":
            output = replay(config, ledger, progress=_emit)
            if config["report"]:
                write_report(config["report"], output)
                output["report"] = config["report"]
            _emit(output)
            return 0
        first = True
        while True:
            output = refresh(config, ledger, first=first)
            _emit(output)
            # Failed reads do not count as a first observation.
            if output["status"] != "error":
                first = False
            if not args.watch:
                return 1 if output["errors"] else 0
            time.sleep(config["interval"])
    except KeyboardInterrupt:
        _emit({"paper_only": True, "status": "stopped", "errors": []})
        return 0
    except Exception as error:
        _emit({"paper_only": True, "status": "error", "errors": [str(error)], "message": str(error)})
        return 1
    finally:
        if ledger is not None:
            ledger.close()


if __name__ == "__main__":
    raise SystemExit(main())
