"""Causal CZSC 1.0.2 signals for the local A-share paper simulator.

The rules below are an experimental, explicit interpretation of a pen-interval
third-buy pattern. They are not the private indicator in the reference image,
nor a claim that this is a complete or authoritative Chan trading system.
This module reads local prices and emits intents only; it cannot submit orders.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Sequence

try:
    from . import export_czsc, tdx_local
except ImportError:  # Direct execution/import from the packaged tool directory.
    import export_czsc
    import tdx_local

Candle = export_czsc.Candle
STRATEGY_VERSION = "czsc-1.0.2-pen-third-buy-v1"
CANDIDATE_SECONDS = 3 * 60 * 60


def _symbol(symbol: str, market: str | None = None) -> str:
    value = str(symbol).lower().strip()
    match = re.fullmatch(r"(?:(sh|sz))?([0-9]{6})", value)
    if not match:
        raise ValueError("证券代码必须是 sh/sz 加六位数字，或六位代码并指定市场")
    prefix, code = match.groups()
    if market is not None:
        market = market.lower().strip()
        if market not in ("sh", "sz") or (prefix is not None and prefix != market):
            raise ValueError("证券代码与配置的 sh/sz 市场不一致")
    prefix = prefix or market
    if prefix is None:
        raise ValueError("六位代码必须另行指定 sh/sz 市场")
    return prefix + code


def load_quant_data(source_path: str | Path, symbol: str, market: str | None = None,
                    now: datetime | None = None) -> tuple[list[Candle], list[Candle], list[Candle]]:
    """Read closed, unadjusted local bars for one explicitly identified security.

    Source must be ``.../fzline/sz000001.lc5`` (or sh equivalent). The paired
    daily file is ``.../lday/sz000001.day``. Incomplete 30m groups are omitted by
    the existing strict adapter. Empty timeframes fail, while genuine CZSC
    warm-up (insufficient pens) simply produces no entry signals later.
    ``now`` follows tdx_local: aware timestamps are converted to Shanghai;
    naive timestamps already mean Shanghai local time.
    """
    identity = _symbol(symbol, market)
    path = Path(source_path)
    match = re.fullmatch(r"(sh|sz)([0-9]{6})\.lc5", path.name.lower())
    if not match or "".join(match.groups()) != identity:
        raise ValueError("行情文件名必须与证券一致，例如 fzline/sz000001.lc5")
    if path.parent.name.lower() != "fzline":
        raise ValueError("请选择通达信 fzline 目录下的 .lc5 文件")
    day_path = path.parent.parent / "lday" / (path.stem + ".day")
    if not path.is_file():
        raise FileNotFoundError(f"缺少5分钟行情文件：{path}")
    if not day_path.is_file():
        raise FileNotFoundError(f"缺少同证券日线文件：{day_path}；请在通达信下载日线数据")
    five_local = tdx_local.read_lc5(path, now=now)
    thirty_local, _skipped = tdx_local.aggregate_30m(five_local)
    daily_local = tdx_local.read_day(day_path, now=now)
    for label, bars in (("5分钟", five_local), ("30分钟（需要连续6根完整5分钟K线）", thirty_local),
                        ("日线", daily_local)):
        if not bars:
            raise ValueError(f"没有已收盘的{label}数据；请下载完整历史行情")

    def candles(bars):
        return [Candle(b.end, b.open, b.high, b.low, b.close, b.volume) for b in bars]

    return candles(five_local), candles(thirty_local), candles(daily_local)


def _utc(stamp: datetime) -> int:
    if stamp.tzinfo is not None:
        raise ValueError("K线和笔时间必须是无时区的上海本地收盘时间")
    return int(stamp.replace(tzinfo=export_czsc.SHANGHAI).timestamp())


def _hash(*parts) -> str:
    payload = json.dumps(parts, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]


@dataclass(frozen=True)
class PenSnapshot:
    """Immutable view of an actually observed native BI; timestamps are UTC."""

    direction: str
    high: float
    low: float
    start: int
    end: int

    @property
    def key(self) -> str:
        return _hash(asdict(self))


@dataclass(frozen=True)
class _Candidate:
    key: str
    confirmed_at: int
    boundary: float
    stop: float


class ExperimentalStrategy:
    """State machine independent of execution and account position.

    It consumes only snapshots available at the current observation, not final
    historical pen labels. Seen structure/pen keys prevent a failed candidate
    from being resurrected and prevent reusing an older 5m confirmation.
    """

    def __init__(self, symbol: str):
        self.symbol = symbol
        self.candidate: _Candidate | None = None
        self._structure: str | None = None
        self._seen_structures: set[str] = set()
        self._seen_five: set[str] = set()

    def observe(self, bar: Candle, five: Sequence[PenSnapshot],
                thirty: Sequence[PenSnapshot], daily: Sequence[PenSnapshot]) -> list[dict]:
        at = _utc(bar.end)
        events = []
        latest = five[-1] if five else None
        new_five = latest is not None and latest.key not in self._seen_five
        if new_five:
            self._seen_five.add(latest.key)
            if latest.direction == "down":
                events.append({"id": _hash(STRATEGY_VERSION, self.symbol, "sell", latest.key),
                               "action": "sell", "at": at, "symbol": self.symbol,
                               "strategy": STRATEGY_VERSION, "reason": "新确认的5分钟向下笔"})

        structure = list(thirty[-5:]) if len(thirty) >= 5 else []
        key = _hash([asdict(p) for p in structure]) if structure else None
        if key != self._structure:
            self._structure = key
            self.candidate = None
            if key is not None and key not in self._seen_structures:
                self._seen_structures.add(key)
                center, leave, pull = structure[:3], structure[3], structure[4]
                zd, zg = max(p.low for p in center), min(p.high for p in center)
                if (zd < zg and leave.direction == "up" and leave.high > zg
                        and pull.direction == "down" and pull.low > zg):
                    self.candidate = _Candidate(key, at, zg, round(pull.low - .01, 8))

        candidate = self.candidate
        if candidate is None:
            return events
        # A low at/below either boundary is already observable at this close.
        if (bar.low <= candidate.stop or bar.low <= candidate.boundary
                or at - candidate.confirmed_at >= CANDIDATE_SECONDS):
            self.candidate = None
            return events
        if (new_five and latest.direction == "up"
                and latest.start > candidate.confirmed_at
                and daily and daily[-1].direction == "up"):
            events.append({"id": _hash(STRATEGY_VERSION, self.symbol, "buy", candidate.key, latest.key),
                           "action": "buy", "at": at, "symbol": self.symbol,
                           "stop": candidate.stop, "strategy": STRATEGY_VERSION,
                           "reason": "30分钟笔区间三买候选 + 日线向上 + 新5分钟向上笔"})
            self.candidate = None
        return events


def _validate_candles(bars: Sequence[Candle], label: str) -> None:
    for bar in bars:
        _utc(bar.end)
        prices = (bar.open, bar.high, bar.low, bar.close, bar.volume)
        if not all(math.isfinite(x) for x in prices) or bar.volume < 0:
            raise ValueError(f"{label}行情含非有限数值或负成交量")
        if not (0 < bar.low <= min(bar.open, bar.close) <= max(bar.open, bar.close) <= bar.high):
            raise ValueError(f"{label}行情OHLC不合法")
    if any(a.end >= b.end for a, b in zip(bars, bars[1:])):
        raise ValueError(f"{label}行情时间必须严格递增且不重复")


def _pens(analysis, native) -> list[PenSnapshot]:
    if analysis is None:
        return []
    # The last native pen may still be revised. Deliberately lag one extra BI.
    return [PenSnapshot("up" if bi.direction == native.Direction.Up else "down",
                        float(bi.high), float(bi.low), _utc(bi.fx_a.dt), _utc(bi.fx_b.dt))
            for bi in analysis.bi_list[:-1]]


def signal_series(five: Sequence[Candle], thirty: Sequence[Candle], daily: Sequence[Candle],
                  symbol: str, min_bi_len: int = 6) -> list[dict]:
    """Rebuild chronological intents using the pinned native CZSC engine.

    Each decision is stamped with the current 5m bar's close (UTC Unix seconds).
    Higher frames are fed only after their own close, including a daily close
    at 15:00. No warm-up data is invented; absent BI structure means no buy.
    Reprocessing identical history yields identical IDs for SQLite deduplication.
    """
    identity = str(symbol).strip()
    if not identity or len(identity) > 128:
        raise ValueError("必须指定证券或交易对标识")
    if not isinstance(min_bi_len, int) or isinstance(min_bi_len, bool) or min_bi_len < 3:
        raise ValueError("min_bi_len 必须是至少3的整数")
    for label, bars in (("5分钟", five), ("30分钟", thirty), ("日线", daily)):
        _validate_candles(bars, label)
    if not five:
        return []
    native = export_czsc._native()
    strategy = ExperimentalStrategy(identity)
    analyses = {"five": None, "thirty": None, "daily": None}
    freqs = {"five": native.Freq.F5, "thirty": native.Freq.F30, "daily": native.Freq.D}

    def feed(name, candle, index):
        raw = native.RawBar(symbol=identity, dt=candle.end, freq=freqs[name], id=index,
                            open=candle.open, close=candle.close, high=candle.high,
                            low=candle.low, vol=candle.volume, amount=candle.close*candle.volume)
        if analyses[name] is None:
            analyses[name] = native.CZSC([raw], min_bi_len=min_bi_len, max_bi_num=100)
        else:
            analyses[name].update(raw)

    events, ti, di = [], 0, 0
    for i, candle in enumerate(five):
        while ti < len(thirty) and thirty[ti].end <= candle.end:
            feed("thirty", thirty[ti], ti)
            ti += 1
        while di < len(daily) and daily[di].end <= candle.end:
            feed("daily", daily[di], di)
            di += 1
        feed("five", candle, i)
        events.extend(strategy.observe(candle, _pens(analyses["five"], native),
                                       _pens(analyses["thirty"], native),
                                       _pens(analyses["daily"], native)))
    return events
