@echo off
setlocal
set PYTHONUTF8=1
cd /d "%~dp0"
if not "%errorlevel%"=="0" goto :failed
py -3.12 --version
if not "%errorlevel%"=="0" goto :python_missing
if not exist ".venv\Scripts\python.exe" py -3.12 -m venv .venv
if not "%errorlevel%"=="0" goto :failed
if not exist ".venv\Scripts\python.exe" goto :failed
.venv\Scripts\python.exe -c "import sys,struct; assert sys.version_info[:2]==(3,12), 'This environment requires Python 3.12'; assert struct.calcsize('P')==8, 'Install 64-bit Python for CZSC'"
if not "%errorlevel%"=="0" goto :failed
.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
if not "%errorlevel%"=="0" goto :failed
.venv\Scripts\python.exe app.py %*
if not "%errorlevel%"=="0" goto :failed
pause
exit /b 0
:python_missing
echo Python 3.12 is missing. The Python launcher alone is not the runtime.
echo If your launcher suggests "py install 3.12", open Command Prompt and run:
echo.
echo     py install 3.12
echo.
echo Then verify it with: py -3.12 --version
echo If "py install" is not supported, install Python 3.12 64-bit from:
echo     https://www.python.org/downloads/windows/
echo Run INSTALL_AND_RUN.cmd again after Python is installed.
echo Extract the entire ZIP to a writable folder before running this file.
pause
exit /b 1
:failed
echo Setup or bridge failed. Keep the error above. Do not assume alarms are active.
pause
exit /b 1
