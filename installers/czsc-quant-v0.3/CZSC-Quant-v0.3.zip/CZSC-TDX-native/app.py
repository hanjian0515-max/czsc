"""Chinese Windows control center for the local CZSC / Tongdaxin bridge.

Only the local bridge process is managed here; this application does not collect
quotes, submit orders, or change Tongdaxin settings. Helpers need no Tk display.
"""
from datetime import datetime, timedelta, timezone
import json
import math
import os
from pathlib import Path
import queue
import re
import subprocess
import sys
import threading
import time

from windows_launcher import install_bridge, pe_arch


ROOT = Path(__file__).resolve().parent
CONFIG_FILE = ROOT / "runtime" / "windows-config.json"
SHANGHAI = timezone(timedelta(hours=8))
CONFIG_KEYS = ("source", "output_dir", "market", "code", "period", "tdx_exe", "slot")


def validate_config(config):
    """Return normalized configuration, checking inputs before spawning anything."""
    result = {key: str(config.get(key, "")).strip() for key in CONFIG_KEYS}
    result["slot"] = str(config.get("slot", 1)).strip()
    if result["slot"] not in tuple(str(i) for i in range(1, 10)):
        raise ValueError("DLL绑定槽必须为1至9。")
    if result["market"] not in ("sh", "sz"):
        raise ValueError("市场必须为sh（上海）或sz（深圳）。")
    if not re.fullmatch(r"[0-9]{6}", result["code"]):
        raise ValueError("证券代码必须是六位数字，如000001。")
    if result["period"] not in ("5m", "30m", "daily"):
        raise ValueError("周期必须为5m、30m或daily。")
    source = Path(result["source"])
    if not result["source"] or not source.is_file():
        raise ValueError("请先选择已有的行情源文件。")
    suffix = source.suffix.lower()
    if suffix not in (".lc5", ".day", ".csv"):
        raise ValueError("行情源只支持.lc5、.day或.csv文件。")
    if suffix in (".lc5", ".day"):
        identity = re.fullmatch(r"(sh|sz)([0-9]{6})\.(lc5|day)", source.name.lower())
        if not identity or identity.group(1) != result["market"] or identity.group(2) != result["code"]:
            raise ValueError("本地行情文件名的市场、代码必须与界面选择一致。")
        if (suffix == ".day") != (result["period"] == "daily"):
            raise ValueError(".day文件请选择daily；.lc5文件请选择5m或30m。")
    executable = Path(result["tdx_exe"])
    if not result["tdx_exe"] or not executable.is_file() or executable.suffix.lower() != ".exe":
        raise ValueError("请选择实际通达信主程序.exe。")
    if not (executable.parent / "T0002").is_dir():
        raise ValueError("通达信主程序必须与T0002文件夹位于同一目录。")
    if not result["output_dir"]:
        raise ValueError("缓存输出目录不能为空；重新选择通达信主程序可自动填写。")
    result["source"] = str(source.resolve())
    result["tdx_exe"] = str(executable.resolve())
    result["output_dir"] = str(Path(result["output_dir"]).resolve())
    result["slot"] = int(result["slot"])
    return result


def build_command(config, root=ROOT, python=sys.executable):
    """Arguments remain separate, even when a path contains shell metacharacters."""
    config = validate_config(config)
    arguments = [str(python), str(Path(root) / "run_bridge.py"), "--watch"]
    for key in ("source", "output_dir", "market", "code", "period"):
        arguments.extend(["--" + key.replace("_", "-"), config[key]])
    return arguments


def save_config(config, destination=CONFIG_FILE):
    """Atomically save UI settings; validation is performed when starting."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    selected = {key: config[key] for key in CONFIG_KEYS if key in config}
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(json.dumps(selected, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(destination)


def formula_for_slot(name, slot, root=ROOT):
    if name not in ("CZSCMAIN", "CZSCUP", "CZSCDN", "CZSCBD", "CZSCTD", "CZSCWIDE"):
        raise ValueError("未知公式。")
    if str(slot) not in tuple(str(i) for i in range(1, 10)):
        raise ValueError("DLL绑定槽必须为1至9。")
    text = (Path(root) / "formulas" / "utf8" / (name + ".txt")).read_text(encoding="utf-8-sig")
    return re.sub(r"\bTDXDLL1(?=\s*\()", "TDXDLL" + str(slot), text)


def _timestamp(value):
    if isinstance(value, bool):
        return None
    try:
        result = float(value)
    except (ValueError, TypeError):
        try:
            result = datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
        except (ValueError, TypeError, OverflowError):
            return None
    return result if math.isfinite(result) else None


def status_from_metadata(metadata, now=None):
    """Refresh age checks on every timer tick, even after engine output stops."""
    now = time.time() if now is None else now
    result = {"state": "unknown", "message": "尚无可验证缓存，实时预警关闭", "latest": "—"}
    if metadata.get("error"):
        result.update(state="error", message="引擎错误：" + str(metadata["error"]) + "；实时预警关闭")
        return result
    latest = _timestamp(metadata.get("newest_bar_end_utc"))
    generated = _timestamp(metadata.get("generated_at_utc"))
    if latest is not None:
        try:
            result["latest"] = datetime.fromtimestamp(latest, SHANGHAI).strftime("%Y-%m-%d %H:%M:%S（上海）")
        except (ValueError, OverflowError, OSError):
            latest = None
    if latest is None or generated is None:
        return result
    if latest > now or generated > now:
        result.update(state="future", message="数据或缓存时间在未来，请检查电脑时间；实时预警关闭")
    elif now - latest > 90:
        result.update(state="stale", message="历史数据可画，实时预警关闭（最新收盘超过90秒）")
    elif now - generated > 15:
        result.update(state="cache_stale", message="缓存更新已超过15秒，实时预警关闭")
    else:
        result.update(state="fresh", message="缓存与最新收盘在时效范围内；预警仍需在通达信内启用")
    return result


class ControlCenter:
    def __init__(self, window, root=ROOT):
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk, self.window, self.root = tk, ttk, window, Path(root)
        self.config_file = self.root / "runtime" / "windows-config.json"
        self.process = None
        self.quant_controls = []
        self.process_events = queue.Queue()
        self.metadata = {}
        self.closing = False
        self.stop_requested = False
        defaults = {"tdx_exe": "", "source": "", "output_dir": "", "market": "sz", "code": "000001", "period": "30m", "slot": "1"}
        load_error = None
        if self.config_file.exists():
            try:
                loaded = json.loads(self.config_file.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict):
                    raise ValueError("配置内容必须是对象")
                defaults.update({key: str(loaded[key]) for key in CONFIG_KEYS if key in loaded})
            except (OSError, ValueError) as error:
                load_error = str(error)
        self.values = {key: tk.StringVar(value=value) for key, value in defaults.items()}
        self.arch = tk.StringVar(value="尚未选择程序；以实际通达信程序位数为准")
        self.state = tk.StringVar(value="未启动；实时预警关闭")
        self.details = tk.StringVar(value="证券：—    周期：—    K线：—    CZSC笔：—")
        self.latest = tk.StringVar(value="最新收盘：—")
        self.paths = tk.StringVar(value="缓存：—\n辅助图层：—")
        window.title("CZSC 画线与模拟量化平台")
        window.geometry("1000x780")
        window.minsize(800, 660)
        window.protocol("WM_DELETE_WINDOW", self.close)
        frame = ttk.Frame(window, padding=14)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text="CZSC 画线与模拟量化平台", font=("Microsoft YaHei UI", 14, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(frame, text="笔/中枢使用原版CZSC；红蓝辅助线、背驰候选为独立规则，历史末端可修订。交易模块仅模拟。", wraplength=900).grid(row=1, column=0, columnspan=3, sticky="w", pady=(3, 12))
        self._file_row(frame, 2, "通达信主程序", "tdx_exe", self.select_executable)
        ttk.Label(frame, textvariable=self.arch).grid(row=3, column=1, columnspan=2, sticky="w", pady=(0, 6))
        self._file_row(frame, 4, "已有行情文件", "source", self.select_source)
        options = ttk.Frame(frame)
        options.grid(row=5, column=0, columnspan=3, sticky="w", pady=8)
        for label, key, choices, width in (("市场", "market", ("sh", "sz"), 6), ("代码", "code", None, 10), ("周期", "period", ("5m", "30m", "daily"), 8), ("DLL绑定槽", "slot", tuple(str(i) for i in range(1, 10)), 4)):
            ttk.Label(options, text=label).pack(side="left", padx=(0, 5))
            widget = ttk.Combobox(options, textvariable=self.values[key], values=choices, state="readonly", width=width) if choices else ttk.Entry(options, textvariable=self.values[key], width=width)
            widget.pack(side="left", padx=(0, 18))
        ttk.Label(frame, text="缓存输出目录").grid(row=6, column=0, sticky="w", padx=(0, 8))
        ttk.Entry(frame, textvariable=self.values["output_dir"]).grid(row=6, column=1, columnspan=2, sticky="ew", pady=4)
        buttons = ttk.Frame(frame)
        buttons.grid(row=7, column=0, columnspan=3, sticky="w", pady=10)
        for label, callback in (("自动量化：模拟 / 回测", self.open_quant), ("安装 / 更新画线DLL", self.install), ("启动画线引擎", self.start), ("停止画线", self.stop), ("打开输出目录", self.open_output)):
            ttk.Button(buttons, text=label, command=callback).pack(side="left", padx=(0, 8))
        copy = ttk.Frame(frame)
        copy.grid(row=8, column=0, columnspan=3, sticky="w", pady=(0, 8))
        for index, (label, name) in enumerate((("复制主图公式", "CZSCMAIN"), ("复制底背驰候选预警", "CZSCBD"), ("复制顶背驰候选预警", "CZSCTD"), ("复制扩宽候选预警", "CZSCWIDE"), ("复制向上笔确认预警", "CZSCUP"), ("复制向下笔确认预警", "CZSCDN"))):
            ttk.Button(copy, text=label, command=lambda n=name: self.copy_formula(n)).grid(row=index // 3, column=index % 3, padx=(0, 8), pady=3, sticky="ew")
        instructions = "通达信画线：公式管理器→DLL绑定→选择上方同号槽，绑定T0002\\dlls\\CZSCBridge.dll。新版需重新绑定以读取辅助图层；如文件被占用，请自行退出通达信。\n新建主图CZSCMAIN及条件选股公式CZSCBD/CZSCTD，使用上方复制按钮粘贴、测试、保存。预警需另在通达信中启用。自动模拟/回测可独立使用，不要求先绑定DLL。"
        ttk.Label(frame, text=instructions, wraplength=930, justify="left").grid(row=9, column=0, columnspan=3, sticky="w", pady=(0, 9))
        status = ttk.LabelFrame(frame, text="运行状态", padding=8)
        status.grid(row=10, column=0, columnspan=3, sticky="ew")
        for variable in (self.state, self.details, self.latest, self.paths):
            ttk.Label(status, textvariable=variable, wraplength=900, justify="left").pack(anchor="w", pady=2)
        ttk.Label(frame, text="本工具只读取已有文件，不采集行情、不连接交易账户。行情客户端必须持续更新所选文件；历史文件可画线，预警自动关闭。", wraplength=930).grid(row=11, column=0, columnspan=3, sticky="w", pady=9)
        frame.rowconfigure(12, weight=1)
        log_frame = ttk.Frame(frame)
        log_frame.grid(row=12, column=0, columnspan=3, sticky="nsew")
        self.log = tk.Text(log_frame, height=8, wrap="word", state="disabled")
        self.log.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        scrollbar.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=scrollbar.set)
        if defaults["tdx_exe"]:
            try:
                self.identify_architecture()
            except (OSError, ValueError) as error:
                self.arch.set("原通达信路径不可用，请重新选择；自动模拟窗口仍可使用")
                self.append_log("程序路径检查失败："+str(error))
        if load_error:
            self.append_log("原配置读取失败，请重新选择：" + load_error)
        self.window.after(300, self.tick)

    def _file_row(self, frame, row, label, key, callback):
        self.ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8))
        self.ttk.Entry(frame, textvariable=self.values[key]).grid(row=row, column=1, sticky="ew", pady=4)
        self.ttk.Button(frame, text="选择…", command=callback).grid(row=row, column=2, padx=(8, 0))

    def current_config(self):
        return {key: variable.get() for key, variable in self.values.items()}

    def open_quant(self):
        for control in self.quant_controls:
            if not control.closing and control.window.winfo_exists():
                control.window.deiconify()
                control.window.lift()
                return
        try:
            from quant_app import QuantControl
            window = self.tk.Toplevel(self.window)
            control = QuantControl(window, root=self.root)
            self.quant_controls.append(control)
        except (OSError, ValueError, ImportError) as error:
            self.show_error(error)

    def append_log(self, message):
        self.log.configure(state="normal")
        self.log.insert("end", datetime.now().strftime("%H:%M:%S ") + str(message).rstrip() + "\n")
        if int(self.log.index("end-1c").split(".")[0]) > 400:
            self.log.delete("1.0", "101.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def show_error(self, error):
        from tkinter import messagebox
        self.state.set("操作失败：" + str(error) + "；实时预警状态未确认")
        self.append_log(error)
        messagebox.showerror("CZSC操作失败", str(error), parent=self.window)

    def identify_architecture(self):
        architecture = pe_arch(self.values["tdx_exe"].get())
        self.arch.set("实际通达信：" + ("32位（x86）" if architecture == "x86" else "64位（x64）") + "；将安装对应位数DLL")
        return architecture

    def select_executable(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.window, title="选择与T0002同级的通达信主程序", filetypes=[("Windows程序", "*.exe")])
        if path:
            self.values["tdx_exe"].set(path)
            try:
                self.identify_architecture()
                if not (Path(path).parent / "T0002").is_dir():
                    raise ValueError("请选择T0002文件夹同级的通达信主程序。")
                self.values["output_dir"].set(str(Path(path).parent / "T0002" / "dlls" / "czsc_data"))
            except (OSError, ValueError) as error:
                self.show_error(error)

    def select_source(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.window, title="选择已有的通达信本地行情或CSV文件", filetypes=[("行情文件", "*.lc5 *.day *.csv"), ("所有文件", "*.*")])
        if path:
            self.values["source"].set(path)
            identity = re.fullmatch(r"(sh|sz)([0-9]{6})\.(lc5|day)", Path(path).name.lower())
            if identity:
                self.values["market"].set(identity.group(1))
                self.values["code"].set(identity.group(2))
                if identity.group(3) == "day":
                    self.values["period"].set("daily")
                elif self.values["period"].get() == "daily":
                    self.values["period"].set("5m")

    def install(self):
        from tkinter import messagebox
        if self.process is not None and self.process.poll() is None:
            self.show_error("请先停止外接引擎，再安装或更新DLL。")
            return
        try:
            self.identify_architecture()
            target = install_bridge(self.values["tdx_exe"].get(), self.root)
            self.values["output_dir"].set(str(target.parent / "czsc_data"))
            save_config(self.current_config(), self.config_file)
            self.append_log("DLL已准备：" + str(target))
            messagebox.showinfo("DLL已准备", "已安装：" + str(target) + "\n\n请在通达信公式管理器中，将此DLL重新绑定到第" + self.values["slot"].get() + "号槽。工具不会替你更改绑定或关闭通达信。", parent=self.window)
        except (OSError, ValueError) as error:
            self.show_error(error)

    def start(self):
        if self.process is not None:
            self.append_log("引擎已启动；修改配置后请先停止再启动。")
            return
        try:
            config = validate_config(self.current_config())
            self.identify_architecture()
            command = build_command(config, self.root)
            save_config(config, self.config_file)
            flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            environment = os.environ.copy()
            environment["PYTHONUTF8"] = "1"
            process = subprocess.Popen(command, cwd=self.root, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1, shell=False, env=environment, creationflags=flags)
            self.process = process
            self.stop_requested = False
            self.metadata = {}
            self.state.set("引擎已启动，正在读取本地行情；实时预警关闭，等待有效缓存")
            self.append_log("启动本地引擎：" + config["market"] + config["code"] + " / " + config["period"])
            threading.Thread(target=self._read_process, args=(process,), daemon=True).start()
        except (OSError, ValueError) as error:
            self.show_error(error)

    def _read_process(self, process):
        try:
            for line in process.stdout:
                self.process_events.put((process, "line", line))
        except (OSError, ValueError) as error:
            self.process_events.put((process, "line", "日志读取失败：" + str(error)))
        finally:
            process.stdout.close()
            code = process.wait()
            self.process_events.put((process, "exit", code))

    def stop(self):
        if self.process is None:
            return
        self.stop_requested = True
        process = self.process
        try:
            if process.poll() is None:
                process.terminate()
        except OSError as error:
            self.show_error(error)
            return
        self.state.set("正在停止引擎；缓存将停止更新，实时预警随后失效")
        self.window.after(2500, lambda: self._kill_if_running(process))

    def _kill_if_running(self, process):
        try:
            if process.poll() is None:
                process.kill()
        except OSError as error:
            if not self.closing:
                self.append_log("停止引擎失败：" + str(error))

    def copy_formula(self, name):
        from tkinter import messagebox
        try:
            text = formula_for_slot(name, self.values["slot"].get(), self.root)
            self.window.clipboard_clear()
            self.window.clipboard_append(text)
            self.window.update_idletasks()
            self.append_log(name + "已复制，使用DLL槽" + self.values["slot"].get())
            messagebox.showinfo("公式已复制", name + "已复制到剪贴板（DLL槽" + self.values["slot"].get() + "）。\n请在通达信新建" + ("主图叠加指标" if name == "CZSCMAIN" else "条件选股公式") + "后粘贴、测试并保存。预警公式还需在预警系统中选用。", parent=self.window)
        except (OSError, ValueError) as error:
            self.show_error(error)

    def open_output(self):
        try:
            value = self.values["output_dir"].get().strip()
            if not value:
                raise ValueError("请先选择通达信主程序以确定缓存目录。")
            path = Path(value)
            if not path.is_dir():
                raise ValueError("缓存目录尚不存在，请先安装DLL或启动引擎。")
            if sys.platform != "win32":
                raise ValueError("打开目录按钮仅适用于Windows：" + str(path))
            os.startfile(str(path))
        except (OSError, ValueError) as error:
            self.show_error(error)

    def tick(self):
        if self.closing:
            return
        while True:
            try:
                process, kind, value = self.process_events.get_nowait()
            except queue.Empty:
                break
            if process is not self.process:
                continue
            if kind == "exit":
                self.process = None
                self.append_log("引擎已退出，退出码：" + str(value))
                self.state.set("引擎已停止；缓存将在15秒时效到期后关闭实时预警" if self.stop_requested else "引擎意外退出；请查看日志，实时预警将在缓存时效到期后关闭")
                continue
            try:
                metadata = json.loads(value)
            except (ValueError, TypeError):
                self.append_log(value)
                continue
            if not isinstance(metadata, dict):
                self.append_log(value)
                continue
            self.metadata = metadata
            if metadata.get("error"):
                self.append_log("引擎错误：" + str(metadata["error"]))
            else:
                self.details.set("证券：{}    周期：{}    K线：{}    CZSC笔：{}".format(metadata.get("instrument", "—"), metadata.get("period", "—"), metadata.get("records", "—"), metadata.get("native_bis", "—")))
                visual_path = metadata.get("visual_output", metadata.get("visual_cache_path", metadata.get("visual_sidecar", "—")))
                self.paths.set("缓存：{}\n辅助图层：{}".format(metadata.get("output", "—"), visual_path))
                notes = metadata.get("visual_notes")
                if notes and notes != getattr(self, "last_visual_notes", None):
                    self.append_log("辅助图层规则：" + str(notes))
                    self.last_visual_notes = notes
        if self.metadata:
            status = status_from_metadata(self.metadata)
            self.latest.set("最新收盘：" + status["latest"])
            prefix = "引擎运行中；" if self.process is not None else "引擎已停止；"
            self.state.set(prefix + status["message"])
        self.window.after(500, self.tick)

    def close(self):
        self.closing = True
        for control in self.quant_controls:
            if not control.closing:
                control.close()
        if self.process is not None and self.process.poll() is None:
            try:
                self.process.terminate()
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._kill_if_running(self.process)
            except OSError:
                pass
        try:
            save_config(self.current_config(), self.config_file)
        except OSError:
            pass
        self.window.destroy()


def main():
    if sys.platform != "win32":
        raise SystemExit("此控制中心用于Windows。其他系统请使用run_bridge.py。")
    import tkinter as tk
    window = tk.Tk()
    ControlCenter(window)
    window.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
