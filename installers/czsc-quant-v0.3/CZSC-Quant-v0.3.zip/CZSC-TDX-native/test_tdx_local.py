import csv
from datetime import datetime, timedelta, timezone
import importlib.util
import io
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import tdx_local as local


def minute_record(stamp, op=10, hi=11, lo=9, close=10.5, amount=1000, volume=100):
    date = (stamp.year-2004)*2048 + stamp.month*100 + stamp.day
    return local.LC5_RECORD.pack(date, stamp.hour*60+stamp.minute, op, hi, lo,
                                  close, amount, volume, 0)


def day_record(day=20261104, op=1000, hi=1100, lo=900, close=1050, amount=1000, volume=100):
    return local.DAY_RECORD.pack(day, op, hi, lo, close, amount, volume, 0)


class LocalReaderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, data):
        path = self.root/name
        path.write_bytes(data)
        return path

    def test_verified_record_sizes_and_lc5_float_prices(self):
        self.assertEqual(local.LC5_RECORD.size, 32)
        self.assertEqual(local.DAY_RECORD.size, 32)
        stamp = datetime(2026, 11, 4, 9, 35)
        path = self.write("sz000001.lc5", minute_record(stamp, op=10.25))
        bars = local.read_lc5(path, now=stamp)
        self.assertEqual(len(bars), 1)
        self.assertEqual(bars[0].end, stamp)
        self.assertEqual(bars[0].open, 10.25)
        self.assertEqual(bars[0].volume, 100)

    def test_closed_filter_handles_aware_utc_and_local_time(self):
        a = datetime(2026, 11, 4, 9, 35)
        b = a+timedelta(minutes=5)
        path = self.write("sz000001.lc5", minute_record(a)+minute_record(b))
        utc_now = datetime(2026, 11, 4, 1, 36, tzinfo=timezone.utc)
        self.assertEqual([x.end for x in local.read_lc5(path, now=utc_now)], [a])

    def test_rejects_empty_partial_duplicate_unsorted_and_invalid_prices(self):
        a = datetime(2026, 11, 4, 9, 35)
        valid = minute_record(a)
        invalid = [b"", valid+b"x", valid+valid,
                   minute_record(a+timedelta(minutes=5))+valid,
                   minute_record(a, hi=float("nan")),
                   minute_record(a, close=20), minute_record(a, amount=-1)]
        for i, content in enumerate(invalid):
            with self.subTest(i=i):
                path = self.write(f"case{i}.lc5", content)
                with self.assertRaises(ValueError):
                    local.read_lc5(path, now=a+timedelta(hours=1))

    def test_rejects_lunch_auction_and_unaligned_stamps(self):
        for hour, minute in ((9, 30), (9, 36), (12, 0), (13, 0), (15, 5)):
            path = self.write("bad.lc5", minute_record(datetime(2026, 11, 4, hour, minute)))
            with self.assertRaises(ValueError):
                local.read_lc5(path)

    def test_daily_a_stock_scaling_and_close_at_1500(self):
        path = self.write("sh600000.day", day_record())
        self.assertEqual(local.read_day(path, now=datetime(2026, 11, 4, 14, 59)), [])
        result = local.read_day(path, now=datetime(2026, 11, 4, 15))
        self.assertEqual(result[0].open, 10)
        self.assertEqual(result[0].end, datetime(2026, 11, 4, 15))
        self.assertEqual(result[0].volume, 100)

    def test_unknown_daily_classes_need_explicit_price_scale(self):
        path = self.write("sh510300.day", day_record(op=10000, hi=11000, lo=9000, close=10500))
        with self.assertRaises(ValueError):
            local.read_day(path)
        self.assertEqual(local.read_day(path, price_scale=.001)[0].open, 10)
        with self.assertRaises(ValueError):
            local.read_day(path, price_scale=float("nan"))

    def test_30minute_exact_groups_no_lunch_filling(self):
        stamps = [datetime(2026, 11, 4, 11, 5)+timedelta(minutes=i*5) for i in range(6)]
        stamps += [datetime(2026, 11, 4, 13, 5)+timedelta(minutes=i*5) for i in range(6)]
        path = self.write("sz000001.lc5", b"".join(minute_record(t, op=10+i*.1, hi=20, lo=9, close=11) for i, t in enumerate(stamps)))
        bars, skipped = local.convert_local(path, "30m", now=datetime(2026, 11, 4, 14))
        self.assertEqual([b.end for b in bars], [datetime(2026, 11, 4, 11, 30), datetime(2026, 11, 4, 13, 30)])
        self.assertEqual(skipped, 0)
        self.assertEqual(bars[0].volume, 600)
        self.assertEqual(bars[0].open, 10)
        self.assertEqual(bars[0].close, 11)

    def test_missing_or_unclosed_5m_never_emits_complete_30m(self):
        stamps = [datetime(2026, 11, 4, 9, 35)+timedelta(minutes=i*5) for i in range(6)]
        path = self.write("sz000001.lc5", b"".join(minute_record(t) for t in stamps))
        bars, skipped = local.convert_local(path, "30m", now=datetime(2026, 11, 4, 9, 59))
        self.assertEqual(bars, [])
        self.assertEqual(skipped, 1)
        path.write_bytes(b"".join(minute_record(t) for i, t in enumerate(stamps) if i != 3))
        bars, skipped = local.convert_local(path, "30m", now=datetime(2026, 11, 4, 10))
        self.assertEqual(bars, [])
        self.assertEqual(skipped, 1)

    def test_period_extension_mismatch_rejected(self):
        path = self.write("sh600000.day", day_record())
        with self.assertRaises(ValueError):
            local.convert_local(path, "5m")

    def test_atomic_csv_roundtrip_and_protects_existing_output(self):
        bar = local.LocalBar(datetime(2026, 11, 4, 10), 10, 11, 9, 10.5, 100)
        path = self.root/"out.csv"
        self.assertTrue(local.write_csv_atomic(path, [bar]))
        with path.open(newline="", encoding="utf-8") as file:
            rows = list(csv.DictReader(file))
        self.assertEqual(rows[0]["Datetime"], "2026-11-04 10:00:00")
        self.assertEqual(rows[0]["Open"], "10")
        with self.assertRaises(FileExistsError):
            local.write_csv_atomic(path, [bar])
        self.assertFalse(local.write_csv_atomic(path, [bar], replace=True))
        original = path.read_bytes()
        with self.assertRaises(ValueError):
            local.write_csv_atomic(path, [], replace=True)
        self.assertEqual(path.read_bytes(), original)

    def test_replace_failure_preserves_old_csv_and_cleans_temp(self):
        target = self.root/"out.csv"
        target.write_text("old user data", encoding="utf-8")
        bar = local.LocalBar(datetime(2026, 11, 4, 10), 10, 11, 9, 10.5, 100)
        with patch.object(local.os, "replace", side_effect=OSError("locked")):
            with self.assertRaises(OSError):
                local.write_csv_atomic(target, [bar], replace=True)
        self.assertEqual(target.read_text(), "old user data")
        self.assertEqual(list(self.root.glob("*.tmp")), [])

    def test_cli_protects_source_and_only_overwrites_explicitly(self):
        path = self.write("sh600000.day", day_record())
        original = path.read_bytes()
        with patch("sys.stderr", new=io.StringIO()), self.assertRaises(SystemExit):
            local.main(["--input", str(path), "--period", "day", "--output", str(path)])
        target = self.root/"out.csv"
        target.write_text("user content")
        with patch("sys.stderr", new=io.StringIO()), self.assertRaises(SystemExit):
            local.main(["--input", str(path), "--period", "day", "--output", str(target)])
        with patch("sys.stdout", new=io.StringIO()):
            self.assertEqual(local.main(["--input", str(path), "--period", "day", "--output", str(target), "--replace-existing"]), 0)
        self.assertEqual(path.read_bytes(), original)
        self.assertTrue(target.read_text().startswith("Datetime,"))


if __name__ == "__main__":
    unittest.main()
