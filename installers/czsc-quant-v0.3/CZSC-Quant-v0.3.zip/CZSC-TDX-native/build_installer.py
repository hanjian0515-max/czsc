"""Build a Win32, no-CRT, per-user self-extracting installer from a product ZIP.

Usage: python build_installer.py --payload product.zip --output CZSC-Setup.exe
Build dependency: ziglang==0.13.0. Windows execution needs only Windows 10/11;
INSTALL_AND_RUN.cmd checks the separately installed Python 3.12 runtime.
The installer is unsigned. Appending an Authenticode certificate is unsupported
by this EOF-trailer format; do not claim this artifact has a trusted publisher.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import struct
import subprocess
import sys
import tempfile
import zipfile

MAGIC = b"CZSCSFX1"
TRAILER = struct.Struct("<8sQQ")
PRODUCT_ROOT = "CZSC-TDX-native"
MAX_PAYLOAD = 64 * 1024 * 1024
MAX_EXPANDED = 128 * 1024 * 1024
MAX_MEMBERS = 4096
KERNEL_FUNCTIONS = {
    "GetModuleFileNameW": 12, "GetEnvironmentVariableW": 12,
    "SetEnvironmentVariableW": 8, "GetTempPathW": 8, "GetTickCount": 0,
    "GetCurrentProcessId": 0, "CreateDirectoryW": 8, "RemoveDirectoryW": 4,
    "CreateFileW": 28, "GetFileSizeEx": 8, "SetFilePointerEx": 20,
    "ReadFile": 20, "WriteFile": 20, "CloseHandle": 4, "DeleteFileW": 4,
    "GetStdHandle": 4, "GetLastError": 0, "SetErrorMode": 4,
    "GetSystemDirectoryW": 8, "CreateProcessW": 40, "WaitForSingleObject": 8,
    "GetExitCodeProcess": 8, "ExitProcess": 4,
}
ROOT_FILES = {
    "README.md", "START-HERE.txt", "SHA256SUMS.txt", "requirements-lock.txt",
    "INSTALL_AND_RUN.cmd", "CHECK_32BIT_DLL.cmd", "czsc_bridge.c",
    "check_windows_dll.c", "setup_bootstrap.c",
}
RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)),
            *(f"lpt{i}" for i in range(1, 10))}


def _controlled_path(parts: list[str], directory: bool) -> bool:
    if not parts:
        return directory
    if directory:
        return parts in (["bin"], ["bin", "x86"], ["bin", "x64"],
                         ["formulas"], ["formulas", "utf8"], ["formulas", "gbk"])
    if len(parts) == 1:
        return parts[0] in ROOT_FILES or bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*\.py", parts[0]))
    if len(parts) == 3 and parts[0] == "bin" and parts[1] in {"x86", "x64"}:
        return parts[2] in {"CZSCBridge.dll", "CZSCCheck.exe"}
    return (len(parts) == 3 and parts[0] == "formulas" and parts[1] in {"utf8", "gbk"}
            and bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]*\.txt", parts[2])))


def _safe_member(info: zipfile.ZipInfo) -> tuple[str, bool]:
    name = info.filename
    # orig_filename preserves embedded NULs that ZipInfo.filename truncates.
    if info.orig_filename != name or "\\" in name or name.startswith("/"):
        raise ValueError(f"Unsafe ZIP path: {name!r}")
    directory = info.is_dir()
    parts = name[:-1].split("/") if directory else name.split("/")
    if not parts or parts[0] != PRODUCT_ROOT:
        raise ValueError(f"ZIP must have the single root {PRODUCT_ROOT!r}: {name!r}")
    for part in parts:
        if (not part or part in {".", ".."} or part[-1:] in {".", " "}
                or any(ord(c) < 32 or c in ':<>"|?*' for c in part)
                or part.split(".")[0].casefold() in RESERVED):
            raise ValueError(f"Unsafe Windows ZIP path: {name!r}")
    if not _controlled_path(parts[1:], directory):
        raise ValueError(f"Path is not a controlled program file: {name!r}")
    mode = info.external_attr >> 16
    kind = stat.S_IFMT(mode)
    if kind not in {0, stat.S_IFDIR if directory else stat.S_IFREG}:
        raise ValueError(f"ZIP contains a link or special file: {name!r}")
    if info.flag_bits & 1 or info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
        raise ValueError(f"Encrypted or unsupported ZIP member: {name!r}")
    if directory and info.file_size:
        raise ValueError(f"ZIP directory contains data: {name!r}")
    return "/".join(parts[1:]), directory


def validate_payload(payload: bytes) -> dict[str, str]:
    """Validate exact ZIP bytes before allowing them to overwrite program files.

    Explicit allowlists exclude .venv, runtime, credentials, market-data files,
    config files and every unknown directory. SHA256SUMS covers every file.
    This is packaging integrity validation, not publisher authentication.
    """
    if not payload or len(payload) > MAX_PAYLOAD or not payload.startswith(b"PK\x03\x04"):
        raise ValueError("Payload must be a nonempty ZIP no larger than 64 MiB")
    hashes: dict[str, str] = {}
    seen: set[str] = set()
    expanded = 0
    try:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            if len(archive.infolist()) > MAX_MEMBERS:
                raise ValueError("Too many ZIP members")
            # Expand-Archive and Python must see the same one-disk, non-ZIP64 ZIP.
            end = payload.rfind(b"PK\x05\x06", max(0, len(payload) - 65557))
            if end < 0 or end + 22 > len(payload):
                raise ValueError("Missing ZIP end record")
            disk, central_disk, disk_count, total_count, central_size, central_offset, comment = struct.unpack_from("<HHHHIIH", payload, end + 4)
            if (disk or central_disk or disk_count != total_count or total_count == 65535
                    or central_offset + central_size != end or end + 22 + comment != len(payload)):
                raise ValueError("ZIP must be single-disk without leading/trailing data or ZIP64")
            manifest = None
            for info in archive.infolist():
                relative, directory = _safe_member(info)
                key = relative.casefold()
                if key in seen:
                    raise ValueError(f"Duplicate Windows ZIP path: {info.filename!r}")
                seen.add(key)
                expanded += info.file_size
                if expanded > MAX_EXPANDED:
                    raise ValueError("Expanded payload exceeds 128 MiB")
                if directory:
                    continue
                data = archive.read(info)  # also checks each file's CRC
                if relative == "SHA256SUMS.txt":
                    manifest = data
                else:
                    hashes[relative] = hashlib.sha256(data).hexdigest()
            if "INSTALL_AND_RUN.cmd" not in hashes or manifest is None:
                raise ValueError("ZIP needs INSTALL_AND_RUN.cmd and SHA256SUMS.txt")
            expected: dict[str, str] = {}
            for line in manifest.decode("utf-8").splitlines():
                match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
                if not match or match[2] in expected:
                    raise ValueError("Malformed or duplicate SHA256 manifest entry")
                expected[match[2]] = match[1]
            if expected != hashes:
                raise ValueError("SHA256 manifest does not match all packaged files")
    except (zipfile.BadZipFile, UnicodeError, NotImplementedError, RuntimeError, struct.error) as error:
        raise ValueError(f"Invalid ZIP payload: {error}") from error
    return hashes


def extract_payload(container: bytes) -> bytes:
    """Parse the same trailer boundary contract as the Windows bootstrap."""
    if len(container) < 88:
        raise ValueError("Installer too short")
    magic, offset, length = TRAILER.unpack_from(container, len(container) - TRAILER.size)
    end = len(container) - TRAILER.size
    if magic != MAGIC or offset < 64 or offset > end or not 0 < length <= MAX_PAYLOAD or length != end - offset:
        raise ValueError("Invalid installer trailer or payload bounds")
    return container[offset:end]


def inspect_pe(binary: bytes) -> dict[str, object]:
    """Minimal dependency/architecture check; accepts only x86 console Kernel32 PE."""
    try:
        if binary[:2] != b"MZ":
            raise ValueError("Missing DOS signature")
        pe = struct.unpack_from("<I", binary, 0x3c)[0]
        if binary[pe:pe + 4] != b"PE\0\0":
            raise ValueError("Missing PE signature")
        machine, sections = struct.unpack_from("<HH", binary, pe + 4)
        optional_size = struct.unpack_from("<H", binary, pe + 20)[0]
        optional = pe + 24
        magic = struct.unpack_from("<H", binary, optional)[0]
        subsystem = struct.unpack_from("<H", binary, optional + 68)[0]
        if machine != 0x14c or magic != 0x10b or subsystem != 3 or optional_size < 224:
            raise ValueError("Bootstrap must be a Win32 console PE")
        section_table = optional + optional_size
        def rva_offset(rva: int) -> int:
            for index in range(sections):
                off = section_table + index * 40
                size, address, raw_size, raw = struct.unpack_from("<IIII", binary, off + 8)
                if address <= rva < address + max(size, raw_size):
                    result = raw + rva - address
                    if result >= len(binary):
                        break
                    return result
            raise ValueError("Invalid PE RVA")
        import_rva, import_size = struct.unpack_from("<II", binary, optional + 96 + 8)
        imports = []
        if not import_rva or not import_size:
            raise ValueError("Missing PE imports")
        offset = rva_offset(import_rva)
        while offset + 20 <= len(binary):
            descriptor = struct.unpack_from("<IIIII", binary, offset)
            if descriptor == (0, 0, 0, 0, 0):
                break
            start = rva_offset(descriptor[3])
            end = binary.find(b"\0", start)
            if end < start:
                raise ValueError("Invalid DLL import name")
            imports.append(binary[start:end].decode("ascii"))
            offset += 20
        else:
            raise ValueError("Unterminated PE imports")
        tls_rva, tls_size = struct.unpack_from("<II", binary, optional + 96 + 9 * 8)
        if [name.casefold() for name in imports] != ["kernel32.dll"] or tls_rva or tls_size:
            raise ValueError(f"Unexpected dependencies or TLS: {imports!r}")
        return {"architecture": "x86", "subsystem": "console", "imports": imports,
                "tls": False, "size": len(binary)}
    except (struct.error, UnicodeError, IndexError) as error:
        raise ValueError("Truncated or invalid PE") from error


def powershell_script(payload_sha256: str) -> str:
    """No user path is interpolated into shell source; fixed hash is hex only.

    Hash the exact ZIP before extraction and the manifest files afterwards.
    Existing reparse points under the install destination are rejected so a
    controlled program filename cannot overwrite a redirected user location.
    """
    if not re.fullmatch(r"[0-9a-f]{64}", payload_sha256):
        raise ValueError("Expected a lowercase SHA256 payload digest")
    return (
        "$ErrorActionPreference='Stop'; "
        "if((Get-FileHash -LiteralPath $env:CZSC_SETUP_ZIP -Algorithm SHA256).Hash "
        f"-ine '{payload_sha256}'){{throw 'Payload checksum mismatch'}}; "
        "$dest=[IO.Path]::GetFullPath($env:CZSC_SETUP_DEST); "
        "function CheckDestination([string]$p){while($p.Length -ge $dest.Length){"
        "if(Test-Path -LiteralPath $p){$item=Get-Item -LiteralPath $p -Force; "
        "if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)"
        "{throw 'Reparse point in installation destination'}}; "
        "if($p -eq $dest){break}; $parent=[IO.Path]::GetDirectoryName($p); "
        "if([string]::IsNullOrEmpty($parent) -or $parent -eq $p){break}; $p=$parent}}; "
        "CheckDestination $dest; "
        "Add-Type -AssemblyName System.IO.Compression.FileSystem; "
        "$archive=[IO.Compression.ZipFile]::OpenRead($env:CZSC_SETUP_ZIP); "
        "try{foreach($entry in $archive.Entries){"
        "$target=[IO.Path]::GetFullPath([IO.Path]::Combine($dest,$entry.FullName)); "
        "if(-not $target.StartsWith($dest+[IO.Path]::DirectorySeparatorChar,"
        "[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe extraction target'}; "
        "CheckDestination $target}}finally{$archive.Dispose()}; "
        "Expand-Archive -LiteralPath $env:CZSC_SETUP_ZIP -DestinationPath $dest -Force; "
        f"$root=Join-Path $dest '{PRODUCT_ROOT}'; "
        "Get-Content -LiteralPath (Join-Path $root 'SHA256SUMS.txt') | ForEach-Object {"
        "if($_ -notmatch '^([0-9a-f]{64})  (.+)$'){throw 'Invalid installed manifest'}; "
        "$expected=$Matches[1]; $path=Join-Path $root $Matches[2]; "
        "if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $expected)"
        "{throw 'Installed file checksum mismatch'}}; "
        "try{$desktop=[Environment]::GetFolderPath('Desktop'); "
        "$link=Join-Path $desktop 'CZSC量化工具.lnk'; "
        "if($desktop -and (Test-Path -LiteralPath $desktop) -and "
        "-not (Test-Path -LiteralPath $link)){"
        "$shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut($link); "
        "$shortcut.TargetPath=Join-Path $root 'INSTALL_AND_RUN.cmd'; "
        "$shortcut.WorkingDirectory=$root; $shortcut.Description='CZSC paper quant and chart tool'; "
        "$shortcut.Save()}}catch{Write-Warning 'Desktop shortcut unavailable; use INSTALL_AND_RUN.cmd in the install folder'}"
    )


def compile_bootstrap(directory: Path, payload_sha256: str) -> bytes:
    import ziglang
    root = Path(__file__).resolve().parent
    directory.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env.setdefault("ZIG_GLOBAL_CACHE_DIR", str(root / "build" / "zig-global-cache"))
    env.setdefault("ZIG_LOCAL_CACHE_DIR", str(root / "build" / "zig-local-cache"))
    zig = [sys.executable, "-m", "ziglang"]
    definition = directory / "kernel32.def"
    definition.write_text("LIBRARY KERNEL32.dll\nEXPORTS\n" + "\n".join(
        f"{name}@{size}" for name, size in KERNEL_FUNCTIONS.items()) + "\n", encoding="ascii")
    library = directory / "kernel32.lib"
    subprocess.run(zig + ["dlltool", "-d", str(definition), "-l", str(library),
                          "-m", "i386", "-k"], env=env, check=True)
    executable = directory / "setup-bootstrap.exe"
    command = ' -NoProfile -NonInteractive -Command "' + powershell_script(payload_sha256) + '"'
    (directory / "payload_config.h").write_text(
        "#define CZSC_SETUP_COMMAND L" + json.dumps(command) + "\n", encoding="ascii")
    headers = Path(ziglang.__file__).parent / "lib/libc/include/any-windows-any"
    subprocess.run(zig + ["cc", "-target", "x86-windows-gnu", "-O2", "-std=c11",
        "-Wall", "-Wextra", "-Werror", "-ffreestanding", "-fno-builtin",
        "-fno-stack-protector", "-nostdlib", "-isystem", str(headers), "-I", str(directory),
        "-Wl,--entry,mainCRTStartup", "-Wl,--subsystem,console",
        str(root / "setup_bootstrap.c"), str(library), "-o", str(executable)], env=env, check=True)
    binary = executable.read_bytes()
    inspect_pe(binary)
    return binary


def build_installer(payload_path: Path, output: Path) -> dict[str, object]:
    if payload_path.stat().st_size > MAX_PAYLOAD:
        raise ValueError("Payload exceeds 64 MiB")
    payload = payload_path.read_bytes()
    files = validate_payload(payload)
    # Never replace a reviewed artifact or overwrite the source payload.
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="czsc-installer-", dir=output.parent) as temporary:
        bootstrap = compile_bootstrap(Path(temporary), hashlib.sha256(payload).hexdigest())
        container = bootstrap + payload + TRAILER.pack(MAGIC, len(bootstrap), len(payload))
        if extract_payload(container) != payload:
            raise ValueError("Post-build payload verification failed")
        with output.open("xb") as stream:
            stream.write(container)
    return {**inspect_pe(bootstrap), "output": str(output), "files": len(files) + 1,
            "bootstrap_size": len(bootstrap), "size": len(container),
            "payload_offset": len(bootstrap), "payload_size": len(payload),
            "payload_sha256": hashlib.sha256(payload).hexdigest(),
            "installer_sha256": hashlib.sha256(container).hexdigest()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", required=True, type=Path, help="ZIP from make_package.py")
    parser.add_argument("--output", required=True, type=Path, help="new .exe path (never overwritten)")
    args = parser.parse_args()
    try:
        result = build_installer(args.payload, args.output)
    except (OSError, ValueError, subprocess.CalledProcessError, ImportError) as error:
        parser.exit(1, f"Installer build failed: {error}\n")
    for key, value in result.items():
        print(f"{key}: {value}")
    print("Built and statically checked. Windows installation and GUI launch still require Windows testing.")


if __name__ == "__main__":
    main()
