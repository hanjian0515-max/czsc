"""Original-CZSC -> real C reader integration; synthetic bars, not live quotes."""
import ctypes as ct
from datetime import datetime, timedelta
import math
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest

from export_czsc import HEADER, RECORD
from make_formulas import MAIN, warning
from run_bridge import refresh
from windows_launcher import pe_arch


class PipelineTests(unittest.TestCase):
    def test_mismatched_local_source_identity_cannot_overwrite_another_security(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cache = root/"1600000_1.bin"
            cache.write_bytes(b"previous-cache")
            for source in (root/"sz000001.lc5", root/"unknown.lc5", root/"sh600000.day"):
                with self.assertRaises(ValueError):
                    refresh(source, root, "600000", "sh", "5m")
                self.assertEqual(cache.read_bytes(), b"previous-cache")

    def test_csv_native_engine_binary_real_c_reader_and_no_historical_alarm(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "synthetic.csv"
            lines = ["Datetime,Open,High,Low,Close,Volume"]
            start = datetime(2024, 1, 2, 9, 35)
            for i in range(240):
                stamp = start+timedelta(minutes=5*i)
                p = 100+10*math.sin(i*math.pi/15)
                lines.append(f"{stamp.isoformat()},{p},{p+1},{p-1},{p},100")
            source.write_text("\n".join(lines), encoding="utf-8")
            meta = refresh(source, root, "600000", "sh", "5m")
            self.assertGreater(meta["native_bis"], 5)
            self.assertGreater(meta["up_events"]+meta["down_events"], 0)
            binary = root / "1600000_1.bin"
            blob = binary.read_bytes()
            rows = list(RECORD.iter_unpack(blob[HEADER.size:]))
            library = root / "bridge.so"
            subprocess.run(["gcc", "-std=c11", "-shared", "-fPIC", str(Path(__file__).with_name("czsc_bridge.c")), "-lm", "-o", str(library)], check=True)
            reader = ct.CDLL(str(library))
            reader.CZSC_SetTestDirectory.argtypes = [ct.c_char_p]
            reader.CZSC_SetTestDirectory(str(root).encode())
            pfloat = ct.POINTER(ct.c_float)
            reader.CZSC_BridgeRead.argtypes = [ct.c_int, ct.c_int, pfloat, pfloat, pfloat, pfloat]
            n = len(rows)
            array = ct.c_float*n
            dates, times, keys = array(*[r[0] for r in rows]), array(*[10000+r[1] for r in rows]), array(*([1600000]*n))
            def read(field):
                output = array()
                reader.CZSC_BridgeRead(field, n, output, dates, times, keys)
                return list(output)
            self.assertEqual(read(1), [r[3] for r in rows])
            self.assertEqual(read(2), [r[4] for r in rows])
            self.assertEqual(read(3), [r[5] for r in rows])
            self.assertEqual(read(4), [r[6] for r in rows])
            self.assertEqual(read(5), [0]*n)
            self.assertEqual(read(6), [0]*n)
            self.assertEqual(read(7), [0]*n)
            self.assertEqual(read(9), [float(bool(r[7]&1)) for r in rows])
            self.assertEqual(read(10), [float(bool(r[7]&2)) for r in rows])

    def test_pe_process_architecture_instead_of_os_bitness(self):
        with tempfile.TemporaryDirectory() as directory:
            exe = Path(directory)/"terminal.exe"
            for machine, expected in ((0x14c, "x86"), (0x8664, "x64")):
                data = bytearray(256)
                data[:2] = b"MZ"
                data[0x3c:0x40] = struct.pack("<I", 128)
                data[128:134] = b"PE\0\0"+struct.pack("<H", machine)
                exe.write_bytes(data)
                self.assertEqual(pe_arch(exe), expected)
            exe.write_bytes(b"not an executable")
            with self.assertRaises(ValueError):
                pe_arch(exe)

    def test_warning_formulas_do_not_depend_on_retrospective_drawings(self):
        for text in (warning(5), warning(6)):
            for forbidden in ("DRAWLINE", "BACKSET", "ZIG(", "PEAK(", "TROUGH(", "FILTERX", "TDXDLL1(9", "TDXDLL1(10"):
                self.assertNotIn(forbidden, text)
            self.assertIn("REF(EV0,1)>0", text)
            self.assertIn("REF(RD0,1)>0", text)
            self.assertIn("REF(MATCH0,1)", text)
            self.assertIn("1000000*SETCODE", text)
            self.assertIn("TQFLAG=0", text)
        self.assertIn("DRAWLINE", MAIN)
        self.assertIn("TDXDLL1(9", MAIN)


if __name__ == "__main__":
    unittest.main()
