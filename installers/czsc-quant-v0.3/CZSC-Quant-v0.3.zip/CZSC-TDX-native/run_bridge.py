"""Watch an existing local source and refresh the original-CZSC DLL cache.

No network or account APIs. Source freshness depends on the quote client.
"""
import argparse
from dataclasses import fields
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import re
import time

from export_czsc import Candle, build_cache, read_csv, write_atomic, instrument_key, PERIODS
from tdx_local import convert_local
from visual_export import visual_cache


def refresh(source, output_dir, code, market, period):
    source, output_dir = Path(source), Path(output_dir)
    now = datetime.now(timezone.utc)
    skipped = 0
    if source.suffix.lower() in (".lc5", ".day"):
        identity = re.fullmatch(r"(sh|sz)([0-9]{6})\.(lc5|day)", source.name.lower())
        if not identity or (identity.group(1), identity.group(2)) != (market, code):
            raise ValueError("Local source filename must match the declared market and six-digit code")
        local, skipped = convert_local(source, "day" if period == "daily" else period, now=now)
        candles = [Candle(**{f.name: getattr(b, f.name) for f in fields(Candle)}) for b in local]
    else:
        candles = read_csv(source, period, now=now)
    payload, metadata = build_cache(candles, code, market, period, now=now)
    visual_payload, visual_metadata = visual_cache(candles, code, market, period, now=now)
    destination = output_dir / f"{instrument_key(code, market)}_{PERIODS[period][0]}.bin"
    visual_destination = output_dir / visual_metadata["filename"]
    write_atomic(visual_destination, visual_payload)
    write_atomic(destination, payload)
    metadata.update({"output": str(destination), "incomplete_30m_groups_skipped": skipped,
                     "visual_output": str(visual_destination),
                     "visual_metadata": visual_metadata,
                     "source": str(source), "source_is_live": False,
                     "notice": "Existing local source only; its latest timestamp determines alarm freshness. No order API."})
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--code", required=True)
    parser.add_argument("--market", choices=("sh", "sz"), required=True)
    parser.add_argument("--period", choices=PERIODS, required=True)
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=float, default=5)
    args = parser.parse_args()
    if not math.isfinite(args.interval) or args.interval < 1:
        parser.error("--interval must be at least one second")
    try:
        while True:
            try:
                result = refresh(args.source, args.output_dir, args.code, args.market, args.period)
                print(json.dumps(result, ensure_ascii=False), flush=True)
            except (OSError, ValueError, RuntimeError) as error:
                print(json.dumps({"error": str(error), "cache_updated": False}, ensure_ascii=False), flush=True)
                if not args.watch:
                    return 1
            if not args.watch:
                return 0
            time.sleep(args.interval)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
