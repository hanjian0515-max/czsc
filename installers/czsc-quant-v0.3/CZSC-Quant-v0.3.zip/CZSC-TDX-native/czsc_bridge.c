/* Original CZSC runs outside Tongdaxin. This DLL only reads its cache.
 * Public interoperability ABI references are recorded in README.md.
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#ifdef _WIN32
#include <windows.h>
#ifdef CZSC_EXPLICIT_EXPORTS
#define EXPORT
#else
#define EXPORT __declspec(dllexport)
#endif
#else
#define EXPORT __attribute__((visibility("default")))
typedef int BOOL;
#define TRUE 1
#define FALSE 0
static char test_directory[2048] = ".";
EXPORT void CZSC_SetTestDirectory(const char *path) {
    if (path && strlen(path) < sizeof(test_directory)) strcpy(test_directory, path);
}
#endif

#pragma pack(push, 1)
typedef void (*TdxCallback)(int, float *, float *, float *, float *);
typedef struct { uint16_t id; TdxCallback function; } TdxFunction;
typedef struct {
    char magic[8];
    uint32_t version, period, instrument, count;
    uint64_t generated_at, newest_end;
} CacheHeader;
typedef struct {
    uint32_t date, minute;
    float close, endpoint, kind, zg, zd;
    uint32_t flags;
} CacheRecord;
typedef struct {
    uint32_t date, minute;
    float value[18];
} VisualRecord;
#pragma pack(pop)

_Static_assert(sizeof(CacheHeader) == 40, "Cache header packing mismatch");
_Static_assert(sizeof(CacheRecord) == 32, "Cache record packing mismatch");
_Static_assert(sizeof(VisualRecord) == 80, "Visual record packing mismatch");
_Static_assert(sizeof(TdxFunction) == 2 + sizeof(void *), "TDX ABI packing mismatch");

EXPORT BOOL RegisterTdxFunc(TdxFunction **functions);

static int bridge_finite(float value) {
    union { float f; uint32_t bits; } bits;
    bits.f = value;
    return (bits.bits & 0x7f800000U) != 0x7f800000U;
}

static void *bridge_allocate(size_t size) {
#ifdef _WIN32
    return HeapAlloc(GetProcessHeap(), 0, size);
#else
    return malloc(size);
#endif
}

static void bridge_free(void *pointer) {
#ifdef _WIN32
    if (pointer) HeapFree(GetProcessHeap(), 0, pointer);
#else
    free(pointer);
#endif
}

static uint64_t bridge_now(void) {
#ifdef _WIN32
    FILETIME stamp;
    GetSystemTimeAsFileTime(&stamp);
    uint64_t ticks = ((uint64_t)stamp.dwHighDateTime << 32) | stamp.dwLowDateTime;
    return ticks/10000000ULL - 11644473600ULL;
#else
    return (uint64_t)time(NULL);
#endif
}

#ifdef _WIN32
/* No CRT initialization or runtime DLLs are required by the Windows bridge. */
DWORD _tls_index; /* Linker-required symbol; this module has no TLS variables. */
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)instance; (void)reason; (void)reserved;
    return TRUE;
}

static wchar_t *append_number(wchar_t *out, uint32_t value) {
    wchar_t reversed[12];
    unsigned count = 0;
    do { reversed[count++] = (wchar_t)(L'0' + value%10); value /= 10; } while (value);
    while (count) *out++ = reversed[--count];
    return out;
}
#endif

static int integer_input(float value, uint32_t *out) {
    if (!bridge_finite(value) || value < 0 || value > 3000000 || (float)(uint32_t)value != value) return 0;
    *out = (uint32_t)value;
    return 1;
}

static unsigned char *read_cache(uint32_t key, uint32_t period, size_t *length, int visual) {
    unsigned char *bytes = NULL;
#ifdef _WIN32
    HMODULE module = NULL;
    wchar_t path[32768];
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            (LPCWSTR)(uintptr_t)&RegisterTdxFunc, &module)) return NULL;
    DWORD n = GetModuleFileNameW(module, path, 32000);
    if (!n || n >= 32000) return NULL;
    wchar_t *slash = NULL;
    for (DWORD i = 0; i < n; ++i) if (path[i] == L'\\') slash = path+i;
    if (!slash) return NULL;
    wchar_t *out = slash;
    const wchar_t *suffix = L"\\czsc_data\\";
    while (*suffix) *out++ = *suffix++;
    out = append_number(out, key);
    *out++ = L'_';
    out = append_number(out, period);
    if (visual) {
        const wchar_t *extra = L"_visual";
        while (*extra) *out++ = *extra++;
    }
    *out++ = L'.'; *out++ = L'b'; *out++ = L'i'; *out++ = L'n'; *out = 0;
    HANDLE file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                              NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) return NULL;
    LARGE_INTEGER size;
    if (!GetFileSizeEx(file, &size) || size.QuadPart < 40 || size.QuadPart > (visual ? 20000040 : 8000040)) {
        CloseHandle(file); return NULL;
    }
    *length = (size_t)size.QuadPart;
    bytes = (unsigned char *)bridge_allocate(*length);
    DWORD got = 0;
    if (!bytes || !ReadFile(file, bytes, (DWORD)*length, &got, NULL) || got != *length) {
        bridge_free(bytes); bytes = NULL;
    }
    CloseHandle(file);
#else
    char path[2200];
    snprintf(path, sizeof(path), "%s/%u_%u%s.bin", test_directory, key, period, visual ? "_visual" : "");
    FILE *file = fopen(path, "rb");
    if (!file) return NULL;
    if (fseek(file, 0, SEEK_END)) { fclose(file); return NULL; }
    long size = ftell(file);
    if (size < 40 || size > (visual ? 20000040 : 8000040) || fseek(file, 0, SEEK_SET)) { fclose(file); return NULL; }
    *length = (size_t)size;
    bytes = (unsigned char *)bridge_allocate(*length);
    if (!bytes || fread(bytes, 1, *length, file) != *length) { bridge_free(bytes); bytes = NULL; }
    fclose(file);
#endif
    return bytes;
}

static int64_t record_epoch(const CacheRecord *r, uint32_t period) {
    int y = (int)(r->date/10000) + 1900;
    unsigned m = (r->date%10000)/100, d = r->date%100;
    static const unsigned month_days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (y < 1970 || y > 2199 || m < 1 || m > 12 || d < 1) return -1;
    unsigned limit = month_days[m-1] + (m == 2 && y%4 == 0 && (y%100 != 0 || y%400 == 0));
    if (d > limit) return -1;
    unsigned minute = period == 5 ? 1500 : r->minute;
    if (minute > 2359 || minute%100 >= 60) return -1;
    /* Gregorian civil day conversion, followed by Shanghai fixed UTC+8. */
    y -= m <= 2;
    int era = (y >= 0 ? y : y-399)/400;
    unsigned yoe = (unsigned)(y-era*400);
    unsigned doy = (153*(m > 2 ? m-3 : m+9)+2)/5+d-1;
    unsigned doe = yoe*365+yoe/4-yoe/100+doy;
    int64_t days = (int64_t)era*146097+doe-719468;
    return days*86400 + (minute/100)*3600 + (minute%100)*60 - 8*3600;
}

static int valid_cache(CacheHeader *h, CacheRecord *rows, size_t length, uint32_t key, uint32_t period) {
    const char expected_magic[8] = {'C','Z','T','D','X','0','1',0};
    for (unsigned i = 0; i < 8; ++i) if (h->magic[i] != expected_magic[i]) return 0;
    if (h->version != 1 || h->instrument != key || h->period != period ||
        !h->count || h->count > 250000 || length != 40 + (size_t)h->count*32) return 0;
    for (uint32_t i = 0; i < h->count; ++i) {
        CacheRecord *r = rows+i;
        if (record_epoch(r, period) < 0 || r->date > 3000000 || r->minute > 2359 || r->minute%100 >= 60 ||
            (period == 5 && r->minute != 0) || !bridge_finite(r->close) || r->close <= 0 ||
            !bridge_finite(r->endpoint) || r->endpoint < 0 || !bridge_finite(r->kind) ||
            (r->kind != 0 && r->kind != 1 && r->kind != -1) ||
            (r->kind != 0 && r->endpoint <= 0) || (r->kind == 0 && r->endpoint != 0) ||
            !bridge_finite(r->zg) || !bridge_finite(r->zd) ||
            !((r->zg == 0 && r->zd == 0) || (r->zg >= r->zd && r->zd > 0)) || r->flags > 2) return 0;
        if (i && (rows[i-1].date > r->date || (rows[i-1].date == r->date && rows[i-1].minute >= r->minute))) return 0;
    }
    return (uint64_t)record_epoch(rows+h->count-1, period) == h->newest_end;
}

static const CacheRecord *lookup(const CacheRecord *rows, uint32_t count, uint32_t date, uint32_t minute) {
    uint32_t lo = 0, hi = count;
    while (lo < hi) {
        uint32_t mid = lo + (hi-lo)/2;
        if (rows[mid].date < date || (rows[mid].date == date && rows[mid].minute < minute)) lo = mid+1;
        else hi = mid;
    }
    if (lo < count && rows[lo].date == date && rows[lo].minute == minute) return rows+lo;
    return NULL;
}

static int valid_visual(CacheHeader *h, VisualRecord *rows, size_t length, uint32_t key, uint32_t period) {
    const char magic[8] = {'C','Z','T','D','V','0','2',0};
    for (unsigned i = 0; i < 8; ++i) if (h->magic[i] != magic[i]) return 0;
    if (h->version != 2 || h->period != period || h->instrument != key || !h->count ||
        h->count > 250000 || length != 40+(size_t)h->count*80) return 0;
    for (uint32_t i = 0; i < h->count; ++i) {
        VisualRecord *r = rows+i;
        CacheRecord clock = {0}; clock.date = r->date; clock.minute = r->minute;
        if (record_epoch(&clock, period) < 0 || (period == 5 && r->minute != 0)) return 0;
        if (i && (rows[i-1].date > r->date || (rows[i-1].date == r->date && rows[i-1].minute >= r->minute))) return 0;
        for (unsigned j = 0; j < 18; ++j) if (!bridge_finite(r->value[j])) return 0;
        for (unsigned j = 0; j < 4; j += 2) {
            if (r->value[j] < 0 || (r->value[j+1] != 0 && r->value[j+1] != 1 && r->value[j+1] != -1) ||
                (r->value[j+1] == 0 && r->value[j] != 0) || (r->value[j+1] != 0 && r->value[j] <= 0)) return 0;
        }
        if (r->value[6] < 0 || r->value[6] > 250000 || (float)(uint32_t)r->value[6] != r->value[6]) return 0;
        if (!((r->value[4] == 0 && r->value[5] == 0 && r->value[6] == 0) ||
              (r->value[4] >= r->value[5] && r->value[5] > 0 && r->value[6] > 0))) return 0;
        for (unsigned j = 7; j <= 9; ++j) if (r->value[j] != 0 && r->value[j] != 1) return 0;
        for (unsigned j = 10; j <= 15; ++j) if (r->value[j] < 0) return 0;
        for (unsigned j = 16; j < 18; ++j) {
            if ((r->value[j] != 0 && r->value[j] != 1) || (r->value[j] > 0 && r->value[6] <= 0)) return 0;
        }
    }
    CacheRecord clock = {0}; clock.date = rows[h->count-1].date; clock.minute = rows[h->count-1].minute;
    return (uint64_t)record_epoch(&clock, period) == h->newest_end;
}

static void read_visual(int field, int n, float *out, float *a, float *b, float *c, uint32_t key, uint32_t period) {
    size_t length = 0;
    unsigned char *bytes = read_cache(key, period, &length, 1);
    if (!bytes) return;
    CacheHeader *h = (CacheHeader *)bytes;
    VisualRecord *rows = (VisualRecord *)(bytes+40);
    if (!valid_visual(h, rows, length, key, period)) { bridge_free(bytes); return; }
    uint64_t now = bridge_now();
    int fresh = h->generated_at <= now && now-h->generated_at <= 15 && h->newest_end <= now && now-h->newest_end <= 90;
    for (int i = 0; i < n; ++i) {
        uint32_t date, packed, row_key;
        if (!integer_input(a[i], &date) || !integer_input(b[i], &packed) || !integer_input(c[i], &row_key) ||
            row_key != key || packed/10000 != period) continue;
        uint32_t minute = period == 5 ? 0 : packed%10000;
        uint32_t lo = 0, hi = h->count;
        while (lo < hi) {
            uint32_t mid = lo+(hi-lo)/2;
            if (rows[mid].date < date || (rows[mid].date == date && rows[mid].minute < minute)) lo = mid+1;
            else hi = mid;
        }
        if (lo >= h->count || rows[lo].date != date || rows[lo].minute != minute) continue;
        if (field >= 11 && field <= 28) out[i] = rows[lo].value[field-11];
        else if (field >= 29 && field <= 31 && fresh && lo == h->count-1) out[i] = rows[lo].value[field-22];
    }
    bridge_free(bytes);
}

/* A=DATE, B=TIME+10000*PERIOD (daily minute normalized to zero),
 * C=instrument key. Formula generation supplies a symbol guard as well.
 * 1..4: retrospective drawing; 5..7: latest/fresh alerts only;
 * 8: source close; 9..10: historical causal confirmation markers.
 */
EXPORT void CZSC_BridgeRead(int field, int n, float *out, float *a, float *b, float *c) {
    if (!out || n <= 0 || n > 1000000) return;
    volatile float *zero = out;
    for (int i = 0; i < n; ++i) zero[i] = 0;
    if (!a || !b || !c) return;
    uint32_t key, packed;
    if (!integer_input(c[n-1], &key) || !integer_input(b[n-1], &packed)) return;
    uint32_t period = packed/10000;
    if ((period != 1 && period != 3 && period != 5) || key > 2999999) return;
    if (field >= 11 && field <= 31) { read_visual(field,n,out,a,b,c,key,period); return; }
    size_t length = 0;
    unsigned char *bytes = read_cache(key, period, &length, 0);
    if (!bytes) return;
    CacheHeader *h = (CacheHeader *)bytes;
    CacheRecord *rows = (CacheRecord *)(bytes+40);
    if (!valid_cache(h, rows, length, key, period)) { bridge_free(bytes); return; }
    uint64_t now = bridge_now();
    int fresh = h->generated_at <= now && now-h->generated_at <= 15 &&
                h->newest_end <= now && now-h->newest_end <= 90;
    for (int i = 0; i < n; ++i) {
        uint32_t date, value, row_key;
        if (!integer_input(a[i], &date) || !integer_input(b[i], &value) || !integer_input(c[i], &row_key) ||
            row_key != key || value/10000 != period) continue;
        uint32_t minute = period == 5 ? 0 : value%10000;
        const CacheRecord *r = lookup(rows, h->count, date, minute);
        if (!r) continue;
        int latest = r == rows+h->count-1;
        switch (field) {
            case 1: out[i] = r->endpoint; break;
            case 2: out[i] = r->kind; break;
            case 3: out[i] = r->zg; break;
            case 4: out[i] = r->zd; break;
            case 5: out[i] = fresh && latest && (r->flags & 1) ? 1 : 0; break;
            case 6: out[i] = fresh && latest && (r->flags & 2) ? 1 : 0; break;
            case 7: out[i] = fresh && latest ? 1 : 0; break;
            case 8: out[i] = r->close; break;
            case 9: out[i] = r->flags & 1 ? 1 : 0; break;
            case 10: out[i] = r->flags & 2 ? 1 : 0; break;
        }
    }
    bridge_free(bytes);
}

#define CZSC_CALLBACK(id) static void call##id(int n,float *o,float *a,float *b,float *c) { CZSC_BridgeRead(id,n,o,a,b,c); }
CZSC_CALLBACK(1) CZSC_CALLBACK(2) CZSC_CALLBACK(3) CZSC_CALLBACK(4) CZSC_CALLBACK(5)
CZSC_CALLBACK(6) CZSC_CALLBACK(7) CZSC_CALLBACK(8) CZSC_CALLBACK(9) CZSC_CALLBACK(10)
CZSC_CALLBACK(11) CZSC_CALLBACK(12) CZSC_CALLBACK(13) CZSC_CALLBACK(14) CZSC_CALLBACK(15)
CZSC_CALLBACK(16) CZSC_CALLBACK(17) CZSC_CALLBACK(18) CZSC_CALLBACK(19) CZSC_CALLBACK(20)
CZSC_CALLBACK(21) CZSC_CALLBACK(22) CZSC_CALLBACK(23) CZSC_CALLBACK(24) CZSC_CALLBACK(25)
CZSC_CALLBACK(26) CZSC_CALLBACK(27) CZSC_CALLBACK(28) CZSC_CALLBACK(29) CZSC_CALLBACK(30) CZSC_CALLBACK(31)
static TdxFunction table[] = {
    {1,call1},{2,call2},{3,call3},{4,call4},{5,call5},
    {6,call6},{7,call7},{8,call8},{9,call9},{10,call10},
    {11,call11},{12,call12},{13,call13},{14,call14},{15,call15},
    {16,call16},{17,call17},{18,call18},{19,call19},{20,call20},
    {21,call21},{22,call22},{23,call23},{24,call24},{25,call25},
    {26,call26},{27,call27},{28,call28},{29,call29},{30,call30},{31,call31},{0,NULL}
};
EXPORT BOOL RegisterTdxFunc(TdxFunction **functions) {
    if (!functions || *functions) return FALSE;
    *functions = table;
    return TRUE;
}
