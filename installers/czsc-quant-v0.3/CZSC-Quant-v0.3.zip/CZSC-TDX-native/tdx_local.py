"""Read-only TongDaXin .lc5/.day -> closed-bar CSV adapter for CZSC.

Binary layouts are verified against rainx/pytdx's lc_min_bar_reader.py and
daily_bar_reader.py. This supports mainland-equity sessions, not arbitrary
international/futures calendars. Existing client files may be stale.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import io
import math
import os
from pathlib import Path
import re
import struct
import sys
import tempfile
import time

SHANGHAI = timezone(timedelta(hours=8))
LC5_RECORD = struct.Struct("<HHfffffII")
DAY_RECORD = struct.Struct("<IIIIIfII")
CSV_HEADER = ("Datetime", "Open", "High", "Low", "Close", "Volume")
SOURCE_LC5 = "https://github.com/rainx/pytdx/blob/master/pytdx/reader/lc_min_bar_reader.py"
SOURCE_DAY = "https://github.com/rainx/pytdx/blob/master/pytdx/reader/daily_bar_reader.py"


@dataclass(frozen=True)
class LocalBar:
    """Unadjusted source bar; end is a naive Asia/Shanghai closing timestamp."""

    end: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int


def local_now(value: datetime | None = None) -> datetime:
    value = datetime.now(SHANGHAI) if value is None else value
    return value.astimezone(SHANGHAI).replace(tzinfo=None) if value.tzinfo else value


def _read_snapshot(path: Path, layout: struct.Struct) -> bytes:
    with path.open("rb") as file:
        before = os.fstat(file.fileno())
        content = file.read()
        after = os.fstat(file.fileno())
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("Source changed during read; retry after the client finishes writing")
    if not content or len(content) % layout.size:
        raise ValueError(f"Empty/partial source: expected a nonempty multiple of {layout.size} bytes")
    if len(content) != before.st_size:
        raise ValueError("Source length changed during read")
    return content


def _validate_bar(bar: LocalBar, amount: float) -> None:
    if not all(math.isfinite(v) for v in (bar.open, bar.high, bar.low, bar.close, amount)):
        raise ValueError("Nonfinite OHLC/amount")
    if not (0 < bar.low <= min(bar.open, bar.close) <= max(bar.open, bar.close) <= bar.high):
        raise ValueError("Invalid source OHLC")
    if amount < 0 or bar.volume < 0:
        raise ValueError("Negative source volume/amount")


def _validate_order(bars: list[LocalBar]) -> None:
    if any(a.end >= b.end for a, b in zip(bars, bars[1:])):
        raise ValueError("Duplicate or unordered source timestamps")


def _session_start(minute: int) -> int:
    # Input stamps are bar END times: 09:35..11:30 and 13:05..15:00.
    for start, finish in ((570, 690), (780, 900)):
        if start < minute <= finish and (minute - start) % 5 == 0:
            return start
    raise ValueError("Not a mainland-equity 5-minute closing timestamp")


def read_lc5(path: str | Path, *, now: datetime | None = None) -> list[LocalBar]:
    """Parse float-price .lc5 records, validate all records, return only closed bars.

    Old integer-price .5 files use another pytdx reader and are not accepted.
    Volume is retained as its raw integer (LC5 documentation calls this shares).
    """
    cutoff = local_now(now)
    bars = []
    for packed_date, minutes, op, hi, lo, close, amount, volume, _ in LC5_RECORD.iter_unpack(_read_snapshot(Path(path), LC5_RECORD)):
        year = packed_date // 2048 + 2004
        month, day = divmod(packed_date % 2048, 100)
        if not 0 <= minutes < 1440:
            raise ValueError("Invalid source minute-of-day")
        _session_start(minutes)
        stamp = datetime(year, month, day, minutes // 60, minutes % 60)
        bar = LocalBar(stamp, op, hi, lo, close, volume)
        _validate_bar(bar, amount)
        bars.append(bar)
    _validate_order(bars)
    return [bar for bar in bars if bar.end <= cutoff]


def infer_daily_scale(path: str | Path) -> float:
    """Only infer classes explicitly verified in the source reader.

    A-stock/index prices use 0.01. Other classes differ; require an explicit
    scale instead of silently treating a fund/bond/B-share as A-stock.
    """
    name = Path(path).name.lower()
    match = re.fullmatch(r"(sh|sz)(\d{6})\.day", name)
    if not match:
        raise ValueError("Cannot infer daily price scale; use --price-scale explicitly")
    market, code = match.groups()
    allowed = ((market == "sh" and code[:2] in ("60", "68", "00", "88", "99")) or
               (market == "sz" and code[:2] in ("00", "30", "39")))
    if not allowed:
        raise ValueError("Daily security class has no default scale; use --price-scale explicitly")
    return .01


def read_day(path: str | Path, *, now: datetime | None = None, price_scale: float | None = None) -> list[LocalBar]:
    """Parse unadjusted daily records with a 15:00 local closing timestamp."""
    scale = infer_daily_scale(path) if price_scale is None else price_scale
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError("Daily price scale must be finite and positive")
    cutoff, bars = local_now(now), []
    for day, op, hi, lo, close, amount, volume, _ in DAY_RECORD.iter_unpack(_read_snapshot(Path(path), DAY_RECORD)):
        stamp = datetime(day // 10000, day // 100 % 100, day % 100, 15)
        bar = LocalBar(stamp, op*scale, hi*scale, lo*scale, close*scale, volume)
        _validate_bar(bar, amount)
        bars.append(bar)
    _validate_order(bars)
    return [bar for bar in bars if bar.end <= cutoff]


def aggregate_30m(bars: list[LocalBar]) -> tuple[list[LocalBar], int]:
    """Aggregate six exact 5m closes within one session; skip incomplete buckets.

    Returns (bars, skipped_bucket_count). No lunch/overnight/holiday filling.
    """
    _validate_order(bars)
    groups: dict[datetime, list[LocalBar]] = {}
    for bar in bars:
        if bar.end.second or bar.end.microsecond:
            raise ValueError("Input 5m bar has sub-minute timestamp")
        minute = bar.end.hour*60 + bar.end.minute
        start = _session_start(minute)
        finish = start + ((minute - start + 29)//30)*30
        key = bar.end.replace(hour=finish//60, minute=finish % 60)
        groups.setdefault(key, []).append(bar)
    result, skipped = [], 0
    for end, members in groups.items():
        expected = [end-timedelta(minutes=n) for n in (25, 20, 15, 10, 5, 0)]
        if [bar.end for bar in members] != expected:
            skipped += 1
            continue
        result.append(LocalBar(end, members[0].open, max(b.high for b in members),
                               min(b.low for b in members), members[-1].close,
                               sum(b.volume for b in members)))
    return result, skipped


def convert_local(path: str | Path, period: str, *, now: datetime | None = None,
                  price_scale: float | None = None) -> tuple[list[LocalBar], int]:
    path = Path(path)
    if period == "day":
        if path.suffix.lower() != ".day":
            raise ValueError("day conversion requires a .day file")
        return read_day(path, now=now, price_scale=price_scale), 0
    if period not in ("5m", "30m") or path.suffix.lower() != ".lc5":
        raise ValueError("5m/30m conversion requires a float-price .lc5 file")
    if price_scale is not None:
        raise ValueError("--price-scale applies to .day files only")
    bars = read_lc5(path, now=now)
    return (bars, 0) if period == "5m" else aggregate_30m(bars)


def write_csv_atomic(path: str | Path, bars: list[LocalBar], *, replace: bool = False) -> bool:
    """Write generated CSV atomically; do not overwrite an unknown file by default.

    Returns False when an explicitly replaceable file already has identical data.
    """
    target = Path(path)
    if not bars:
        raise ValueError("No completed bars; previous output is preserved")
    stream = io.StringIO(newline="")
    writer = csv.writer(stream)
    writer.writerow(CSV_HEADER)
    for bar in bars:
        writer.writerow((bar.end.strftime("%Y-%m-%d %H:%M:%S"), bar.open, bar.high,
                         bar.low, bar.close, bar.volume))
    payload = stream.getvalue().encode("utf-8")
    if target.exists():
        if not replace:
            raise FileExistsError("Output exists; choose a new path or explicitly use --replace-existing")
        if target.read_bytes() == payload:
            return False
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_name = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=target.name+".", suffix=".tmp", delete=False) as file:
            tmp_name = file.name
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        # The explicit --output location is owned only after the initial success.
        os.replace(tmp_name, target)
        tmp_name = None
    finally:
        if tmp_name:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass
    return True


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--period", choices=("5m", "30m", "day"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--price-scale", type=float)
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=float, default=2)
    parser.add_argument("--replace-existing", action="store_true",
                        help="Explicitly permit replacing the selected generated CSV")
    args = parser.parse_args(argv)
    if args.input.resolve() == args.output.resolve():
        parser.error("Input and output must be different; source files are read-only")
    if not math.isfinite(args.interval) or args.interval < .25:
        parser.error("--interval must be finite and at least 0.25 seconds")
    if args.output.exists() and not args.replace_existing:
        parser.error("Output exists; choose a new path or use --replace-existing")
    owned_output = args.replace_existing
    try:
        while True:
            try:
                bars, skipped = convert_local(args.input, args.period, price_scale=args.price_scale)
                changed = write_csv_atomic(args.output, bars, replace=owned_output)
                owned_output = True
                if changed:
                    print(f"CSV updated: {args.output}; closed_bars={len(bars)}; incomplete_30m_buckets_skipped={skipped}; last_close_local={bars[-1].end.isoformat()}", flush=True)
            except (OSError, ValueError, struct.error) as error:
                print(f"Local conversion failed; previous output preserved: {error}", file=sys.stderr, flush=True)
                if not args.watch:
                    return 1
            if not args.watch:
                return 0
            time.sleep(args.interval)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
