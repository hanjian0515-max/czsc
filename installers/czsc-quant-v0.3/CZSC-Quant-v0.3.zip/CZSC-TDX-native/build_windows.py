"""Cross-compile real Windows DLLs using ziglang==0.13.0 (isolated build tool)."""
import os
from pathlib import Path
import subprocess
import sys
import ziglang

KERNEL_FUNCTIONS = {"GetModuleHandleExW": 12, "GetModuleFileNameW": 12,
                    "CreateFileW": 28, "GetFileSizeEx": 8, "ReadFile": 20,
                    "CloseHandle": 4, "GetProcessHeap": 0, "HeapAlloc": 12,
                    "HeapFree": 12, "GetSystemTimeAsFileTime": 4,
                    "GetStdHandle": 4, "WriteFile": 20, "SetErrorMode": 4,
                    "LoadLibraryW": 4, "GetProcAddress": 8, "FreeLibrary": 4,
                    "GetLastError": 0, "ExitProcess": 4}


def main():
    root = Path(__file__).resolve().parent
    for arch, target in (("x64", "x86_64-windows-gnu"), ("x86", "x86-windows-gnu")):
        output = root / "build" / arch
        output.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env.setdefault("ZIG_GLOBAL_CACHE_DIR", str(root / "build" / "zig-global-cache"))
        env.setdefault("ZIG_LOCAL_CACHE_DIR", str(root / "build" / "zig-local-cache"))
        zig = [sys.executable, "-m", "ziglang"]
        definition = output / "kernel32.def"
        definition.write_text("LIBRARY KERNEL32.dll\nEXPORTS\n"+"\n".join(
            name+("@"+str(size) if arch == "x86" else "")
            for name, size in KERNEL_FUNCTIONS.items())+"\n")
        library = output / "kernel32.lib"
        subprocess.run(zig+["dlltool", "-d", str(definition), "-l", str(library),
                           "-m", "i386" if arch == "x86" else "i386:x86-64", "-k"],
                       env=env, check=True)
        exports = output / "exports.def"
        exports.write_text("EXPORTS\nRegisterTdxFunc\nCZSC_BridgeRead\n")
        common = zig+["cc", "-target", target, "-O2", "-std=c11", "-Wall", "-Wextra",
                      "-ffreestanding", "-fno-builtin", "-fno-stack-protector", "-nostdlib",
                      "-isystem", str(Path(ziglang.__file__).parent/"lib/libc/include/any-windows-any")]
        entry = "DllMain@12" if arch == "x86" else "DllMain"
        subprocess.run(common+["-shared", "-DCZSC_EXPLICIT_EXPORTS", "-Wl,--entry,"+entry,
                                str(root/"czsc_bridge.c"), str(library), str(exports),
                                "-o", str(output/"CZSCBridge.dll")], env=env, check=True)
        subprocess.run(common+["-Wl,--entry,mainCRTStartup", "-Wl,--subsystem,console",
                                str(root/"check_windows_dll.c"), str(library),
                                "-o", str(output/"CZSCCheck.exe")], env=env, check=True)
        print("Built", output / "CZSCBridge.dll", flush=True)


if __name__ == "__main__":
    main()
