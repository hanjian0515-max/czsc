"""Generate pasteable TDX source, not encrypted .tn6 or compiled formulas.

The visual fields are supplied by the independent sidecar.  They do not turn
the auxiliary lines or divergence candidates into native CZSC signals.  Python
checks can audit the generated text; only the target TDX client can compile it.
"""
from pathlib import Path

COMMON = """{CZSC 1.0.2 external engine; bind CZSCBridge.dll to slot 1}
KEY0:=STR2CON(CODE)+1000000*SETCODE;
TM0:=10000*PERIOD+IF(PERIOD=5,0,TIME);
ALLOW0:=(SETCODE=0 OR SETCODE=1) AND (PERIOD=1 OR PERIOD=3 OR PERIOD=5) AND TQFLAG=0;
SC0:=TDXDLL1(8,DATE,TM0,KEY0);
RD0:=TDXDLL1(7,DATE,TM0,KEY0);
MATCH0:=SC0>0 AND ABS(C-SC0)<=MAX(0.00001,ABS(SC0)*0.00001);
"""

MAIN = COMMON + """
{Edit these constants here; no formula-parameter defaults are required.}
SHOWBI:=1;
SHOWAUX:=1;
SHOWZS:=1;
SHOWFIB:=1;
SHOWEVENT:=1;
SHOWCONFIRM:=0;
BP0:=TDXDLL1(1,DATE,TM0,KEY0);
BK0:=TDXDLL1(2,DATE,TM0,KEY0);
ZG0:=TDXDLL1(3,DATE,TM0,KEY0);
ZD0:=TDXDLL1(4,DATE,TM0,KEY0);
UH0:=TDXDLL1(9,DATE,TM0,KEY0);
DH0:=TDXDLL1(10,DATE,TM0,KEY0);
RP0:=TDXDLL1(11,DATE,TM0,KEY0);
RK0:=TDXDLL1(12,DATE,TM0,KEY0);
WP0:=TDXDLL1(13,DATE,TM0,KEY0);
WK0:=TDXDLL1(14,DATE,TM0,KEY0);
ZH0:=TDXDLL1(15,DATE,TM0,KEY0);
ZL0:=TDXDLL1(16,DATE,TM0,KEY0);
ZI0:=TDXDLL1(17,DATE,TM0,KEY0);
VT0:=TDXDLL1(18,DATE,TM0,KEY0);
VB0:=TDXDLL1(19,DATE,TM0,KEY0);
VX0:=TDXDLL1(20,DATE,TM0,KEY0);
F38:=TDXDLL1(21,DATE,TM0,KEY0);
F50:=TDXDLL1(22,DATE,TM0,KEY0);
F62:=TDXDLL1(23,DATE,TM0,KEY0);
F79:=TDXDLL1(24,DATE,TM0,KEY0);
SH0:=TDXDLL1(25,DATE,TM0,KEY0);
SL0:=TDXDLL1(26,DATE,TM0,KEY0);
ZS0:=TDXDLL1(27,DATE,TM0,KEY0);
ZE0:=TDXDLL1(28,DATE,TM0,KEY0);
OK0:=ALLOW0 AND MATCH0;
FG0:=SHOWFIB AND OK0 AND SH0>SL0 AND SL0>0;
{Reference bands first; candles and structural lines remain visible above them.}
STICKLINE(FG0 AND F38>0 AND F50>0,F38,F50,4,0),COLOR444444;
STICKLINE(FG0 AND F62>0 AND F79>0,F62,F79,4,0),COLOR444444;
DRAWKLINE(H,O,L,C);
{Yellow: native CZSC BI. Red: independent structural aid, not a strict segment.}
BD0:=IF(SHOWBI AND OK0 AND BP0>0,BK0,0);
DRAWLINE(BD0=-1,BP0,BD0=1,BP0,0),COLORYELLOW;
DRAWLINE(BD0=1,BP0,BD0=-1,BP0,0),COLORYELLOW;
RA0:=IF(SHOWAUX AND OK0 AND RP0>0,RK0,0);
DRAWLINE(RA0=-1,RP0,RA0=1,RP0,0),COLORRED,LINETHICK2;
DRAWLINE(RA0=1,RP0,RA0=-1,RP0,0),COLORRED,LINETHICK2;
{Blue: window-extremes trend reference.}
WA0:=IF(SHOWAUX AND OK0 AND WP0>0,WK0,0);
DRAWLINE(WA0=-1,WP0,WA0=1,WP0,0),COLORBLUE,LINETHICK2;
DRAWLINE(WA0=1,WP0,WA0=-1,WP0,0),COLORBLUE,LINETHICK2;
{Native ZS start/end coordinates come from the sidecar; no signal is backfilled.}
ZV0:=SHOWZS AND OK0 AND ZI0>0 AND ZH0>=ZL0 AND ZL0>0;
ZA0:=ZV0 AND ZS0>0;
ZB0:=ZV0 AND ZE0>0;
DRAWLINE(ZA0,ZH0,ZB0,ZH0,0),COLORMAGENTA,LINETHICK2;
DRAWLINE(ZA0,ZL0,ZB0,ZL0,0),COLORMAGENTA,LINETHICK2;
STICKLINE(ZA0 OR ZB0,ZH0,ZL0,0,0),COLORMAGENTA;
ZS_UP:IF(OK0 AND SHOWZS,IF(ZH0>0,ZH0,ZG0),DRAWNULL),NODRAW;
ZS_DN:IF(OK0 AND SHOWZS,IF(ZL0>0,ZL0,ZD0),DRAWNULL),NODRAW;
{Candidate labels stay on the discovery bar. They are not live alert inputs.}
DRAWTEXT(SHOWEVENT AND OK0 AND VT0>0,H*1.005,'顶背驰候选'),COLORYELLOW;
DRAWTEXT(SHOWEVENT AND OK0 AND VB0>0,L*0.995,'底背驰候选'),COLORYELLOW;
DRAWTEXT(SHOWEVENT AND OK0 AND VX0>0,L*0.985,'区间扩宽'),COLORCYAN;
DRAWTEXT(SHOWCONFIRM AND OK0 AND UH0>0,L*0.995,'向上笔确认'),COLORRED;
DRAWTEXT(SHOWCONFIRM AND OK0 AND DH0>0,H*1.005,'向下笔确认'),COLORGREEN;
DRAWTEXT_FIX(ISLASTBAR,0.01,0.01,0,'CZSC独立画线：黄笔/红结构辅助/蓝窗口参考/品红中枢'),COLORYELLOW;
DRAWTEXT_FIX(ISLASTBAR,0.01,0.05,0,'历史端点可修订；背驰仅为候选；灰带为黄金分割参考'),COLORYELLOW;
DRAWTEXT_FIX(ISLASTBAR AND ALLOW0=0,0.01,0.09,0,'仅支持沪深5分/30分/日线，必须选择不复权'),COLORYELLOW;
DRAWTEXT_FIX(ISLASTBAR AND ALLOW0 AND COUNT(MATCH0,2)=0,0.01,0.09,0,'行情未匹配：核对股票代码、周期、不复权及本地数据；预警关闭'),COLORYELLOW;
DRAWTEXT_FIX(ISLASTBAR AND ALLOW0 AND COUNT(MATCH0,2)>0 AND COUNT(RD0>0,2)=0,0.01,0.09,0,'缓存已过期：保留历史绘图，实时预警关闭'),COLORYELLOW;
DRAWTEXT_FIX(ISLASTBAR AND ALLOW0 AND COUNT(MATCH0,2)>0 AND COUNT(RD0>0,2)>0,0.01,0.09,0,'行情匹配、缓存新鲜：仍须在条件预警中添加并启用公式'),COLORCYAN;
"""


LIVE_FIELDS = (5, 6, 29, 30, 31)


def warning(field):
    """Only current, freshness-gated DLL event fields can drive live alerts."""
    if field not in LIVE_FIELDS:
        raise ValueError("Live warnings require DLL field 5, 6, 29, 30 or 31")
    return COMMON + f"""
{{Minutes: previous closed bar. Daily: external engine supplies closed bars only.}}
EV0:=TDXDLL1({field},DATE,TM0,KEY0);
MIN0:=PERIOD<>5 AND REF(EV0,1)>0 AND REF(RD0,1)>0 AND REF(MATCH0,1);
DAY0:=PERIOD=5 AND EV0>0 AND RD0>0 AND MATCH0;
XG:ALLOW0 AND (MIN0 OR DAY0);
"""


FORMULAS = {
    "CZSCMAIN": MAIN,
    "CZSCUP": warning(5),
    "CZSCDN": warning(6),
    "CZSCBD": warning(30),
    "CZSCTD": warning(29),
    "CZSCWIDE": warning(31),
}


def generate(root):
    """Write matching UTF-8/GBK text with Windows newlines, without a BOM."""
    root = Path(root)
    for encoding, folder in (("utf-8", "utf8"), ("gbk", "gbk")):
        target = root / folder
        target.mkdir(parents=True, exist_ok=True)
        for name, text in FORMULAS.items():
            windows_text = text.replace("\r\n", "\n").replace("\n", "\r\n")
            (target / (name + ".txt")).write_bytes(windows_text.encode(encoding))


def main():
    root = Path(__file__).resolve().parent / "formulas"
    generate(root)
    print("Generated", root)


if __name__ == "__main__":
    main()
