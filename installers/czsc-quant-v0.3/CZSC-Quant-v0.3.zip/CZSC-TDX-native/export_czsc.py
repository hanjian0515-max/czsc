"""Export actual CZSC 1.0.2 structures to a read-only Tongdaxin DLL cache.

CSV timestamps are bar CLOSE times in Shanghai local time. This program reads
an existing CSV; it does not acquire a quote feed or submit any orders.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, time as daytime, timedelta, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import struct
import tempfile
import time

SHANGHAI = timezone(timedelta(hours=8))
UTC = timezone.utc
MAGIC = b"CZTDX01\0"
VERSION = 1
HEADER = struct.Struct("<8sIIIIQQ")
RECORD = struct.Struct("<IIfffffI")
PERIODS = {"5m": (1, 5), "30m": (3, 30), "daily": (5, None)}
MARKETS = {"sz": 0, "sh": 1, "bj": 2}


@dataclass(frozen=True)
class Candle:
    end: datetime  # naive Shanghai local close time, as required by CZSC
    open: float
    high: float
    low: float
    close: float
    volume: float


def instrument_key(code: str, market: str) -> int:
    if not re.fullmatch(r"[0-9]{6}", code) or market not in MARKETS:
        raise ValueError("Use an explicit sh/sz/bj market and a six-digit code")
    return int(code) + MARKETS[market] * 1_000_000


def _local_now(now: datetime | None) -> datetime:
    value = now or datetime.now(UTC)
    if value.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    return value.astimezone(SHANGHAI)


def read_csv(path: Path, period: str, now: datetime | None = None) -> list[Candle]:
    if period not in PERIODS:
        raise ValueError("Unsupported period")
    wall_now = _local_now(now).replace(tzinfo=None)
    before = path.stat()
    content = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("Input CSV changed while reading; retry after writer finishes")
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = content.decode("gb18030")
    reader = csv.DictReader(io.StringIO(text))
    names = {str(k).strip().lower(): k for k in reader.fieldnames or []}
    required = ("datetime", "open", "high", "low", "close", "volume")
    if any(k not in names for k in required):
        raise ValueError("CSV requires Datetime,Open,High,Low,Close,Volume columns")
    result = []
    previous = None
    for line_number, row in enumerate(reader, 2):
        if line_number > 200_001:
            raise ValueError("CSV exceeds the 200000-row limit")
        try:
            stamp = datetime.fromisoformat(row[names["datetime"]].strip())
            if stamp.tzinfo is not None:
                raise ValueError("Datetime must be naive Shanghai local time")
            if not 1970 <= stamp.year <= 2099:
                raise ValueError("Datetime year must be between 1970 and 2099")
            if period == "daily":
                if stamp.time() == daytime(0, 0):
                    stamp = stamp.replace(hour=15)
                elif stamp.time() != daytime(15, 0):
                    raise ValueError("Daily bars must use a date or a 15:00 close timestamp")
            elif stamp.second or stamp.microsecond or stamp.minute % PERIODS[period][1]:
                raise ValueError("Minute close timestamp is not aligned to the selected period")
            if previous is not None and stamp <= previous:
                raise ValueError("Duplicate or unordered close timestamp")
            previous = stamp
            values = [float(row[names[k]]) for k in required[1:]]
            op, high, low, close, volume = values
            if not all(math.isfinite(v) and abs(v) <= 1e30 for v in values):
                raise ValueError("Nonfinite or unrepresentable OHLCV")
            if not (0 < low <= min(op, close) <= max(op, close) <= high) or volume < 0:
                raise ValueError("Invalid OHLCV")
            if stamp <= wall_now:
                result.append(Candle(stamp, op, high, low, close, volume))
        except (ValueError, TypeError, AttributeError, KeyError) as error:
            raise ValueError(f"CSV line {line_number}: {error}") from error
    if not result:
        raise ValueError("No closed candles available")
    return result


def _native():
    os.environ.setdefault("CZSC_HOME", str(Path(__file__).resolve().parent / "runtime" / "czsc-cache"))
    import czsc
    if czsc.__version__ != "1.0.2":
        raise RuntimeError("The cache contract is tested with CZSC 1.0.2; install the pinned version")
    return czsc


def _event_key(bi):
    # Revisions are separate observed events; earlier event flags never move.
    return (bi.fx_a.dt, bi.fx_b.dt, str(bi.direction), float(bi.fx_a.fx), float(bi.fx_b.fx))


def build_cache(candles: list[Candle], code: str, market: str, period: str,
                now: datetime | None = None, min_bi_len: int = 6,
                max_bi_num: int = 100) -> tuple[bytes, dict]:
    if not candles:
        raise ValueError("No candles")
    key = instrument_key(code, market)
    if period not in PERIODS or min_bi_len < 3 or max_bi_num < 2:
        raise ValueError("Invalid period or CZSC parameters")
    wall_now = _local_now(now)
    if any(c.end.tzinfo is not None or c.end > wall_now.replace(tzinfo=None) for c in candles):
        raise ValueError("build_cache accepts closed, naive Shanghai candles only")
    if any(not 1970 <= c.end.year <= 2099 for c in candles):
        raise ValueError("Datetime year must be between 1970 and 2099")
    if any(a.end >= b.end for a, b in zip(candles, candles[1:])):
        raise ValueError("Candles must be strictly ordered")
    native = _native()
    freq = {"5m": native.Freq.F5, "30m": native.Freq.F30, "daily": native.Freq.D}[period]
    analysis = None
    records = []
    seen = set()
    for i, candle in enumerate(candles):
        raw = native.RawBar(symbol=f"{market}{code}", dt=candle.end, freq=freq,
                            open=candle.open, close=candle.close, high=candle.high,
                            low=candle.low, vol=candle.volume,
                            amount=candle.close*candle.volume, id=i)
        if analysis is None:
            analysis = native.CZSC([raw], min_bi_len=min_bi_len, max_bi_num=max_bi_num)
        else:
            analysis.update(raw)
        flags = 0
        lagged_bis = analysis.bi_list[:-1]
        if lagged_bis:
            latest = lagged_bis[-1]
            identity = _event_key(latest)
            if identity not in seen:
                flags = 1 if latest.direction == native.Direction.Up else 2
                seen.add(identity)
        zg = zd = 0.0
        for center in reversed(analysis.zs_list):
            if center.is_valid():
                zg, zd = float(center.zg), float(center.zd)
                break
        stamp = candle.end
        records.append([(stamp.year-1900)*10000+stamp.month*100+stamp.day,
                        0 if period == "daily" else stamp.hour*100+stamp.minute,
                        candle.close, 0.0, 0.0, zg, zd, flags])
    # Drawing is a snapshot of native BI endpoints at their true extremum bars.
    # This can revise historical drawings. It is entirely separate from flags.
    index = {c.end: i for i, c in enumerate(candles)}
    for bi in analysis.bi_list:
        for point in (bi.fx_a, bi.fx_b):
            if point.dt in index:
                record = records[index[point.dt]]
                record[3] = float(point.fx)
                record[4] = 1.0 if point.mark == native.Mark.G else -1.0
    generated = int(wall_now.astimezone(UTC).timestamp())
    newest = int(candles[-1].end.replace(tzinfo=SHANGHAI).timestamp())
    payload = HEADER.pack(MAGIC, VERSION, PERIODS[period][0], key, len(records), generated, newest)
    payload += b"".join(RECORD.pack(*r) for r in records)
    metadata = {"engine": "czsc", "version": native.__version__, "instrument": f"{market}{code}",
                "key": key, "period": period, "records": len(records),
                "native_bis": len(analysis.bi_list), "up_events": sum(bool(r[-1] & 1) for r in records),
                "down_events": sum(bool(r[-1] & 2) for r in records),
                "generated_at_utc": generated, "newest_bar_end_utc": newest,
                "min_bi_len": min_bi_len, "max_bi_num": max_bi_num,
                "cache_sha256": hashlib.sha256(payload).hexdigest(),
                "notice": "Native CZSC drawing snapshot; structural events only, not buy/sell signals. No orders or quote feed."}
    return payload, metadata


def write_atomic(path: Path, content: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".czsc-", delete=False) as file:
            temporary = Path(file.name)
            file.write(content)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def export_csv(input_path: Path, output_dir: Path, code: str, market: str, period: str,
               now: datetime | None = None, min_bi_len: int = 6, max_bi_num: int = 100) -> dict:
    candles = read_csv(input_path, period, now)
    payload, metadata = build_cache(candles, code, market, period, now, min_bi_len, max_bi_num)
    target = output_dir / f"{instrument_key(code, market)}_{PERIODS[period][0]}.bin"
    write_atomic(target, payload)
    metadata["output"] = str(target)
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--code", required=True)
    parser.add_argument("--market", choices=MARKETS, required=True)
    parser.add_argument("--period", choices=PERIODS, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--min-bi-len", type=int, default=6)
    parser.add_argument("--max-bi-num", type=int, default=100)
    parser.add_argument("--watch", action="store_true", help="Repeatedly read an existing CSV; does not download quotes")
    parser.add_argument("--interval", type=float, default=5.0)
    args = parser.parse_args()
    if not math.isfinite(args.interval) or args.interval < 1:
        parser.error("--interval must be at least one second")
    while True:
        try:
            result = export_csv(args.input, args.output_dir, args.code, args.market,
                                args.period, min_bi_len=args.min_bi_len, max_bi_num=args.max_bi_num)
            print(json.dumps(result, ensure_ascii=False), flush=True)
        except (OSError, ValueError, RuntimeError) as error:
            print(json.dumps({"error": str(error), "cache_updated": False}, ensure_ascii=False), flush=True)
            if not args.watch:
                return 1
        if not args.watch:
            return 0
        try:
            time.sleep(args.interval)
        except KeyboardInterrupt:
            return 0


if __name__ == "__main__":
    raise SystemExit(main())
