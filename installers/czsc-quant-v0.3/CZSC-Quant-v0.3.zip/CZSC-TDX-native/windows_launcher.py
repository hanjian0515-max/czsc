"""Windows setup assistant: select actual TDX executable and an existing source."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys


def pe_arch(path):
    with Path(path).open("rb") as file:
        if file.read(2) != b"MZ":
            raise ValueError("Not a Windows PE executable")
        file.seek(0x3c)
        offset_bytes = file.read(4)
        if len(offset_bytes) != 4:
            raise ValueError("Truncated executable")
        offset = struct.unpack("<I", offset_bytes)[0]
        file.seek(offset)
        if file.read(4) != b"PE\0\0":
            raise ValueError("Invalid PE signature")
        machine_bytes = file.read(2)
        if len(machine_bytes) != 2:
            raise ValueError("Truncated PE machine field")
        machine = struct.unpack("<H", machine_bytes)[0]
        if machine not in (0x14c, 0x8664):
            raise ValueError("Only x86/x64 Tongdaxin processes are supported")
        return "x64" if machine == 0x8664 else "x86"


def install_bridge(executable, package):
    executable, package = Path(executable).resolve(), Path(package).resolve()
    root = executable.parent
    if not (root / "T0002").is_dir():
        raise ValueError("Selected executable must be in the Tongdaxin root containing T0002")
    architecture = pe_arch(executable)
    binary = package / "bin" / architecture / "CZSCBridge.dll"
    if pe_arch(binary) != architecture:
        raise ValueError("Packaged DLL architecture mismatch")
    target = root / "T0002" / "dlls" / "CZSCBridge.dll"
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        if hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(binary.read_bytes()).digest():
            backup = target.with_name("CZSCBridge.dll.backup-"+datetime.now().strftime("%Y%m%d%H%M%S%f"))
            shutil.copy2(target, backup)
            shutil.copy2(binary, target)
    else:
        shutil.copy2(binary, target)
    (target.parent / "czsc_data").mkdir(exist_ok=True)
    return target


def configure(root):
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog
    window = tk.Tk()
    window.withdraw()
    try:
        messagebox.showinfo("CZSC 外接通达信", "请选择实际通达信主程序；工具会读取程序位数，安装对应DLL。\n64位Windows也可能运行32位通达信。")
        exe = filedialog.askopenfilename(title="选择通达信主程序（T0002同级）", filetypes=[("Windows程序", "*.exe")])
        if not exe:
            return None
        source = filedialog.askopenfilename(title="选择已有的沪深.lc5 / .day / 标准CSV行情文件", filetypes=[("行情文件", "*.lc5 *.day *.csv"), ("全部文件", "*.*")])
        if not source:
            return None
        match = re.fullmatch(r"(sh|sz)(\d{6})\.(lc5|day)", Path(source).name.lower())
        symbol = (match.group(1)+match.group(2)) if match else simpledialog.askstring("证券", "输入市场和六位代码，例如 sh600000 或 sz000001")
        if not symbol or not re.fullmatch(r"(sh|sz)\d{6}", symbol):
            raise ValueError("必须是 sh/sz 加六位证券代码")
        period = "daily" if Path(source).suffix.lower() == ".day" else simpledialog.askstring("周期", "输入5m或30m；CSV日线输入daily", initialvalue="5m")
        if period not in ("5m", "30m", "daily"):
            raise ValueError("周期必须为5m、30m或daily")
        target = install_bridge(exe, root)
        messagebox.showinfo("DLL已准备", "请在通达信公式管理器中，将CZSCBridge.dll绑定到DLL槽1；若槽1已有插件，请先勿替换，按说明修改公式使用空闲槽。\n再新建主图CZSCMAIN及预警CZSCUP/CZSCDN，粘贴formulas/gbk对应内容。\n行情源必须持续更新；旧文件只画历史图，不会发实时预警。")
        return {"source": source, "output_dir": str(target.parent/"czsc_data"), "market": symbol[:2], "code": symbol[2:], "period": period}
    finally:
        window.destroy()


def main():
    if sys.platform != "win32":
        raise SystemExit("Use run_bridge.py on non-Windows; this setup assistant is for Windows")
    root = Path(__file__).resolve().parent
    config_file = root / "runtime" / "windows-config.json"
    try:
        if config_file.exists() and "--configure" not in sys.argv:
            config = json.loads(config_file.read_text(encoding="utf-8"))
        else:
            config = configure(root)
            if config is None:
                return 0
            config_file.parent.mkdir(exist_ok=True)
            config_file.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        args = [sys.executable, str(root/"run_bridge.py"), "--watch"]
        for key in ("source", "output_dir", "market", "code", "period"):
            args += ["--"+key.replace("_", "-"), config[key]]
        return subprocess.call(args)
    except (OSError, ValueError, KeyError) as error:
        print("Setup failed:", error, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
