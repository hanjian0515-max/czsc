"""Synthetic engineering checks; these are not live quote or trading tests."""
from datetime import datetime, timedelta
from fractions import Fraction
import math
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_czsc import Candle, SHANGHAI, UTC, _native
from visual_export import (FIELDS, HEADER, MAGIC, RECORD, _draw_boxes,
                           _macd_areas, _swing_points, visual_cache)

NOW = datetime(2026, 11, 5, 12, tzinfo=UTC)


def field(name):
    return FIELDS.index(name) + 2


def unpack(payload):
    header = HEADER.unpack_from(payload)
    return header, [RECORD.unpack_from(payload, HEADER.size + i*RECORD.size)
                    for i in range(header[4])]


def synthetic_wave():
    # New price extremes on progressively shorter swings produce a real,
    # reproducible native BI MACD-area comparison, without a market feed.
    values = [100.0]
    for target, count in [(120, 40), (90, 40), (122, 12), (89, 12),
                          (123, 8), (88, 8), (121, 10), (90, 10)]:
        previous = values[-1]
        values.extend(previous+(target-previous)*i/count for i in range(1, count+1))
    start = datetime(2026, 10, 1, 9, 35)
    return [Candle(start+timedelta(minutes=5*i), value, value+.2, value-.2,
                   value, 1000) for i, value in enumerate(values)]


def native_analysis(source):
    native = _native()
    raw = [native.RawBar(symbol="sh600000", dt=b.end, freq=native.Freq.F5,
                         open=b.open, close=b.close, high=b.high, low=b.low,
                         vol=b.volume, amount=b.close*b.volume, id=i)
           for i, b in enumerate(source)]
    return native.CZSC(raw, min_bi_len=6, max_bi_num=100)


class NativeVisualTests(unittest.TestCase):
    def test_binary_contract_native_drawing_sources_and_latest_fibonacci(self):
        source = synthetic_wave()
        payload, metadata = visual_cache(source, "600000", "sh", "5m", NOW)
        head, rows = unpack(payload)
        self.assertEqual((len(MAGIC), HEADER.size, RECORD.size), (8, 40, 80))
        self.assertEqual(head[:5], (MAGIC, 2, 1, 1600000, len(source)))
        self.assertEqual(head[5], int(NOW.timestamp()))
        self.assertEqual(head[6], int(source[-1].end.replace(tzinfo=SHANGHAI).timestamp()))
        self.assertEqual(len(payload), 40+80*len(source))
        self.assertEqual(rows[0][:2], (1261001, 935))
        self.assertEqual(metadata["filename"], "1600000_1_visual.bin")
        self.assertEqual(len(FIELDS), 18)
        obj = native_analysis(source)
        index = {b.end: i for i, b in enumerate(source)}
        native_points = {index[p.dt]: float(p.fx) for bi in obj.bi_list
                         for p in (bi.fx_a, bi.fx_b)}
        self.assertGreater(len(native_points), 4)
        for name in ("redPrice", "bluePrice"):
            drawn = {i: row[field(name)] for i, row in enumerate(rows) if row[field(name)]}
            self.assertGreaterEqual(len(drawn), 2)
            for i, value in drawn.items():
                self.assertAlmostEqual(value, native_points[i], places=4)
        blue = [row[field("bluePrice")] for row in rows if row[field("bluePrice")]]
        self.assertAlmostEqual(min(blue), min(native_points.values()), places=4)
        self.assertAlmostEqual(max(blue), max(native_points.values()), places=4)
        valid = [z for z in obj.zs_list if z.is_valid()]
        self.assertTrue(valid)
        for i, row in enumerate(rows):
            covering = [z for z in valid if z.sdt <= source[i].end <= z.edt]
            if covering:
                latest = max(covering, key=lambda z: (z.sdt, z.edt))
                self.assertAlmostEqual(row[field("boxHigh")], latest.zg, places=4)
                self.assertAlmostEqual(row[field("boxLow")], latest.zd, places=4)
            else:
                self.assertEqual(row[field("boxID")], 0)
        latest = obj.bi_list[-2]
        high, low = latest.high, latest.low
        up = latest.direction == _native().Direction.Up
        for name, ratio in zip(("fib382", "fib500", "fib618", "fib786"),
                               (.382, .5, .618, .786)):
            expected = high-ratio*(high-low) if up else low+ratio*(high-low)
            self.assertAlmostEqual(rows[-1][field(name)], expected, places=4)
        self.assertAlmostEqual(rows[-1][field("swingHigh")], high, places=4)
        self.assertAlmostEqual(rows[-1][field("swingLow")], low, places=4)

    def test_nonzero_native_candidates_and_fibonacci_are_prefix_causal(self):
        source = synthetic_wave()
        _, full = unpack(visual_cache(source, "000001", "sz", "5m", NOW)[0])
        causal = ("divTopFlag", "divBottomFlag", "expandFlag", "fib382", "fib500",
                  "fib618", "fib786", "swingHigh", "swingLow")
        self.assertTrue(any(row[field("divTopFlag")] for row in full))
        self.assertTrue(any(row[field("divBottomFlag")] for row in full))
        for length in (1, 85, 110, 125, len(source)-1):
            _, prefix = unpack(visual_cache(source[:length], "000001", "sz", "5m", NOW)[0])
            for a, b in zip(prefix, full):
                self.assertEqual(a[:2], b[:2])
                self.assertEqual([a[field(name)] for name in causal],
                                 [b[field(name)] for name in causal])
        _, metadata = visual_cache(source, "000001", "sz", "5m", NOW)
        for event in metadata["divergence_events"]:
            observed = datetime.fromisoformat(event["observed_at"])
            bi_end = datetime.fromisoformat(event["bi_end"])
            self.assertGreater(observed, bi_end)
            self.assertLess(event["area"], event["previous_area"])
            row = full[next(i for i, bar in enumerate(source) if bar.end == observed)]
            name = "divTopFlag" if event["direction"] == "up" else "divBottomFlag"
            self.assertEqual(row[field(name)], 1)

    def test_daily_uses_zero_time_and_market_is_explicit(self):
        source = [Candle(datetime(2026, 10, i+1, 15), 100, 101, 99, 100, 1000)
                  for i in range(5)]
        header, rows = unpack(visual_cache(source, "000001", "sh", "daily", NOW)[0])
        self.assertEqual(header[2:4], (5, 1000001))
        self.assertTrue(all(row[1] == 0 for row in rows))
        self.assertTrue(all(not any(row[2:]) for row in rows))

    def test_invalid_candles_never_reach_native_engine(self):
        source = synthetic_wave()
        invalid = [([], "000001", "sz", "5m", NOW),
                   (source, "000001", "us", "5m", NOW),
                   (source, "000001", "sz", "1m", NOW),
                   (source, "000001", "sz", "5m", datetime(2026, 1, 1, tzinfo=UTC)),
                   (source[::-1], "000001", "sz", "5m", NOW),
                   ([source[0], source[0]], "000001", "sz", "5m", NOW),
                   ([Candle(source[0].end, math.nan, 101, 99, 100, 1)], "000001", "sz", "5m", NOW),
                   ([Candle(source[0].end, 100, 99, 98, 100, 1)], "000001", "sz", "5m", NOW),
                   ([Candle(NOW, 100, 101, 99, 100, 1)], "000001", "sz", "5m", NOW),
                   (source, "000001", "sz", "5m", NOW.replace(tzinfo=None))]
        with patch("visual_export._native", side_effect=AssertionError("native must not run")):
            for args in invalid:
                with self.subTest(args=args[1:4]):
                    with self.assertRaises(ValueError):
                        visual_cache(*args)


class VisualDefinitionTests(unittest.TestCase):
    def test_macd_initialization_and_positive_negative_area_match_exact_recurrence(self):
        closes = [100, 110, 90, 105, 95]
        source = [Candle(datetime(2026, 10, 1)+timedelta(minutes=5*i), p, p+1, p-1, p, 1)
                  for i, p in enumerate(closes)]
        positive, negative = _macd_areas(source)
        fast = slow = Fraction(closes[0])
        dea = Fraction(0)
        expected_positive, expected_negative = [0.0], [0.0]
        for price in closes:
            fast = Fraction(11, 13)*fast + Fraction(2, 13)*price
            slow = Fraction(25, 27)*slow + Fraction(2, 27)*price
            dif = fast-slow
            dea = Fraction(4, 5)*dea + Fraction(1, 5)*dif
            histogram = float(2*(dif-dea))
            expected_positive.append(expected_positive[-1]+max(histogram, 0))
            expected_negative.append(expected_negative[-1]+max(-histogram, 0))
        for actual, expected in zip(positive+negative, expected_positive+expected_negative):
            self.assertAlmostEqual(actual, expected, places=12)
        self.assertEqual(_macd_areas(source[:3]), (positive[:4], negative[:4]))

    def test_three_same_kind_extrema_are_thinned_without_inventing_prices(self):
        points = [(0, 100, -1.), (1, 120, 1.), (2, 102, -1.), (3, 125, 1.),
                  (4, 95, -1.), (5, 121, 1.), (6, 98, -1.), (7, 123, 1.),
                  (8, 99, -1.), (9, 119, 1.), (10, 101, -1.)]
        result = _swing_points(points)
        self.assertEqual(result, [points[i] for i in (0, 3, 4, 7, 10)])
        self.assertTrue(all(a[2] != b[2] for a, b in zip(result, result[1:])))
        self.assertEqual(_swing_points(points[:2]), points[:2])
        same_kind_edges = [(0, 120, 1.), (1, 90, -1.), (2, 122, 1.),
                           (3, 89, -1.), (4, 123, 1.), (5, 88, -1.), (6, 121, 1.)]
        anchored = _swing_points(same_kind_edges)
        self.assertEqual(anchored[0], same_kind_edges[0])
        self.assertEqual(anchored[-1], same_kind_edges[-1])
        self.assertTrue(all(a[2] != b[2] for a, b in zip(anchored, anchored[1:])))

    def test_overlapping_center_fragments_have_their_own_complete_anchors(self):
        candles = synthetic_wave()[:15]
        def center(start, end, high, low):
            return SimpleNamespace(sdt=candles[start].end, edt=candles[end].end,
                                   zg=high, zd=low)
        records = [[0, 0]+[0.0]*18 for _ in candles]
        segments = _draw_boxes(records, [center(0, 10, 110, 100), center(3, 5, 108, 102),
                                        center(8, 12, 112, 105)], candles)
        self.assertEqual(segments, 4)
        self.assertEqual([r[field("boxID")] for r in records],
                         [1, 1, 1, 2, 2, 2, 1, 1, 3, 3, 3, 3, 3, 0, 0])
        self.assertEqual([i for i, r in enumerate(records) if r[field("boxStartFlag")]],
                         [0, 3, 6, 8])
        self.assertEqual([i for i, r in enumerate(records) if r[field("boxEndFlag")]],
                         [2, 5, 7, 12])
        for row in records:
            if row[field("boxStartFlag")] or row[field("boxEndFlag")]:
                self.assertGreater(row[field("boxID")], 0)
                self.assertGreater(row[field("boxHigh")], row[field("boxLow")])

    def test_interval_widening_is_observed_on_arrival_without_backfilling(self):
        # Explicit interval snapshots exercise the engineering definition;
        # this does not claim this fabricated sequence is native market data.
        source = synthetic_wave()[:8]
        bounds = [None, (110, 100), (110, 100), (111, 99), (109, 101),
                  (112, 98), (112, 98), (113, 99)]
        class FakeAnalysis:
            def __init__(self, bars, **kwargs):
                self.bi_list = []
                self.position = 0
            def update(self, bar):
                self.position += 1
            @property
            def zs_list(self):
                limits = bounds[self.position]
                if limits is None:
                    return []
                return [SimpleNamespace(sdt=source[0].end, edt=source[self.position].end,
                                        zg=limits[0], zd=limits[1], is_valid=lambda: True)]
        native = SimpleNamespace(__version__="1.0.2", CZSC=FakeAnalysis,
                                 RawBar=lambda **kw: SimpleNamespace(**kw),
                                 Freq=SimpleNamespace(F5=1, F30=3, D=5))
        with patch("visual_export._native", return_value=native):
            _, full = unpack(visual_cache(source, "000001", "sz", "5m", NOW)[0])
            _, prefix = unpack(visual_cache(source[:5], "000001", "sz", "5m", NOW)[0])
        self.assertEqual([i for i, r in enumerate(full) if r[field("expandFlag")]], [3, 5])
        self.assertEqual([r[field("expandFlag")] for r in prefix],
                         [r[field("expandFlag")] for r in full[:5]])


if __name__ == "__main__":
    unittest.main()
