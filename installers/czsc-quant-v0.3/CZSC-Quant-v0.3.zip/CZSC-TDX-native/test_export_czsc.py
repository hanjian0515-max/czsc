import csv
from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_czsc import (Candle, HEADER, MAGIC, RECORD, SHANGHAI, UTC,
                         _native, build_cache, export_csv, instrument_key,
                         read_csv, write_atomic)


def candles(count=300):
    start = datetime(2026, 10, 1, 9, 35)
    return [Candle(start+timedelta(minutes=5*i),
                   100+10*math.sin(i*math.pi/15),
                   101+10*math.sin(i*math.pi/15),
                   99+10*math.sin(i*math.pi/15),
                   100+10*math.sin(i*math.pi/15), 1000) for i in range(count)]


NOW = datetime(2026, 11, 5, 12, 0, tzinfo=UTC)


def unpack(payload):
    header = HEADER.unpack_from(payload)
    records = [RECORD.unpack_from(payload, HEADER.size+i*RECORD.size) for i in range(header[4])]
    return header, records


def create_csv(path, bars):
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(["Datetime", "Open", "High", "Low", "Close", "Volume"])
        for b in bars:
            writer.writerow([b.end.isoformat(sep=" "), b.open, b.high, b.low, b.close, b.volume])


class NativeExportTests(unittest.TestCase):
    def test_contract_and_actual_native_endpoints(self):
        source = candles()
        payload, metadata = build_cache(source, "600000", "sh", "5m", NOW)
        head, rows = unpack(payload)
        self.assertEqual(HEADER.size, 40)
        self.assertEqual(RECORD.size, 32)
        self.assertEqual(len(payload), 40+32*len(source))
        self.assertEqual(head[:5], (MAGIC, 1, 1, 1_600_000, len(source)))
        self.assertEqual(head[5], int(NOW.timestamp()))
        self.assertEqual(head[6], int(source[-1].end.replace(tzinfo=SHANGHAI).timestamp()))
        self.assertEqual(rows[0][:2], (1261001, 935))
        self.assertTrue(any(r[7] == 1 for r in rows))
        self.assertTrue(any(r[7] == 2 for r in rows))
        native = _native()
        raw = [native.RawBar(symbol="sh600000", dt=b.end, freq=native.Freq.F5,
                              open=b.open, close=b.close, high=b.high, low=b.low,
                              vol=b.volume, amount=b.close*b.volume, id=i)
               for i, b in enumerate(source)]
        obj = native.CZSC(raw, min_bi_len=6, max_bi_num=100)
        expected = {}
        for bi in obj.bi_list:
            for point in (bi.fx_a, bi.fx_b):
                expected[point.dt] = (point.fx, 1.0 if point.mark == native.Mark.G else -1.0)
        index = {b.end: i for i, b in enumerate(source)}
        self.assertGreater(len(expected), 5)
        for date, (price, kind) in expected.items():
            row = rows[index[date]]
            self.assertAlmostEqual(row[3], price, places=4)
            self.assertEqual(row[4], kind)
        self.assertEqual(metadata["native_bis"], len(obj.bi_list))

    def test_event_and_center_prefix_is_not_rewritten_by_future_candles(self):
        source = candles(360)
        _, prefix = unpack(build_cache(source[:230], "000001", "sz", "5m", NOW)[0])
        _, full = unpack(build_cache(source, "000001", "sz", "5m", NOW)[0])
        # Historical native drawings may revise; causal flags/center snapshots cannot.
        for a, b in zip(prefix, full):
            self.assertEqual(a[:3], b[:3])
            self.assertEqual(a[5:], b[5:])
        self.assertTrue(any(a[7] for a in prefix))

    def test_native_center_snapshots_match_final_native_center(self):
        source = candles()
        _, rows = unpack(build_cache(source, "600000", "sh", "5m", NOW)[0])
        native = _native()
        obj = native.CZSC([native.RawBar("sh600000", b.end, native.Freq.F5, b.open,
                                       b.close, b.high, b.low, b.volume,
                                       b.close*b.volume, i) for i, b in enumerate(source)],
                          min_bi_len=6, max_bi_num=100)
        center = next(z for z in reversed(obj.zs_list) if z.is_valid())
        self.assertAlmostEqual(rows[-1][5], center.zg, places=4)
        self.assertAlmostEqual(rows[-1][6], center.zd, places=4)

    def test_market_identity_and_period_are_not_interchangeable(self):
        self.assertNotEqual(instrument_key("000001", "sz"), instrument_key("000001", "sh"))
        with self.assertRaises(ValueError): instrument_key("../a", "sh")
        with self.assertRaises(ValueError): instrument_key("600000", "us")
        daily = [Candle(datetime(2026, 10, i+1, 15), 100, 101, 99, 100, 1000) for i in range(10)]
        head, rows = unpack(build_cache(daily, "600000", "sh", "daily", NOW)[0])
        self.assertEqual(head[2], 5)
        self.assertTrue(all(r[1] == 0 for r in rows))


class CsvAndAtomicTests(unittest.TestCase):
    def test_future_candles_are_filtered_using_shanghai_wall_time(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"input.csv"
            source = candles(3)
            create_csv(path, source)
            now = datetime(2026, 10, 1, 1, 41, tzinfo=UTC)  # Shanghai 09:41
            result = read_csv(path, "5m", now)
            self.assertEqual([b.end for b in result], [b.end for b in source[:2]])

    def test_daily_date_is_a_1500_close_and_not_available_in_morning(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"daily.csv"
            path.write_text("Datetime,Open,High,Low,Close,Volume\n2026-11-05,100,101,99,100,1000\n",encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "No closed"):
                read_csv(path, "daily", datetime(2026,11,5,2,tzinfo=UTC))
            result = read_csv(path, "daily", datetime(2026,11,5,8,tzinfo=UTC))
            self.assertEqual(result[0].end, datetime(2026,11,5,15))

    def test_rejects_duplicate_unaligned_missing_and_bad_ohlcv(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"bad.csv"
            examples = [
                "Datetime,Open,High,Low,Close,Volume\n2026-11-04 09:35,100,101,99,100,1000\n2026-11-04 09:35,100,101,99,100,1000\n",
                "Datetime,Open,High,Low,Close,Volume\n2026-11-04 09:36,100,101,99,100,1000\n",
                "Datetime,Open,High,Low,Close,Volume\n2026-11-04 09:35,nan,101,99,100,1000\n",
                "Datetime,Open,High,Low,Close,Volume\n2026-11-04 09:35,100,90,99,100,1000\n",
                "Datetime,Open,High,Low,Close\n2026-11-04 09:35,100,101,99,100\n",
                "Datetime,Open,High,Low,Close,Volume\n2026-11-04T09:35+08:00,100,101,99,100,1000\n",
            ]
            for content in examples:
                with self.subTest(content=content):
                    path.write_text(content,encoding="utf-8")
                    with self.assertRaises(ValueError): read_csv(path,"5m",NOW)

    def test_invalid_input_preserves_previous_cache_and_leaves_no_temp_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root/"input.csv"
            create_csv(source,candles())
            out = root/"cache"
            first = export_csv(source,out,"600000","sh","5m",NOW)
            target = Path(first["output"])
            original = target.read_bytes()
            source.write_text("invalid",encoding="utf-8")
            with self.assertRaises(ValueError): export_csv(source,out,"600000","sh","5m",NOW)
            self.assertEqual(target.read_bytes(),original)
            self.assertFalse(list(out.glob(".czsc-*")))

    def test_replace_failure_preserves_old_file_and_cleans_temporary(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"data.bin"
            path.write_bytes(b"old")
            with patch("export_czsc.os.replace",side_effect=PermissionError("busy")):
                with self.assertRaises(PermissionError): write_atomic(path,b"new")
            self.assertEqual(path.read_bytes(),b"old")
            self.assertFalse(list(path.parent.glob(".czsc-*")))

    def test_public_build_rejects_unclosed_or_unordered_input(self):
        source = candles()
        with self.assertRaises(ValueError): build_cache(source,"600000","sh","5m",datetime(2026,1,1,tzinfo=UTC))
        with self.assertRaises(ValueError): build_cache(source[::-1],"600000","sh","5m",NOW)


if __name__ == "__main__":
    unittest.main()
