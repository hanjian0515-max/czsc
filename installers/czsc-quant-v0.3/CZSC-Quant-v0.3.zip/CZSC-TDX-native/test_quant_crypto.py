"""Synthetic/mocked crypto-feed tests; these are not real-market evidence."""
import csv
from datetime import datetime, timedelta, timezone
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.error import URLError

from quant_crypto import (SOURCE, fetch_crypto_history, load_crypto_data,
                          normalize_product, public_json, save_crypto_history,
                          refresh_crypto_file, update_crypto_history)

UTC = timezone.utc
SH = timezone(timedelta(hours=8))
END = int(datetime(2024, 11, 1, tzinfo=UTC).timestamp())


def row(end, price=100):
    return {"end": end, "open": price, "high": price+1, "low": price-1,
            "close": price, "volume": 2}


def dataset(rows=None):
    return {"schema": 1, "asset_market": "crypto", "source": "synthetic_test_fixture",
            "product": "BTC-USD", "fetched_at": END,
            "instrument": {"tick": .01, "step": .00001, "multiplier": 1,
                           "quote_to_usd": 1, "short_allowed": False},
            "series": {"300": [row(END-300), row(END)] if rows is None else rows}}


def provider():
    calls = []
    def request(path, params=None):
        calls.append((path, params))
        if params is None:
            return {"id": "BTC-USD", "quote_currency": "USD", "status": "online",
                    "quote_increment": ".01", "base_increment": ".00000001",
                    "min_market_funds": "10"}
        seconds = params["granularity"]
        start = int(datetime.fromisoformat(params["start"]).timestamp())
        end = int(datetime.fromisoformat(params["end"]).timestamp())
        # Native endpoint returns newest first and may include out-of-window rows.
        return [[stamp, 99, 101, 100, 100, 2] for stamp in range(end, start-seconds-1, -seconds)]
    return request, calls


class CryptoInputTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    def write_json(self, value):
        path = self.root/"synthetic.json"
        path.write_text(json.dumps(value), encoding="utf-8")
        return path

    def write_csv(self, rows):
        stream = io.StringIO(newline="")
        writer = csv.writer(stream)
        writer.writerow(("Datetime", "Open", "High", "Low", "Close", "Volume"))
        for stamp, price in rows:
            writer.writerow((stamp, price, price+1, price-1, price, 2))
        path = self.root/"synthetic.csv"
        path.write_text(stream.getvalue(), encoding="utf-8")
        return path

    def test_usd_spot_aliases_and_rejects_tether_or_path_injection(self):
        for value in ("BTCUSD", "btc-usd", " BTC/USD "):
            self.assertEqual(normalize_product(value), "BTC-USD")
        for value in ("BTCUSDT", "BTC-USDT", "BTC-USD/orders", "600000", "../BTC-USD"):
            with self.assertRaises(ValueError):
                normalize_product(value)

    def test_complete_utc_day_aggregates_to_shanghai_0800(self):
        start = END-86400
        rows = [(datetime.fromtimestamp(start+i*300, UTC).isoformat(), 100+i*.01) for i in range(1, 289)]
        path = self.write_csv(rows)
        five, thirty, daily = load_crypto_data(path, "BTCUSD", now=END)
        self.assertEqual((len(five), len(thirty), len(daily)), (288, 48, 1))
        self.assertEqual(daily[0].end, datetime(2024, 11, 1, 8))
        self.assertEqual(daily[0].volume, 576)
        self.assertEqual(daily[0].open, five[0].open)
        self.assertEqual(daily[0].close, five[-1].close)
        self.assertIsNone(five[0].end.tzinfo)

    def test_missing_five_minute_bar_is_never_filled(self):
        rows = [(datetime.fromtimestamp(END-86400+i*300, UTC).isoformat(), 100) for i in range(1, 289) if i != 15]
        five, thirty, daily = load_crypto_data(self.write_csv(rows), now=END)
        self.assertEqual(len(five), 287)
        self.assertEqual(len(thirty), 47)
        self.assertEqual(daily, [])

    def test_open_candles_are_excluded_before_aggregation(self):
        values = [(datetime.fromtimestamp(END-1800+i*300, UTC).isoformat(), 100) for i in range(1, 7)]
        five, thirty, daily = load_crypto_data(self.write_csv(values), now=END-1)
        self.assertEqual(len(five), 5)
        self.assertEqual(thirty, [])
        self.assertEqual(daily, [])

    def test_naive_csv_is_shanghai_and_offsets_represent_same_clock(self):
        rows = [("2024-11-01 07:55:00", 100), ("2024-11-01T00:00:00Z", 101)]
        five, _, _ = load_crypto_data(self.write_csv(rows), now=datetime(2024, 11, 1, tzinfo=UTC))
        self.assertEqual([b.end for b in five], [datetime(2024, 11, 1, 7, 55), datetime(2024, 11, 1, 8)])

    def test_duplicate_unordered_and_unaligned_csv_are_rejected(self):
        cases = [(("2024-11-01T00:00:00Z", 100), ("2024-11-01T08:00:00+08:00", 101)),
                 (("2024-11-01T00:00:00Z", 100), ("2024-10-31T23:55:00Z", 101)),
                 (("2024-10-31T23:56:00Z", 100),)]
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                load_crypto_data(self.write_csv(rows), now=END)

    def test_json_symbol_currency_metadata_and_ohlcv_guards(self):
        cases = []
        for key, value in (("product", "ETH-USD"), ("asset_market", "ashare")):
            data = dataset(); data[key] = value; cases.append(data)
        for key, value in (("quote_to_usd", .9), ("multiplier", 100), ("short_allowed", True), ("tick", 0)):
            data = dataset(); data["instrument"][key] = value; cases.append(data)
        for key, value in (("close", float("nan")), ("high", 90), ("volume", -1), ("open", True)):
            data = dataset(); data["series"]["300"][0][key] = value; cases.append(data)
        for data in cases:
            with self.subTest(data=data), self.assertRaises(ValueError):
                load_crypto_data(self.write_json(data), now=END)

    def test_snapshot_capture_time_caps_data_and_preserves_warmup(self):
        data = dataset()
        data["series"]["86400"] = [row(END-10*86400), row(END-9*86400)]
        data["fetched_at"] = END-1
        five, thirty, daily = load_crypto_data(self.write_json(data), now=END+86400)
        self.assertEqual(len(five), 1)
        self.assertEqual(len(daily), 2)
        self.assertEqual(thirty, [])

    def test_json_duplicate_rows_and_wrong_timeframe_are_rejected(self):
        data = dataset([row(END), row(END)])
        with self.assertRaises(ValueError): load_crypto_data(self.write_json(data), now=END)
        data = dataset()
        data["series"]["300"][0]["seconds"] = 1800
        with self.assertRaises(ValueError): load_crypto_data(self.write_json(data), now=END)

    def test_empty_or_all_open_data_does_not_become_a_fake_feed(self):
        for rows in ([], [row(END+300)]):
            with self.assertRaises(ValueError): load_crypto_data(self.write_json(dataset(rows)), now=END)
        with self.assertRaises(ValueError):
            load_crypto_data(self.write_json(dataset()), now=datetime(2024, 11, 1))


class CryptoDownloadTests(unittest.TestCase):
    def test_pages_are_bounded_sorted_and_filter_provider_extras(self):
        request, calls = provider()
        data = fetch_crypto_history(days=2, now=END, request_json=request, throttle=0)
        self.assertEqual(data["source"], SOURCE)
        self.assertEqual(data["instrument"]["quote_to_usd"], 1)
        self.assertEqual(data["instrument"]["min_market_funds"], 10)
        self.assertEqual({k: len(v) for k, v in data["series"].items()}, {"300": 576, "1800": 300, "86400": 180})
        for path, params in calls:
            self.assertTrue(path.startswith("/products/BTC-USD"))
            if params:
                seconds = params["granularity"]
                start = datetime.fromisoformat(params["start"]).timestamp()
                end = datetime.fromisoformat(params["end"]).timestamp()
                self.assertLessEqual((end-start)/seconds, 299)
        for seconds, values in data["series"].items():
            self.assertTrue(all(v["end"] <= END for v in values))
            self.assertTrue(all(a["end"] < b["end"] for a,b in zip(values, values[1:])))

    def test_provider_missing_row_stays_missing(self):
        request, _ = provider()
        removed = False
        def sparse(path, params=None):
            nonlocal removed
            data = request(path, params)
            if params and params["granularity"] == 300 and not removed:
                data.pop(2); removed = True
            return data
        data = fetch_crypto_history(days=1, now=END, request_json=sparse, throttle=0)
        self.assertEqual(len(data["series"]["300"]), 287)

    def test_duplicate_provider_candles_and_invalid_specs_fail(self):
        request, _ = provider()
        def duplicate(path, params=None):
            data = request(path, params)
            return data+[data[1]] if params else data
        with self.assertRaises(ValueError):
            fetch_crypto_history(now=END, request_json=duplicate, throttle=0)
        for change in ({"quote_currency": "USDT"}, {"status": "offline"}, {"base_increment": "0"}, {"trading_disabled": True}):
            def bad(path, params=None):
                return {**request(path, params), **change}
            with self.subTest(change=change), self.assertRaises(ValueError):
                fetch_crypto_history(now=END, request_json=bad, throttle=0)

    def test_failure_leaves_no_snapshot_and_existing_file_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)/"history.json"
            with self.assertRaises(URLError):
                save_crypto_history(output, request_json=lambda *args: (_ for _ in ()).throw(URLError("fixture network failure")), throttle=0)
            self.assertFalse(output.exists())
            output.write_text("previous evidence")
            request, calls = provider()
            with self.assertRaises(FileExistsError): save_crypto_history(output, request_json=request, throttle=0)
            self.assertEqual(output.read_text(), "previous evidence")
            self.assertEqual(calls, [])

    def test_successful_saved_history_loads_through_public_api(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)/"history.json"
            request, _ = provider()
            metadata = save_crypto_history(output, days=1, now=END, request_json=request, throttle=0)
            five, thirty, daily = load_crypto_data(output, now=END)
            self.assertTrue(metadata["paper_only"])
            self.assertEqual((len(five), len(thirty), len(daily)), (288, 300, 180))

    def test_fixed_origin_get_only_and_no_order_route(self):
        with patch("quant_crypto.urlopen") as request:
            with self.assertRaises(ValueError): public_json("/orders")
            request.assert_not_called()
            response = request.return_value.__enter__.return_value
            response.read.return_value = b'{"id":"BTC-USD"}'
            self.assertEqual(public_json("/products/BTC-USD")["id"], "BTC-USD")
            args, kwargs = request.call_args
            self.assertEqual(args[0].get_method(), "GET")
            self.assertEqual(args[0].full_url, "https://api.exchange.coinbase.com/products/BTC-USD")
            self.assertEqual(kwargs["timeout"], 20)

    def test_fetch_limits_and_throttle_are_validated(self):
        for days in (0, 366, True, 1.5):
            with self.assertRaises(ValueError): fetch_crypto_history(days=days)
        for throttle in (-1, float("nan")):
            with self.assertRaises(ValueError): fetch_crypto_history(throttle=throttle)


class CryptoRefreshTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        request, _ = provider()
        self.seed = fetch_crypto_history(days=1, now=END, request_json=request, throttle=0)
        self.source, self.live = self.root/"user-history.json", self.root/"runner-live.json"
        self.source.write_text(json.dumps(self.seed), encoding="utf-8")

    def test_normal_refresh_only_reads_short_tails_and_deduplicates_revisions(self):
        request, calls = provider()
        original = json.dumps(self.seed, sort_keys=True)
        def revised(path, params=None):
            values = request(path, params)
            if params:
                for raw in values:
                    if raw[0]+params["granularity"] == END:
                        raw[2], raw[4] = 102, 101
            return values
        updated = update_crypto_history(self.seed, now=END+600, request_json=revised, throttle=0)
        self.assertEqual(json.dumps(self.seed, sort_keys=True), original)
        self.assertEqual(updated["fetched_at"], END+600)
        self.assertEqual(len(updated["series"]["300"]), 290)
        self.assertEqual(len(calls), 4)  # product plus one short page per timeframe
        self.assertEqual(updated["refresh_stats"]["300"]["new_bars"], 2)
        self.assertEqual(updated["refresh_stats"]["300"]["revised_bars"], 1)
        for seconds, values in updated["series"].items():
            ends = [r["end"] for r in values]
            self.assertEqual(len(ends), len(set(ends)))
            self.assertEqual(next(r["close"] for r in values if r["end"] == END), 101)
            self.assertTrue(all(end <= END+600 for end in ends))
        self.assertEqual(updated["series"]["300"][0], self.seed["series"]["300"][0])

    def test_gap_catchup_is_paged_and_has_every_new_closed_bar(self):
        request, calls = provider()
        now = END+2*86400+300
        updated = update_crypto_history(self.seed, now=now, request_json=request, throttle=0)
        values = updated["series"]["300"]
        self.assertEqual(len(values), 288+577)
        self.assertEqual(values[-1]["end"], now)
        self.assertTrue(all(b["end"]-a["end"] == 300 for a,b in zip(values, values[1:])))
        self.assertEqual(updated["refresh_stats"]["300"]["request_pages"], 2)
        self.assertEqual(updated["refresh_stats"]["300"]["new_bars"], 577)
        for _, params in calls:
            if params:
                span = datetime.fromisoformat(params["end"])-datetime.fromisoformat(params["start"])
                self.assertLessEqual(span.total_seconds()/params["granularity"], 299)

    def test_excessively_old_or_untrusted_seed_fails_before_network(self):
        request, calls = provider()
        with self.assertRaises(ValueError):
            update_crypto_history(self.seed, now=END+91*86400, request_json=request, throttle=0)
        bad = json.loads(json.dumps(self.seed))
        bad["source"] = "synthetic_test_fixture"
        with self.assertRaises(ValueError):
            update_crypto_history(bad, now=END+300, request_json=request, throttle=0)
        bad = json.loads(json.dumps(self.seed))
        bad["instrument"]["multiplier"] = True
        with self.assertRaises(ValueError):
            update_crypto_history(bad, now=END+300, request_json=request, throttle=0)
        self.assertEqual(calls, [])

    def test_future_seed_capture_and_open_seed_candle_are_rejected(self):
        request, calls = provider()
        bad = json.loads(json.dumps(self.seed)); bad["fetched_at"] = END+301
        with self.assertRaises(ValueError):
            update_crypto_history(bad, now=END+300, request_json=request, throttle=0)
        bad = json.loads(json.dumps(self.seed)); bad["series"]["300"].append(row(END+300))
        with self.assertRaises(ValueError):
            update_crypto_history(bad, now=END+300, request_json=request, throttle=0)
        self.assertEqual(calls, [])

    def test_missing_new_candle_pauses_refresh_without_inventing_it(self):
        request, _ = provider()
        def missing(path, params=None):
            values = request(path, params)
            if params and params["granularity"] == 300:
                values = [r for r in values if r[0] != END]
            return values
        with self.assertRaisesRegex(ValueError, "every newly closed candle"):
            update_crypto_history(self.seed, now=END+600, request_json=missing, throttle=0)

    def test_file_refresh_uses_own_live_copy_then_catches_up_from_it(self):
        request, _ = provider()
        source_bytes = self.source.read_bytes()
        first = refresh_crypto_file(self.source, self.live, now=END+300, request_json=request, throttle=0)
        second = refresh_crypto_file(self.source, self.live, now=END+600, request_json=request, throttle=0)
        self.assertEqual(first["counts"]["300"], 289)
        self.assertEqual(second["counts"]["300"], 290)
        self.assertEqual(second["updated_rows"]["300"]["new_bars"], 1)
        self.assertEqual(self.source.read_bytes(), source_bytes)
        five, _, _ = load_crypto_data(self.live, now=END+600)
        self.assertEqual(len(five), 290)
        self.assertEqual(list(self.root.glob(".czsc-crypto-*")), [])

    def test_any_network_failure_preserves_previous_live_and_source(self):
        self.live.write_bytes(self.source.read_bytes())
        source_bytes, live_bytes = self.source.read_bytes(), self.live.read_bytes()
        request, _ = provider()
        calls = 0
        def broken(path, params=None):
            nonlocal calls
            calls += 1
            if calls == 3:
                raise URLError("synthetic refresh failure after one successful timeframe")
            return request(path, params)
        with self.assertRaises(URLError):
            refresh_crypto_file(self.source, self.live, now=END+600, request_json=broken, throttle=0)
        self.assertEqual(self.source.read_bytes(), source_bytes)
        self.assertEqual(self.live.read_bytes(), live_bytes)
        self.assertEqual(list(self.root.glob(".czsc-crypto-*")), [])

    def test_source_same_as_output_and_wrong_live_identity_cannot_be_overwritten(self):
        request, calls = provider()
        with self.assertRaises(ValueError):
            refresh_crypto_file(self.source, self.source, now=END+300, request_json=request, throttle=0)
        bad = json.loads(json.dumps(self.seed)); bad["product"] = "ETH-USD"
        self.live.write_text(json.dumps(bad), encoding="utf-8")
        previous = self.live.read_bytes()
        with self.assertRaises(ValueError):
            refresh_crypto_file(self.source, self.live, now=END+300, request_json=request, throttle=0)
        self.assertEqual(self.live.read_bytes(), previous)
        self.assertEqual(calls, [])

    def test_atomic_replace_failure_preserves_previous_output(self):
        self.live.write_bytes(self.source.read_bytes())
        before = self.live.read_bytes()
        request, _ = provider()
        with patch("quant_crypto.os.replace", side_effect=PermissionError("synthetic lock")):
            with self.assertRaises(PermissionError):
                refresh_crypto_file(self.source, self.live, now=END+300, request_json=request, throttle=0)
        self.assertEqual(self.live.read_bytes(), before)
        self.assertEqual(list(self.root.glob(".czsc-crypto-*")), [])

    def test_concurrent_writer_is_detected_before_live_replacement(self):
        self.live.write_bytes(self.source.read_bytes())
        request, _ = provider()
        def changed(path, params=None):
            if params is None:
                self.live.write_text("synthetic concurrent writer changed this file")
            return request(path, params)
        with self.assertRaises(OSError):
            refresh_crypto_file(self.source, self.live, now=END+300, request_json=changed, throttle=0)
        self.assertEqual(self.live.read_text(), "synthetic concurrent writer changed this file")
        self.assertEqual(list(self.root.glob(".czsc-crypto-*")), [])


if __name__ == "__main__":
    unittest.main()
