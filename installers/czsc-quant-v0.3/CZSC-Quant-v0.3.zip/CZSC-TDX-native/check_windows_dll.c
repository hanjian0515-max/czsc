/* Windows loader diagnostic, no CRT and no account/data access. */
#include <windows.h>
#include <stdint.h>
DWORD _tls_index;

static void print(const char *message) {
    DWORD count = 0, written = 0;
    while (message[count]) ++count;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), message, count, &written, NULL);
}

static void print_number(DWORD value) {
    char buffer[16], reverse[16];
    unsigned n = 0, i = 0;
    do { reverse[n++] = (char)('0'+value%10); value /= 10; } while (value);
    while (n) buffer[i++] = reverse[--n];
    buffer[i] = 0;
    print(buffer);
}

#pragma pack(push,1)
typedef void (*Callback)(int,float*,float*,float*,float*);
typedef struct { unsigned short id; Callback function; } Function;
#pragma pack(pop)

void mainCRTStartup(void) {
#ifdef _WIN64
    print("CZSC DLL loader check: 64-bit\r\n");
#else
    print("CZSC DLL loader check: 32-bit\r\n");
#endif
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
    wchar_t path[32768];
    DWORD n = GetModuleFileNameW(NULL, path, 32000), start = 0;
    if (!n || n >= 32000) { print("Cannot locate diagnostic executable\r\n"); ExitProcess(2); }
    for (DWORD i = 0; i < n; ++i) if (path[i] == L'\\') start = i+1;
    const wchar_t *name = L"CZSCBridge.dll";
    while (*name) path[start++] = *name++;
    path[start] = 0;
    HMODULE module = LoadLibraryW(path);
    if (!module) {
        DWORD error = GetLastError();
        print("LOAD_FAILED Windows error "); print_number(error); print("\r\n");
        print("193: wrong bitness/invalid PE; 126: missing module/dependency; 1114: initialization failed\r\n");
        ExitProcess(error ? error : 3);
    }
    typedef BOOL (*Register)(Function **);
    Register reg = (Register)(uintptr_t)GetProcAddress(module, "RegisterTdxFunc");
    if (!reg) { print("EXPORT_MISSING RegisterTdxFunc\r\n"); FreeLibrary(module); ExitProcess(4); }
    Function *functions = NULL;
    if (!reg(&functions) || !functions) { print("REGISTER_FAILED\r\n"); FreeLibrary(module); ExitProcess(5); }
    for (unsigned i = 0; i < 31; ++i) {
        if (functions[i].id != i+1 || !functions[i].function) {
            print("ABI_TABLE_INVALID\r\n"); FreeLibrary(module); ExitProcess(6);
        }
    }
    if (functions[31].id != 0 || functions[31].function) {
        print("ABI_SENTINEL_INVALID\r\n"); FreeLibrary(module); ExitProcess(7);
    }
    float out = -99, a = 0, b = 0, c = 0;
    functions[0].function(1, &out, &a, &b, &c);
    if (out != 0) { print("CALLBACK_FAILED\r\n"); FreeLibrary(module); ExitProcess(8); }
    print("LOAD_OK\r\nREGISTER_OK: 31 functions\r\nCALLBACK_OK\r\n");
    print("This checks Windows loading only; Tongdaxin binding still needs verification.\r\n");
    FreeLibrary(module);
    ExitProcess(0);
}
