"""Runner and launch contracts: causal calls, freshness and isolated accounts."""
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch

from export_czsc import Candle
from quant_ledger import Config, QuantLedger
import quant_app
import quant_runner


def candles(count=5):
    start = datetime(2026, 11, 5, 9, 35)
    return [Candle(start + timedelta(minutes=5 * index), 10 + index * .1,
                   10.2 + index * .1, 9.8 + index * .1, 10 + index * .1, 100_000)
            for index in range(count)]


def signal(candle, action="buy", name="buy-1", symbol="sz000001"):
    result = {"id": name, "action": action, "at": quant_runner.candle_bar(candle)["end"], "symbol": symbol}
    if action == "buy":
        result["stop"] = 9.0
    return result


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.source = self.root / "folder & $(no shell)" / "fzline" / "sz000001.lc5"
        self.source.parent.mkdir(parents=True)
        self.source.touch()
        self.config = quant_runner.validate_config({"source": self.source, "ledger": self.root / "paper.sqlite", "capital": 100_000})
        self.ledger = QuantLedger(self.config["ledger"], Config(capital=100_000))

    def tearDown(self):
        self.ledger.close()
        self.directory.cleanup()

    def test_timestamp_converts_shanghai_to_utc(self):
        bar = quant_runner.candle_bar(candles(1)[0])
        self.assertEqual(datetime.fromtimestamp(bar["end"], timezone.utc), datetime(2026, 11, 5, 1, 35, tzinfo=timezone.utc))

    def test_index_selection_is_rejected_without_substitution(self):
        index = self.source.with_name("sz399001.lc5")
        index.touch()
        with self.assertRaisesRegex(ValueError, "指数"):
            quant_runner.validate_config({**self.config, "code": "399001", "source": index})
        self.assertEqual(quant_app.infer_source(index)["code"], "399001")

    def test_filename_cannot_be_mislabeled_as_another_stock(self):
        with self.assertRaisesRegex(ValueError, "完全一致"):
            quant_runner.validate_config({**self.config, "market": "sh", "code": "600000"})

    def test_crypto_requires_usd_and_own_source(self):
        source = self.root / "btc.json"
        source.touch()
        config = quant_runner.validate_config({**self.config, "asset_market": "crypto", "source": source, "code": "btc-usd"})
        self.assertEqual((config["currency"], config["symbol"]), ("USD", "BTC-USD"))
        with self.assertRaisesRegex(ValueError, "BTC-USD"):
            quant_runner.validate_config({**config, "code": "BTC-USDT"})

    def test_command_keeps_paths_as_arguments_and_mode_is_explicit(self):
        command = quant_app.build_command(self.config, root=self.root, python="python with spaces.exe")
        self.assertIsInstance(command, list)
        self.assertIn(str(self.source), command)
        self.assertEqual(command[command.index("--mode") + 1], "paper")
        self.assertIn("--watch", command)
        replay = quant_app.build_command({**self.config, "mode": "replay", "report": self.root / "report.json"})
        self.assertNotIn("--watch", replay)
        self.assertIn("--report", replay)

    def test_popen_disables_shell_and_detaches_stdin(self):
        control = quant_app.QuantControl.__new__(quant_app.QuantControl)
        control.root = self.root
        command = ["python", "quant_runner.py", "--source", str(self.source)]
        with patch.object(quant_app.subprocess, "Popen") as spawn:
            control._spawn(command)
        arguments, options = spawn.call_args
        self.assertEqual(arguments[0], command)
        self.assertIs(options["shell"], False)
        self.assertEqual(options["stdin"], subprocess.DEVNULL)
        self.assertEqual(options["stdout"], subprocess.PIPE)

    def test_first_observation_does_not_generate_or_fill_historical_signal(self):
        data = candles(2)
        now = quant_runner.candle_bar(data[-1])["end"] + 2
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for") as strategy:
            output = quant_runner.refresh(self.config, self.ledger, first=True, now=now)
        strategy.assert_not_called()
        self.assertEqual(output["status"], "initialized")
        self.assertFalse(output["ledger"]["pending"])
        self.assertEqual(output["ledger"]["execution_count"], 0)
        self.assertEqual(output["ledger"]["last_bars"]["sz000001"], now - 2)

    def test_stale_input_and_duplicate_polls_never_generate_new_signals(self):
        data = candles(2)
        now = quant_runner.candle_bar(data[-1])["end"]
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for") as strategy:
            quant_runner.refresh(self.config, self.ledger, first=True, now=now)
            duplicate = quant_runner.refresh(self.config, self.ledger, now=now + 5)
            stale = quant_runner.refresh(self.config, self.ledger, now=now + 91)
        strategy.assert_not_called()
        self.assertEqual(duplicate["status"], "waiting_bar")
        self.assertEqual(stale["status"], "paused_stale")
        self.assertEqual(stale["ledger"]["execution_count"], 0)

    def test_new_signal_waits_for_next_fresh_bar_and_never_fills_twice(self):
        data = candles(3)
        end = lambda index: quant_runner.candle_bar(data[index])["end"]
        with patch.object(quant_runner, "load_data", return_value=(data[:1], [], [])):
            quant_runner.refresh(self.config, self.ledger, first=True, now=end(0))
        with patch.object(quant_runner, "load_data", return_value=(data[:2], [], [])), patch.object(quant_runner, "signals_for", return_value=[signal(data[1])]):
            queued = quant_runner.refresh(self.config, self.ledger, now=end(1) + 2)
        self.assertFalse(queued["executions"])
        self.assertIn("sz000001", queued["ledger"]["pending"])
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for", return_value=[signal(data[1])]):
            filled = quant_runner.refresh(self.config, self.ledger, now=end(2) + 2)
            duplicate = quant_runner.refresh(self.config, self.ledger, now=end(2) + 3)
        self.assertEqual(len(filled["executions"]), 1)
        self.assertEqual(filled["executions"][0]["bar_end"], end(2))
        self.assertGreater(filled["executions"][0]["price"], data[2].close)
        self.assertEqual(duplicate["ledger"]["execution_count"], 1)
        self.assertTrue(filled["paper_only"])

    def test_latest_only_poll_does_not_backfill_older_signals(self):
        data = candles(4)
        with patch.object(quant_runner, "load_data", return_value=(data[:1], [], [])):
            quant_runner.refresh(self.config, self.ledger, first=True, now=quant_runner.candle_bar(data[0])["end"])
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for", return_value=[signal(data[1])]):
            output = quant_runner.refresh(self.config, self.ledger, now=quant_runner.candle_bar(data[-1])["end"])
        self.assertIsNone(output["signal"])
        self.assertFalse(output["ledger"]["positions"])
        self.assertFalse(output["ledger"]["pending"])

    def test_source_error_preserves_existing_ledger(self):
        before = self.ledger.snapshot()
        with patch.object(quant_runner, "load_data", side_effect=ValueError("缺少同证券日线")):
            output = quant_runner.refresh(self.config, self.ledger, first=True)
        self.assertEqual(output["status"], "error")
        self.assertIn("日线", output["errors"][0])
        self.assertEqual(output["ledger"], before)

    def test_conflicting_or_cross_symbol_signals_are_rejected(self):
        data = candles(1)
        with self.assertRaisesRegex(ValueError, "冲突"):
            quant_runner.signal_map([signal(data[0]), signal(data[0], action="sell", name="sell-1")])
        with self.assertRaisesRegex(ValueError, "证券"):
            quant_runner.signal_map([signal(data[0], symbol="sh600000")], "sz000001")

    def test_restart_preserves_position_and_does_not_replay_signals(self):
        data = candles(3)
        for index, candle in enumerate(data):
            bar = quant_runner.candle_bar(candle)
            self.ledger.process_bar("sz000001", bar, signal(data[1]) if index == 1 else None, now=bar["end"])
        self.ledger.close()
        self.ledger = QuantLedger(self.config["ledger"], Config(capital=100_000))
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for") as strategy:
            output = quant_runner.refresh(self.config, self.ledger, first=True, now=quant_runner.candle_bar(data[-1])["end"] + 2)
        strategy.assert_not_called()
        self.assertIn("sz000001", output["ledger"]["positions"])
        self.assertEqual(output["ledger"]["execution_count"], 1)

    def test_replay_uses_explicit_simulated_clock_and_retains_end_position(self):
        data = candles(4)
        source = self.root / "crypto.json"
        source.touch()
        config = quant_runner.validate_config({"source": source, "asset_market": "crypto", "code": "BTC-USD", "mode": "replay", "capital": 100_000, "ledger": self.root / "replay.sqlite"})
        with QuantLedger(config["ledger"], Config(market="crypto", mode="replay", capital=100_000)) as ledger:
            with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for", return_value=[signal(data[1], symbol="BTC-USD")]):
                output = quant_runner.replay(config, ledger, now=quant_runner.candle_bar(data[-1])["end"] + 1_000_000)
            self.assertEqual(output["status"], "replay_complete")
            self.assertEqual(output["execution_count"], 1)
            self.assertIn("BTC-USD", output["open_positions"])
            self.assertEqual(output["executions"][0]["bar_end"], quant_runner.candle_bar(data[2])["end"])
            self.assertEqual(output["final_equity"], ledger.snapshot()["equity"])

    def test_reports_are_created_without_overwriting(self):
        report = self.root / "results" / "run.json"
        quant_runner.write_report(report, {"paper_only": True, "final_equity": 123})
        with self.assertRaises(FileExistsError):
            quant_runner.write_report(report, {"final_equity": 456})
        self.assertEqual(json.loads(report.read_text(encoding="utf-8"))["final_equity"], 123)

    def test_online_crypto_uses_account_owned_copy_and_never_overwrites_seed(self):
        source = self.root / "btc.json"
        source.touch()
        config = quant_runner.validate_config({**self.config, "asset_market": "crypto", "source": source,
                                                "code": "BTC-USD", "online": True, "interval": None})
        self.assertEqual(config["interval"], 10)
        self.assertIn("--online", quant_app.build_command(config))
        owned = quant_runner.live_quote_path(config)
        self.assertNotEqual(owned, source)
        second = quant_runner.live_quote_path({**config, "ledger": str(self.root / "different.sqlite")})
        self.assertNotEqual(owned, second)
        with patch("quant_crypto.refresh_crypto_file") as refresh_file, patch("quant_crypto.load_crypto_data", return_value=([], [], [])) as load:
            quant_runner.load_data(config, 1_800_000_000)
        self.assertEqual(refresh_file.call_args.args[:2], (str(source), owned))
        self.assertEqual(load.call_args.args[0], owned)
        csv_source = source.with_suffix(".csv")
        csv_source.touch()
        with self.assertRaisesRegex(ValueError, "暖机"):
            quant_runner.validate_config({**config, "source": csv_source})

    def test_online_failure_does_not_fall_back_to_fresh_old_cache_or_fill(self):
        source = self.root / "btc.json"
        source.touch()
        config = quant_runner.validate_config({**self.config, "asset_market": "crypto", "source": source,
                                                "code": "BTC-USD", "online": True})
        ledger = Mock()
        ledger.snapshot.return_value = {"cash": 123}
        with patch("quant_crypto.refresh_crypto_file", side_effect=ValueError("HTTP 403")), patch("quant_crypto.load_crypto_data") as load:
            output = quant_runner.refresh(config, ledger)
        load.assert_not_called()
        ledger.process_bar.assert_not_called()
        self.assertEqual(output["status"], "error")
        self.assertIn("403", output["errors"][0])

    def test_slow_signal_computation_rechecks_wall_clock_before_execution(self):
        data = candles(2)
        first_end, latest_end = [quant_runner.candle_bar(c)["end"] for c in data]
        self.ledger.process_bar("sz000001", quant_runner.candle_bar(data[0]), now=first_end)
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner, "signals_for", return_value=[signal(data[1])]), patch.object(quant_runner.time, "time", side_effect=[latest_end + 1, latest_end + 1, latest_end + 91]):
            output = quant_runner.refresh(self.config, self.ledger)
        self.assertEqual(output["status"], "paused_stale")
        self.assertIsNone(output["signal"])
        self.assertFalse(output["ledger"]["pending"])

    def test_zero_interval_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "轮询间隔"):
            quant_runner.validate_config({**self.config, "interval": 0})

    def test_other_symbol_scope_is_rejected_before_loading_or_processing(self):
        bar = quant_runner.candle_bar(candles(1)[0])
        self.ledger.process_bar("sh600000", bar, now=bar["end"])
        before = self.ledger.snapshot()
        with patch.object(quant_runner, "load_data") as load:
            output = quant_runner.refresh(self.config, self.ledger, first=True, now=bar["end"] + 1)
        load.assert_not_called()
        self.assertEqual(output["status"], "error")
        self.assertIn("新建独立账本", output["errors"][0])
        self.assertEqual(output["ledger"], before)

    def test_replay_rejects_old_symbol_even_when_account_is_flat(self):
        bar = quant_runner.candle_bar(candles(1)[0])
        self.ledger.process_bar("sh600000", bar, now=bar["end"])
        self.assertFalse(self.ledger.snapshot()["positions"])
        with patch.object(quant_runner, "load_data") as load, self.assertRaisesRegex(ValueError, "其他证券"):
            quant_runner.replay({**self.config, "mode": "replay"}, self.ledger, now=bar["end"])
        load.assert_not_called()

    def test_gui_download_and_runner_are_mutually_exclusive(self):
        self.assertIsNone(quant_app.activity_error(False, False))
        self.assertIn("下载", quant_app.activity_error(False, True))
        self.assertIn("已有模拟", quant_app.activity_error(True, False))
        self.assertIsNotNone(quant_app.activity_error(True, True))
        control = quant_app.QuantControl.__new__(quant_app.QuantControl)
        control.process, control.fetch_process = None, object()
        control.append_log = Mock()
        control._spawn = Mock()
        control.start()
        control._spawn.assert_not_called()
        control.process, control.fetch_process = object(), None
        control.fetch_crypto()
        control._spawn.assert_not_called()

    def test_default_ledger_includes_explicit_symbol(self):
        path = quant_app.default_ledger(self.root, "ashare", "paper", symbol="sz000001")
        self.assertIn("sz000001", path.name)

    def test_slow_http_first_poll_does_not_resume_pending_with_old_clock(self):
        data = candles(3)
        end = lambda index: quant_runner.candle_bar(data[index])["end"]
        self.ledger.process_bar("sz000001", quant_runner.candle_bar(data[0]), now=end(0))
        self.ledger.process_bar("sz000001", quant_runner.candle_bar(data[1]), signal(data[1]), now=end(1))
        self.assertTrue(self.ledger.snapshot()["pending"])
        with patch.object(quant_runner, "load_data", return_value=(data, [], [])), patch.object(quant_runner.time, "time", side_effect=[end(2) + 1, end(2) + 91]):
            output = quant_runner.refresh(self.config, self.ledger, first=True)
        self.assertEqual(output["status"], "paused_stale")
        self.assertFalse(output["executions"])
        self.assertFalse(output["ledger"]["pending"])

    def test_default_accounts_do_not_mix_market_or_mode(self):
        now = datetime(2026, 11, 5, 9, 35)
        paths = {quant_app.default_ledger(self.root, market, mode, now) for market in ("ashare", "crypto") for mode in ("paper", "replay")}
        self.assertEqual(len(paths), 4)
        self.assertIn("20261105", str(quant_app.default_ledger(self.root, "crypto", "replay", now)))

    def test_ui_rechecks_freshness_if_worker_stops_producing_output(self):
        message = quant_app.status_message({"mode": "paper", "source_at_utc": 1000, "message": "fresh"}, running=True, now=1091)
        self.assertIn("暂停", message)
        stopped = quant_app.status_message({"mode": "replay", "status": "replay_progress"}, running=False)
        self.assertIn("已停止", stopped)


if __name__ == "__main__":
    unittest.main()
