"""Synthetic causal/adapter tests; these are not market or profit validation."""
from dataclasses import replace
from datetime import datetime, timedelta, timezone
import math
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

import quant_strategy as quant
import tdx_local


BASE = int(datetime(2026, 11, 4, 2, tzinfo=timezone.utc).timestamp())


def synthetic_candle(at=BASE, low=12.5):
    stamp = datetime.fromtimestamp(at, timezone.utc).astimezone(quant.export_czsc.SHANGHAI).replace(tzinfo=None)
    return quant.Candle(stamp, low + .1, low + .5, low, low + .2, 100)


def synthetic_pen(direction, high, low, start, end):
    return quant.PenSnapshot(direction, high, low, start, end)


def synthetic_candidate():
    values = [("up", 11, 8), ("down", 12, 9), ("up", 11.5, 8.5),
              ("up", 14, 10), ("down", 14, 12)]
    return [synthetic_pen(d, hi, lo, BASE - (10-i)*1800, BASE - (9-i)*1800)
            for i, (d, hi, lo) in enumerate(values)]


DAILY_UP = [synthetic_pen("up", 20, 7, BASE-20*86400, BASE-86400)]
OLD_UP = synthetic_pen("up", 13, 12, BASE-900, BASE-600)
NEW_UP = synthetic_pen("up", 14, 12.1, BASE+300, BASE+900)


class StrategyRuleTests(unittest.TestCase):
    def confirm(self, strategy=None, daily=DAILY_UP):
        strategy = strategy or quant.ExperimentalStrategy("sz000001")
        strategy.observe(synthetic_candle(), [OLD_UP], synthetic_candidate(), daily)
        return strategy

    def test_candidate_buy_occurs_at_observation_not_pen_extreme_and_stable_ids(self):
        results = []
        for _ in range(2):
            strategy = self.confirm()
            result = strategy.observe(synthetic_candle(BASE+1200), [NEW_UP], synthetic_candidate(), DAILY_UP)
            self.assertEqual(len(result), 1)
            buy = result[0]
            self.assertEqual(buy["action"], "buy")
            self.assertEqual(buy["at"], BASE+1200)
            self.assertGreater(buy["at"], NEW_UP.end)
            self.assertEqual(buy["stop"], 11.99)
            self.assertIsNone(strategy.candidate)
            self.assertEqual(strategy.observe(synthetic_candle(BASE+1500), [NEW_UP],
                                              synthetic_candidate(), DAILY_UP), [])
            results.append(result)
        self.assertEqual(results[0], results[1])

    def test_overlap_departure_and_pullback_must_all_be_strict(self):
        invalid = []
        original = synthetic_candidate()
        case = original.copy()
        case[1] = replace(case[1], low=11)  # ZD == ZG.
        invalid.append(case)
        case = original.copy()
        case[3] = replace(case[3], high=11)  # No upward departure.
        invalid.append(case)
        case = original.copy()
        case[4] = replace(case[4], low=11)  # Pullback touches the center.
        invalid.append(case)
        case = original.copy()
        case[4] = replace(case[4], direction="up")
        invalid.append(case)
        for pens in invalid:
            with self.subTest(pens=pens):
                strategy = quant.ExperimentalStrategy("sz000001")
                strategy.observe(synthetic_candle(), [OLD_UP], pens, DAILY_UP)
                self.assertIsNone(strategy.candidate)

    def test_stop_boundary_and_three_hour_expiry_do_not_resurrect(self):
        for at, low in ((BASE+300, 11.99), (BASE+300, 10.9), (BASE+3*3600, 12.5)):
            with self.subTest(at=at, low=low):
                strategy = self.confirm()
                self.assertEqual(strategy.observe(synthetic_candle(at, low), [], synthetic_candidate(), DAILY_UP), [])
                self.assertIsNone(strategy.candidate)
                self.assertEqual(strategy.observe(synthetic_candle(at+300), [NEW_UP],
                                                  synthetic_candidate(), DAILY_UP), [])
                self.assertIsNone(strategy.candidate)

    def test_daily_up_and_new_five_start_strictly_after_confirmation(self):
        strategy = self.confirm(daily=[])
        self.assertEqual(strategy.observe(synthetic_candle(BASE+1200), [NEW_UP],
                                          synthetic_candidate(), []), [])
        # The same up pen cannot become a new trigger when the daily filter changes.
        self.assertEqual(strategy.observe(synthetic_candle(BASE+1500), [NEW_UP],
                                          synthetic_candidate(), DAILY_UP), [])
        strategy = self.confirm()
        equal_start = replace(NEW_UP, start=BASE)
        self.assertEqual(strategy.observe(synthetic_candle(BASE+1200), [equal_start],
                                          synthetic_candidate(), DAILY_UP), [])
        later = replace(NEW_UP, start=BASE+600, end=BASE+1500)
        self.assertEqual(strategy.observe(synthetic_candle(BASE+1800), [later],
                                          synthetic_candidate(), DAILY_UP)[0]["action"], "buy")

    def test_changed_structure_gets_new_confirmation_clock(self):
        strategy = self.confirm()
        changed = synthetic_candidate()
        changed[-1] = replace(changed[-1], high=14.1)
        strategy.observe(synthetic_candle(BASE+600), [OLD_UP], changed, DAILY_UP)
        self.assertEqual(strategy.candidate.confirmed_at, BASE+600)
        self.assertEqual(strategy.observe(synthetic_candle(BASE+1200), [NEW_UP], changed, DAILY_UP), [])
        newer = replace(NEW_UP, start=BASE+900, end=BASE+1800)
        self.assertEqual(strategy.observe(synthetic_candle(BASE+2100), [newer], changed, DAILY_UP)[0]["action"], "buy")

    def test_down_pen_emits_one_sell_at_first_observation(self):
        strategy = quant.ExperimentalStrategy("sz000001")
        down = synthetic_pen("down", 15, 12, BASE-1800, BASE-300)
        events = strategy.observe(synthetic_candle(), [down], [], [])
        self.assertEqual(events[0]["action"], "sell")
        self.assertEqual(events[0]["at"], BASE)
        self.assertEqual(strategy.observe(synthetic_candle(BASE+300), [down], [], []), [])


class LocalDataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root/"fzline").mkdir()
        (self.root/"lday").mkdir()
        self.path = self.root/"fzline"/"sz000001.lc5"
        self.day = self.root/"lday"/"sz000001.day"
        stamps = [datetime(2026, 11, 4, 9, 35)+timedelta(minutes=5*i) for i in range(6)]
        records = []
        for stamp in stamps:
            day = (stamp.year-2004)*2048+stamp.month*100+stamp.day
            records.append(tdx_local.LC5_RECORD.pack(day, stamp.hour*60+stamp.minute,
                                                    10, 11, 9, 10.5, 1000, 100, 0))
        self.path.write_bytes(b"".join(records))
        self.day.write_bytes(tdx_local.DAY_RECORD.pack(20261103, 1000, 1100, 900, 1050, 1000, 100, 0))

    def tearDown(self):
        self.temp.cleanup()

    def test_reads_same_security_daily_and_exact_closed_30m(self):
        five, thirty, daily = quant.load_quant_data(self.path, "000001", "sz", datetime(2026, 11, 4, 10))
        self.assertEqual((len(five), len(thirty), len(daily)), (6, 1, 1))
        self.assertIsInstance(five[0], quant.Candle)
        self.assertIsNone(five[0].end.tzinfo)
        self.assertEqual(thirty[0].end, datetime(2026, 11, 4, 10))
        self.assertEqual(daily[0].close, 10.5)

    def test_mismatch_missing_daily_and_insufficient_30m_fail(self):
        with self.assertRaisesRegex(ValueError, "文件名"):
            quant.load_quant_data(self.path, "sh600000")
        with self.assertRaisesRegex(ValueError, "市场"):
            quant.load_quant_data(self.path, "sz000001", "sh")
        with self.assertRaisesRegex(ValueError, "30分钟"):
            quant.load_quant_data(self.path, "sz000001", now=datetime(2026, 11, 4, 9, 59))
        self.day.unlink()
        with self.assertRaisesRegex(FileNotFoundError, "日线"):
            quant.load_quant_data(self.path, "sz000001")


class CausalEngineTests(unittest.TestCase):
    def test_spy_higher_frames_never_receive_future_bars(self):
        fed, observations = {}, []

        class FakeEngine:
            def __init__(self, bars, **kwargs):
                self.freq = bars[0].freq
                self.bi_list = []
                fed[self.freq] = list(bars)

            def update(self, raw):
                fed[self.freq].append(raw)

        class SpyStrategy:
            def __init__(self, symbol):
                pass

            def observe(self, candle, *pens):
                snapshots = {key: [r.dt for r in values] for key, values in fed.items()}
                observations.append((candle.end, snapshots))
                return []

        native = SimpleNamespace(Freq=SimpleNamespace(F5="5", F30="30", D="D"),
                                 Direction=SimpleNamespace(Up="up"), RawBar=lambda **kw: SimpleNamespace(**kw),
                                 CZSC=FakeEngine)

        def bars(stamps):
            return [quant.Candle(stamp, 10, 11, 9, 10, 100) for stamp in stamps]

        five = bars([datetime(2026, 11, 4, 10), datetime(2026, 11, 4, 14, 55),
                     datetime(2026, 11, 4, 15), datetime(2026, 11, 5, 10)])
        thirty = bars([datetime(2026, 11, 4, 10), datetime(2026, 11, 4, 15), datetime(2026, 11, 5, 10, 30)])
        daily = bars([datetime(2026, 11, 3, 15), datetime(2026, 11, 4, 15), datetime(2026, 11, 5, 15)])
        with patch.object(quant.export_czsc, "_native", return_value=native), \
                patch.object(quant, "ExperimentalStrategy", SpyStrategy):
            self.assertEqual(quant.signal_series(five, thirty, daily, "BTC-USD"), [])
        for current, snapshot in observations:
            self.assertTrue(all(stamp <= current for values in snapshot.values() for stamp in values))
        self.assertEqual(observations[1][1]["D"], [datetime(2026, 11, 3, 15)])
        self.assertEqual(observations[2][1]["D"], [datetime(2026, 11, 3, 15), datetime(2026, 11, 4, 15)])
        self.assertEqual(len(fed["30"]), 2)
        self.assertEqual(len(fed["D"]), 2)

    def test_native_snapshots_drop_last_mutable_pen(self):
        native = SimpleNamespace(Direction=SimpleNamespace(Up="up"))
        pens = [SimpleNamespace(direction="up", high=13, low=10,
                                fx_a=SimpleNamespace(dt=datetime(2026, 11, 1, 10)),
                                fx_b=SimpleNamespace(dt=datetime(2026, 11, 2, 10))) for _ in range(3)]
        snapshots = quant._pens(SimpleNamespace(bi_list=pens), native)
        self.assertEqual(len(snapshots), 2)
        self.assertEqual(snapshots[0].end, int(datetime(2026, 11, 2, 2, tzinfo=timezone.utc).timestamp()))

    def test_bad_order_and_timezone_rejected(self):
        a = synthetic_candle()
        with self.assertRaisesRegex(ValueError, "递增"):
            quant.signal_series([a, a], [], [], "sz000001")
        with self.assertRaisesRegex(ValueError, "无时区"):
            quant.signal_series([replace(a, end=a.end.replace(tzinfo=timezone.utc))], [], [], "sz000001")

    def test_actual_native_warmup_and_recomputation_are_causal(self):
        # Continuous synthetic bars exercise the engine, not an exchange calendar.
        five = []
        start = datetime(2026, 1, 1, 9, 35)
        for i in range(600):
            close = 20+2*math.sin(i*math.pi/12)+.2*math.sin(i*.13)
            five.append(quant.Candle(start+timedelta(minutes=5*i), close-.03,
                                     close+.2, close-.2, close, 100))
        thirty = []
        for i in range(0, len(five), 6):
            group = five[i:i+6]
            thirty.append(quant.Candle(group[-1].end, group[0].open, max(c.high for c in group),
                                       min(c.low for c in group), group[-1].close, 600))
        native = quant.export_czsc._native()
        self.assertEqual(native.__version__, "1.0.2")
        self.assertEqual(quant.signal_series(five[:5], [], [], "sz000001"), [])
        events = quant.signal_series(five, thirty, [], "sz000001")
        self.assertTrue(events, "The real native engine must form lagged synthetic down pens")
        self.assertTrue(all(event["action"] == "sell" for event in events))
        cutoff = quant._utc(five[299].end)
        early = quant.signal_series(five[:300], thirty, [], "sz000001")
        self.assertEqual(early, [event for event in events if event["at"] <= cutoff])
        self.assertEqual(events, quant.signal_series(five, thirty, [], "sz000001"))
        self.assertEqual(len({event["id"] for event in events}), len(events))


if __name__ == "__main__":
    unittest.main()
