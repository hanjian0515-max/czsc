"""Installer packaging/real PE checks, not Windows installation execution."""
from __future__ import annotations

import hashlib
import importlib.util
import io
import os
from pathlib import Path
import stat
import struct
import subprocess
import sys
import tempfile
import unittest
import warnings
from zipfile import ZipFile, ZipInfo, ZIP_STORED, ZIP_DEFLATED

from build_installer import (MAGIC, MAX_PAYLOAD, PRODUCT_ROOT, TRAILER,
    build_installer, extract_payload, inspect_pe, powershell_script,
    validate_payload, _safe_member)


def payload(files=None, *, manifest=None, extra=None, compression=ZIP_DEFLATED):
    members = {"INSTALL_AND_RUN.cmd": b"@echo off\r\necho SYNTHETIC TEST ONLY\r\n",
               "README.md": b"Synthetic packaging fixture, not a product release.\n",
               "app.py": b"print('synthetic fixture only')\n"}
    if files:
        members.update(files)
    lines = "".join(hashlib.sha256(data).hexdigest()+"  "+name+"\n"
                    for name, data in sorted(members.items()))
    members["SHA256SUMS.txt"] = lines.encode() if manifest is None else manifest
    result = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with ZipFile(result, "w", compression=compression) as archive:
            for name, data in members.items():
                archive.writestr(PRODUCT_ROOT+"/"+name, data)
            for name, data in extra or []:
                archive.writestr(name, data)
    return result.getvalue()


class PayloadTests(unittest.TestCase):
    def test_valid_payload_accepts_only_manifest_covered_program_files(self):
        files = {"quant_app.py": b"# fixture\n", "bin/x86/CZSCBridge.dll": b"PE fixture bytes",
                 "formulas/gbk/CZSCMAIN.txt": b"X:C;\r\n"}
        actual = validate_payload(payload(files))
        self.assertEqual(actual["quant_app.py"], hashlib.sha256(files["quant_app.py"]).hexdigest())
        self.assertIn("bin/x86/CZSCBridge.dll", actual)
        self.assertNotIn("SHA256SUMS.txt", actual)

    def test_runtime_venv_quotes_configs_and_unknown_payload_paths_are_refused(self):
        for relative in ("runtime/account.sqlite", ".venv/Scripts/python.exe", ".env",
                         "market.csv", "user.json", "data/history.csv", "private/key.pem"):
            with self.subTest(relative=relative), self.assertRaises(ValueError):
                validate_payload(payload({relative: b"never overwrite"}))

    def test_windows_traversal_absolute_reserved_and_ambiguous_names_are_refused(self):
        for name in ("../app.py", "/tmp/app.py", "C:/app.py",
                     PRODUCT_ROOT+"/../app.py", PRODUCT_ROOT+"/bin/../../app.py",
                     PRODUCT_ROOT+"\\app.py", PRODUCT_ROOT+"/NUL.py",
                     PRODUCT_ROOT+"/app.py.", PRODUCT_ROOT+"/app.py ",
                     PRODUCT_ROOT+"/app.py:stream", PRODUCT_ROOT+"//app.py"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                validate_payload(payload(extra=[(name, b"bad")]))

    def test_windows_case_duplicates_are_refused(self):
        with self.assertRaisesRegex(ValueError, "Duplicate Windows"):
            validate_payload(payload(extra=[(PRODUCT_ROOT+"/APP.py", b"bad duplicate")]))

    def test_symlink_and_special_files_are_refused(self):
        for mode in (stat.S_IFLNK, stat.S_IFIFO):
            info = ZipInfo(PRODUCT_ROOT+"/app.py")
            info.external_attr = (mode|0o600) << 16
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                _safe_member(info)

    def test_manifest_requires_correct_hashes_and_complete_file_set(self):
        for manifest in (b"", b"not a checksum\n", b"0"*64+b"  app.py\n"):
            with self.subTest(manifest=manifest), self.assertRaises(ValueError):
                validate_payload(payload(manifest=manifest))
        valid = validate_payload(payload())
        lines = "".join(digest+"  "+name+"\n" for name,digest in valid.items()).encode()
        with self.assertRaises(ValueError):
            validate_payload(payload(manifest=lines+lines))

    def test_corrupt_crc_and_truncated_or_trailing_zip_data_are_refused(self):
        original = payload(compression=ZIP_STORED)
        corrupted = original.replace(b"print('synthetic fixture only')", b"print('corrupted fixture only')", 1)
        self.assertNotEqual(corrupted, original)
        for value in (corrupted, original[:-8], original+b"trailing", b"leading"+original, b"not a zip"):
            with self.subTest(length=len(value)), self.assertRaises(ValueError):
                validate_payload(value)

    def test_builder_failure_does_not_replace_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, destination = root/"input.zip", root/"existing.exe"
            source.write_bytes(payload())
            destination.write_bytes(b"preserved prior installer")
            with self.assertRaises(FileExistsError):
                build_installer(source, destination)
            self.assertEqual(destination.read_bytes(), b"preserved prior installer")
            source.write_bytes(b"not a zip")
            target = root/"new.exe"
            with self.assertRaises(ValueError):
                build_installer(source, target)
            self.assertFalse(target.exists())


class TrailerAndScriptTests(unittest.TestCase):
    def test_trailer_roundtrip_and_bounds(self):
        content = payload()
        pe = b"MZ"+b"\0"*126
        container = pe+content+TRAILER.pack(MAGIC, len(pe), len(content))
        self.assertEqual(extract_payload(container), content)
        invalid = [b"short", container[:-1], container+b"certificate bytes"]
        for magic, offset, length in ((b"badmagic", 128, len(content)), (MAGIC, 0, len(content)),
                                       (MAGIC, len(container)+1, 1), (MAGIC, 128, 0),
                                       (MAGIC, 128, MAX_PAYLOAD+1), (MAGIC, 128, len(content)+1)):
            invalid.append(pe+content+TRAILER.pack(magic, offset, length))
        for value in invalid:
            with self.subTest(size=len(value)), self.assertRaises(ValueError):
                extract_payload(value)

    def test_runtime_checksums_and_environment_paths_do_not_change_execution_policy(self):
        digest = hashlib.sha256(b"fixture").hexdigest()
        script = powershell_script(digest)
        self.assertIn("Get-FileHash -LiteralPath $env:CZSC_SETUP_ZIP", script)
        self.assertIn(digest, script)
        self.assertLess(script.index("Payload checksum mismatch"), script.index("Expand-Archive"))
        self.assertIn("Installed file checksum mismatch", script)
        self.assertIn("ReparsePoint", script)
        self.assertIn("-DestinationPath $dest", script)
        self.assertIn("GetFolderPath('Desktop')", script)
        self.assertIn("-not (Test-Path -LiteralPath $link)", script)
        self.assertIn("$shortcut.TargetPath=Join-Path $root 'INSTALL_AND_RUN.cmd'", script)
        self.assertNotIn("ExecutionPolicy", script)
        # User paths (including Unicode, spaces and apostrophes) are carried
        # by Win32 environment variables and never interpolated into source.
        for name in ("C:\\Users\\O'Neil\\AppData", "C:\\用户 空格\\缓存"):
            self.assertNotIn(name, script)
        for bad in ("", "f"*63, "f"*65, "A"*64, "'; bad command #"):
            with self.subTest(digest=bad), self.assertRaises(ValueError):
                powershell_script(bad)

    def test_pe_inspector_rejects_non_pe_and_truncated_headers(self):
        for value in (b"", b"not pe", b"MZ", b"MZ"+b"\0"*80):
            with self.subTest(length=len(value)), self.assertRaises(ValueError):
                inspect_pe(value)


class RealCrossBuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if importlib.util.find_spec("ziglang"):
            cls.python = sys.executable
        else:
            cls.python = os.environ.get("CZSC_ZIG_PYTHON")
        if not cls.python or not Path(cls.python).is_file():
            raise unittest.SkipTest("Set CZSC_ZIG_PYTHON to the Python containing ziglang==0.13.0")
        cls.temporary = tempfile.TemporaryDirectory(prefix="czsc-installer-cross-test-")
        root = Path(cls.temporary.name)
        cls.payload = payload()
        cls.source, cls.destination = root/"synthetic.zip", root/"synthetic-setup.exe"
        cls.source.write_bytes(cls.payload)
        command = [cls.python, str(Path(__file__).with_name("build_installer.py")),
                   "--payload", str(cls.source), "--output", str(cls.destination)]
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        cls.output = result.stdout
        cls.binary = cls.destination.read_bytes()

    @classmethod
    def tearDownClass(cls):
        if hasattr(cls, "temporary"):
            cls.temporary.cleanup()

    def test_actual_x86_kernel32_bootstrap_embeds_exact_payload_and_hash(self):
        self.assertEqual(extract_payload(self.binary), self.payload)
        _, offset, _ = TRAILER.unpack_from(self.binary, len(self.binary)-TRAILER.size)
        bootstrap = self.binary[:offset]
        info = inspect_pe(bootstrap)
        self.assertEqual(info["architecture"], "x86")
        self.assertEqual([name.lower() for name in info["imports"]], ["kernel32.dll"])
        digest = hashlib.sha256(self.payload).hexdigest()
        self.assertIn(digest.encode("utf-16le"), bootstrap)
        self.assertIn(f"size: {len(self.binary)}\n", self.output)
        self.assertIn(f"bootstrap_size: {len(bootstrap)}\n", self.output)

    def test_rebuilding_cannot_overwrite_verified_artifact(self):
        before = hashlib.sha256(self.binary).hexdigest()
        result = subprocess.run([self.python, str(Path(__file__).with_name("build_installer.py")),
                                 "--payload", str(self.source), "--output", str(self.destination)],
                                text=True, capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(hashlib.sha256(self.destination.read_bytes()).hexdigest(), before)


if __name__ == "__main__":
    unittest.main()
