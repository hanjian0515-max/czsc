"""Independent chart aids around native CZSC 1.0.2 BI and ZS objects.

The red/blue lines are explicitly defined drawing aids, not native segments.
The MACD labels are divergence *candidates*, not formal Chan divergences or
trade signals.  Only drawings may revise; event flags and Fibonacci snapshots
are calculated at the bar when the information first becomes available.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import math
import struct

from export_czsc import (Candle, HEADER, PERIODS, SHANGHAI, UTC, _event_key,
                         _local_now, _native, instrument_key)

MAGIC = b"CZTDV02\0"
VERSION = 2
RECORD = struct.Struct("<II18f")
FIELDS = ("redPrice", "redKind", "bluePrice", "blueKind", "boxHigh", "boxLow",
          "boxID", "divTopFlag", "divBottomFlag", "expandFlag", "fib382",
          "fib500", "fib618", "fib786", "swingHigh", "swingLow", "boxStartFlag",
          "boxEndFlag")
_FIELD = {name: index + 2 for index, name in enumerate(FIELDS)}
_RATIOS = (0.382, 0.5, 0.618, 0.786)


def _macd_areas(candles: list[Candle]) -> tuple[list[float], list[float]]:
    """Prefix sums of positive/negative 2*(EMA12-EMA26-EMA9(DIF)).

    The first close seeds both price EMAs; DEA starts at the resulting zero
    DIF. Each array begins with zero so endpoint-inclusive BI areas use
    prefix[end + 1] - prefix[start]. No library warm-up or future prices.
    """
    positive, negative = [0.0], [0.0]
    fast = slow = candles[0].close
    dea = 0.0
    for candle in candles:
        fast += (candle.close - fast) * (2.0 / 13.0)
        slow += (candle.close - slow) * (2.0 / 27.0)
        dif = fast - slow
        dea += (dif - dea) * (2.0 / 10.0)
        histogram = 2.0 * (dif - dea)
        positive.append(positive[-1] + max(histogram, 0.0))
        negative.append(negative[-1] + max(-histogram, 0.0))
    return positive, negative


def _area(bi, index, positive, negative, up: bool) -> float:
    start, end = index[bi.fx_a.dt], index[bi.fx_b.dt]
    totals = positive if up else negative
    return totals[end + 1] - totals[start]


def _endpoints(bis, index, native) -> list[tuple[int, float, float]]:
    points = {}
    for bi in bis:
        for point in (bi.fx_a, bi.fx_b):
            if point.dt in index:
                points[index[point.dt]] = (index[point.dt], float(point.fx),
                                          1.0 if point.mark == native.Mark.G else -1.0)
    return [points[i] for i in sorted(points)]


def _swing_points(points) -> list[tuple[int, float, float]]:
    """Thin endpoints using three adjacent tops or three adjacent bottoms.

    An interior top must be >= its preceding top and > its following top;
    a bottom uses <= and <.  First/last native endpoints anchor the window.
    Adjacent interior candidates of the same kind collapse to the more
    extreme one (latest wins ties). A same-kind boundary pair keeps both
    anchors and inserts the most extreme opposite native endpoint between
    them. This is a drawing definition, never a native XD.
    """
    if len(points) < 3:
        return points[:]
    candidates = {points[0][0]: points[0], points[-1][0]: points[-1]}
    for kind in (-1.0, 1.0):
        same = [p for p in points if p[2] == kind]
        for before, middle, after in zip(same, same[1:], same[2:]):
            if ((kind > 0 and middle[1] >= before[1] and middle[1] > after[1]) or
                    (kind < 0 and middle[1] <= before[1] and middle[1] < after[1])):
                candidates[middle[0]] = middle
    result = []
    for point in sorted(candidates.values()):
        if result and point[2] == result[-1][2]:
            if len(result) == 1 or point[0] == points[-1][0]:
                between = [p for p in points if result[-1][0] < p[0] < point[0]
                           and p[2] != point[2]]
                if between:
                    result.append(min(between, key=lambda p: p[1]*point[2]))
                    result.append(point)
            elif (point[1] - result[-1][1]) * point[2] >= 0:
                result[-1] = point
        else:
            result.append(point)
    return result


def _draw_boxes(records, centers, candles) -> int:
    """Latest native center wins overlaps; mark every visible fragment."""
    ordered = sorted(centers, key=lambda center: (center.sdt, center.edt))
    for box_id, center in enumerate(ordered, 1):
        for row, candle in zip(records, candles):
            if center.sdt <= candle.end <= center.edt:
                row[_FIELD["boxHigh"]] = float(center.zg)
                row[_FIELD["boxLow"]] = float(center.zd)
                row[_FIELD["boxID"]] = float(box_id)
    segments = 0
    for i, row in enumerate(records):
        identity = row[_FIELD["boxID"]]
        if identity:
            if i == 0 or records[i-1][_FIELD["boxID"]] != identity:
                row[_FIELD["boxStartFlag"]] = 1.0
                segments += 1
            if i + 1 == len(records) or records[i+1][_FIELD["boxID"]] != identity:
                row[_FIELD["boxEndFlag"]] = 1.0
    return segments


def visual_cache(candles: list[Candle], code: str, market: str, period: str,
                 now: datetime | None = None, min_bi_len: int = 6,
                 max_bi_num: int = 100) -> tuple[bytes, dict]:
    """Build ``<instrumentKey>_<tdxPeriod>_visual.bin`` contents and metadata.

    DLL functions 11..28 correspond to FIELDS, in order. The binary header is
    the 40-byte base-cache header with a distinct 8-byte magic and version 2;
    records are 80 bytes. Caller owns atomic publication of the sidecar.
    """
    if not candles:
        raise ValueError("No candles")
    key = instrument_key(code, market)
    if period not in PERIODS or min_bi_len < 3 or max_bi_num < 2:
        raise ValueError("Invalid period or CZSC parameters")
    wall_now = _local_now(now)
    for candle in candles:
        if candle.end.tzinfo is not None or candle.end > wall_now.replace(tzinfo=None):
            raise ValueError("visual_cache accepts closed, naive Shanghai candles only")
        if not 1970 <= candle.end.year <= 2099:
            raise ValueError("Datetime year must be between 1970 and 2099")
        values = (candle.open, candle.high, candle.low, candle.close, candle.volume)
        if not all(math.isfinite(value) and abs(value) <= 1e30 for value in values):
            raise ValueError("Nonfinite or unrepresentable OHLCV")
        if (not 0 < candle.low <= min(candle.open, candle.close) <=
                max(candle.open, candle.close) <= candle.high or candle.volume < 0):
            raise ValueError("Invalid OHLCV")
    if any(a.end >= b.end for a, b in zip(candles, candles[1:])):
        raise ValueError("Candles must be strictly ordered")
    native = _native()
    freq = {"5m": native.Freq.F5, "30m": native.Freq.F30, "daily": native.Freq.D}[period]
    index = {c.end: i for i, c in enumerate(candles)}
    positive, negative = _macd_areas(candles)
    analysis = None
    records = []
    seen_bis = set()
    previous_center = None
    divergence_events, expansion_events = [], []
    for i, candle in enumerate(candles):
        raw = native.RawBar(symbol=f"{market}{code}", dt=candle.end, freq=freq,
                            open=candle.open, close=candle.close, high=candle.high,
                            low=candle.low, vol=candle.volume,
                            amount=candle.close*candle.volume, id=i)
        if analysis is None:
            analysis = native.CZSC([raw], min_bi_len=min_bi_len, max_bi_num=max_bi_num)
        else:
            analysis.update(raw)
        stamp = candle.end
        row = [(stamp.year-1900)*10000+stamp.month*100+stamp.day,
               0 if period == "daily" else stamp.hour*100+stamp.minute] + [0.0]*18
        lagged = analysis.bi_list[:-1]
        if lagged:
            latest = lagged[-1]
            up = latest.direction == native.Direction.Up
            high, low = float(latest.high), float(latest.low)
            row[_FIELD["swingHigh"]], row[_FIELD["swingLow"]] = high, low
            for name, ratio in zip(("fib382", "fib500", "fib618", "fib786"), _RATIOS):
                row[_FIELD[name]] = high-ratio*(high-low) if up else low+ratio*(high-low)
            identity = _event_key(latest)
            if identity not in seen_bis:
                seen_bis.add(identity)
                previous = next((bi for bi in reversed(lagged[:-1])
                                 if bi.direction == latest.direction), None)
                if previous is not None:
                    area = _area(latest, index, positive, negative, up)
                    prior_area = _area(previous, index, positive, negative, up)
                    new_extreme = high > float(previous.high) if up else low < float(previous.low)
                    if new_extreme and area < prior_area:
                        row[_FIELD["divTopFlag" if up else "divBottomFlag"]] = 1.0
                        divergence_events.append({"observed_at": stamp.isoformat(),
                                                  "direction": "up" if up else "down",
                                                  "bi_end": latest.fx_b.dt.isoformat(),
                                                  "area": area, "previous_area": prior_area})
        effective = next((center for center in reversed(analysis.zs_list)
                          if center.is_valid()), None)
        if effective is not None:
            current = (effective.sdt, effective.edt, float(effective.zg), float(effective.zd))
            if previous_center is not None and current != previous_center:
                _, _, high, low = current
                _, _, previous_high, previous_low = previous_center
                if (high >= previous_high and low <= previous_low and
                        high-low > previous_high-previous_low):
                    row[_FIELD["expandFlag"]] = 1.0
                    expansion_events.append({"observed_at": stamp.isoformat(),
                                             "high": high, "low": low,
                                             "previous_high": previous_high,
                                             "previous_low": previous_low})
            previous_center = current
        records.append(row)
    points = _endpoints(analysis.bi_list, index, native)
    red = _swing_points(points)
    for point_index, price, kind in red:
        records[point_index][_FIELD["redPrice"]] = price
        records[point_index][_FIELD["redKind"]] = kind
    blue = []
    if len(points) >= 2:
        highest = max(points, key=lambda p: p[1])
        lowest = min(points, key=lambda p: p[1])
        if highest[0] != lowest[0]:
            blue = [(highest[0], highest[1], 1.0), (lowest[0], lowest[1], -1.0)]
            for point_index, price, kind in blue:
                records[point_index][_FIELD["bluePrice"]] = price
                records[point_index][_FIELD["blueKind"]] = kind
    centers = [center for center in analysis.zs_list if center.is_valid()]
    box_segments = _draw_boxes(records, centers, candles)
    generated = int(wall_now.astimezone(UTC).timestamp())
    newest = int(candles[-1].end.replace(tzinfo=SHANGHAI).timestamp())
    payload = HEADER.pack(MAGIC, VERSION, PERIODS[period][0], key, len(records), generated, newest)
    payload += b"".join(RECORD.pack(*row) for row in records)
    metadata = {"engine": "czsc", "version": native.__version__, "visual_version": VERSION,
                "instrument": f"{market}{code}", "key": key, "period": period,
                "records": len(records), "native_bis": len(analysis.bi_list),
                "native_centers": len(centers), "red_endpoints": len(red),
                "blue_endpoints": len(blue), "box_segments": box_segments,
                "div_top_candidates": sum(bool(r[_FIELD["divTopFlag"]]) for r in records),
                "div_bottom_candidates": sum(bool(r[_FIELD["divBottomFlag"]]) for r in records),
                "interval_expansions": len(expansion_events),
                "divergence_events": divergence_events, "expansion_events": expansion_events,
                "generated_at_utc": generated, "newest_bar_end_utc": newest,
                "min_bi_len": min_bi_len, "max_bi_num": max_bi_num,
                "fields": list(FIELDS), "cache_sha256": hashlib.sha256(payload).hexdigest(),
                "filename": f"{key}_{PERIODS[period][0]}_visual.bin",
                "notice": "Independent visual aids around native CZSC BI/ZS. Red: three-same-kind-endpoint swing thinning, not native segments; blue: window endpoint extremes. Center boxes use native sdt/edt and zg/zd; one drawing track gives newer centers overlap priority, so covered objects are not displayed in full and visible fragments are re-anchored. Drawings may revise. Divergence candidates compare same-direction lagged BI signed MACD areas; interval expansion is containment with increased width, not a level upgrade. Events and Fibonacci snapshots do not backfill. No buy/sell signals or orders."}
    return payload, metadata
