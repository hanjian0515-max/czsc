"""Accounting and temporal-integrity tests; no external data or broker needed."""
from datetime import datetime, timezone
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

try:
    from .quant_ledger import Config, QuantLedger
except ImportError:
    from quant_ledger import Config, QuantLedger


def timestamp(day="2026-11-02", clock="01:35:00"):
    return int(datetime.fromisoformat(f"{day}T{clock}+00:00").timestamp())


def bar(end, close=100.0, low=None, high=None):
    return {"end": end, "open": close, "high": close if high is None else high,
            "low": close if low is None else low, "close": close, "volume": 1000}


def signal(end, action="buy", signal_id=None, stop=99.0):
    return {"id": signal_id or f"{action}:{end}", "at": end, "action": action, "stop": stop}


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "account.sqlite3"
        self.ledgers = []
        self.t = timestamp()

    def tearDown(self):
        for ledger in self.ledgers:
            try:
                ledger.close()
            except Exception:
                pass
        self.tmp.cleanup()

    def ledger(self, **kwargs):
        config = Config(**kwargs)
        ledger = QuantLedger(self.path, config)
        self.ledgers.append(ledger)
        return ledger

    def observe(self, ledger, symbol, end, close=100, sig=None, low=None, now=None):
        return ledger.process_bar(symbol, bar(end, close, low), sig, now=end if now is None else now)

    def open_position(self, ledger, symbol="sh600000", stop=99):
        self.observe(ledger, symbol, self.t)
        self.observe(ledger, symbol, self.t + 300, sig=signal(self.t + 300, stop=stop))
        result = self.observe(ledger, symbol, self.t + 600)
        self.assertEqual(len(result["executions"]), 1)
        return result["executions"][0]

    def test_first_fresh_bar_only_initializes(self):
        ledger = self.ledger()
        result = self.observe(ledger, "sh600000", self.t, sig=signal(self.t))
        self.assertEqual(result["status"], "warmup_no_trade")
        self.assertEqual(result["snapshot"]["cash"], 1_000_000)
        self.assertEqual(result["snapshot"]["pending"], {})
        self.assertEqual(result["snapshot"]["last_bars"], {"sh600000": self.t})
        self.assertEqual(result["events"][0]["kind"], "warmup_skipped")

    def test_entry_uses_next_close_slippage_fees_and_risk_limits(self):
        ledger = self.ledger()
        self.observe(ledger, "sh600000", self.t)
        pending = self.observe(ledger, "sh600000", self.t + 300, sig=signal(self.t + 300))
        self.assertEqual(pending["executions"], [])
        result = self.observe(ledger, "sh600000", self.t + 600, close=100.5)
        fill = result["executions"][0]
        self.assertAlmostEqual(fill["price"], 100.5 * 1.0005)
        self.assertEqual(fill["bar_end"], self.t + 600)
        self.assertEqual(fill["observed_at"], self.t + 600)
        self.assertEqual(fill["qty"] % 100, 0)
        self.assertLessEqual(fill["notional"], 100_000)
        self.assertLessEqual(fill["planned_risk"], 2500)
        self.assertAlmostEqual(result["snapshot"]["cash"], 1_000_000 - fill["notional"] - fill["fees"])
        self.assertTrue(fill["paper_only"])
        self.assertEqual(fill["pricing"], "delayed_bar_close")

    def test_restart_and_two_instances_preserve_deduplication(self):
        ledger = self.ledger()
        fill = self.open_position(ledger)
        snapshot = ledger.snapshot()
        second = self.ledger()
        self.assertEqual(second.snapshot(), snapshot)
        duplicate = self.observe(second, "sh600000", self.t + 600)
        self.assertEqual(duplicate["status"], "duplicate_bar")
        self.assertEqual(duplicate["executions"], [])
        self.observe(ledger, "sh600000", self.t + 900,
                     sig=signal(self.t + 900, signal_id=fill["signal_id"]))
        self.assertEqual(second.snapshot()["execution_count"], 1)
        self.assertEqual(second.snapshot()["pending"], {})

    def test_future_out_of_order_and_stale_bars_cannot_fill(self):
        ledger = self.ledger()
        self.observe(ledger, "sh600000", self.t)
        self.observe(ledger, "sh600000", self.t + 300, sig=signal(self.t + 300))
        future = self.observe(ledger, "sh600000", self.t + 600, now=self.t + 599)
        self.assertEqual(future["status"], "future_bar")
        self.assertEqual(future["snapshot"]["last_bars"]["sh600000"], self.t + 300)
        old = self.observe(ledger, "sh600000", self.t - 300)
        self.assertEqual(old["status"], "out_of_order_bar")
        stale = self.observe(ledger, "sh600000", self.t + 600,
                             sig=signal(self.t + 600), now=self.t + 691)
        self.assertEqual(stale["status"], "stale_bar")
        self.assertEqual(stale["snapshot"]["pending"], {})
        self.assertEqual(stale["executions"], [])
        self.observe(ledger, "sh600000", self.t + 900)
        self.assertEqual(ledger.snapshot()["execution_count"], 0)

    def test_late_and_incorrectly_stamped_signals_never_queue(self):
        ledger = self.ledger()
        self.observe(ledger, "sh600000", self.t)
        result = self.observe(ledger, "sh600000", self.t + 300, sig=signal(self.t))
        self.assertEqual(result["events"][0]["kind"], "rejected_signal_time")
        self.assertFalse(result["snapshot"]["pending"])

    def test_expired_entry_cannot_cross_long_gap(self):
        ledger = self.ledger(market="crypto")
        self.observe(ledger, "BTC-USD", self.t)
        self.observe(ledger, "BTC-USD", self.t + 300, sig=signal(self.t + 300))
        result = self.observe(ledger, "BTC-USD", self.t + 1200)
        self.assertEqual(result["events"][0]["kind"], "cancelled_expired")
        self.assertFalse(result["executions"])

    def test_ashare_entry_does_not_cross_lunch_or_overnight(self):
        ledger = self.ledger(pending_ttl=100_000)
        t = timestamp(clock="03:25:00")  # 11:25 China
        self.observe(ledger, "sh600000", t)
        self.observe(ledger, "sh600000", t + 300, sig=signal(t + 300))
        result = self.observe(ledger, "sh600000", timestamp(clock="05:05:00"))
        self.assertEqual(result["events"][0]["kind"], "cancelled_session_boundary")
        t2 = timestamp(clock="06:55:00")
        self.observe(ledger, "sh600000", t2, sig=signal(t2))
        next_day = self.observe(ledger, "sh600000", timestamp("2026-11-03"))
        self.assertEqual(next_day["events"][0]["kind"], "cancelled_session_boundary")
        self.assertEqual(ledger.snapshot()["execution_count"], 0)

    def test_ashare_t1_stop_is_deferred_and_not_filled_at_stop(self):
        ledger = self.ledger()
        self.open_position(ledger)
        touch = self.observe(ledger, "sh600000", self.t + 900, close=90, low=89)
        self.assertFalse(touch["executions"])
        self.assertIn("sh600000", touch["snapshot"]["deferred_exits"])
        self.assertIn("sh600000", touch["snapshot"]["positions"])
        next_day = self.observe(ledger, "sh600000", timestamp("2026-11-03"), close=80)
        fill = next_day["executions"][0]
        self.assertEqual(fill["side"], "sell")
        self.assertAlmostEqual(fill["price"], 80 * 0.9995)
        self.assertGreater(fill["tax"], 0)
        self.assertFalse(next_day["snapshot"]["positions"])
        self.assertFalse(next_day["snapshot"]["deferred_exits"])

    def test_t1_strategy_exit_is_recoverable_after_restart(self):
        ledger = self.ledger()
        self.open_position(ledger)
        self.observe(ledger, "sh600000", self.t + 900, sig=signal(self.t + 900, "sell"))
        deferred = self.observe(ledger, "sh600000", self.t + 1200)
        self.assertFalse(deferred["executions"])
        second = self.ledger()
        next_day = self.observe(second, "sh600000", timestamp("2026-11-03"), close=101)
        self.assertEqual(next_day["executions"][0]["reason"], "strategy_exit")
        self.assertEqual(second.snapshot()["execution_count"], 2)

    def test_stale_stop_touch_updates_mark_but_never_fills(self):
        ledger = self.ledger(market="crypto")
        self.open_position(ledger, "BTC-USD")
        stale = self.observe(ledger, "BTC-USD", self.t + 900, close=90, now=self.t + 1000)
        self.assertFalse(stale["executions"])
        self.assertEqual(stale["snapshot"]["positions"]["BTC-USD"]["mark"], 90)
        self.assertIn("BTC-USD", stale["snapshot"]["positions"])
        fresh = self.observe(ledger, "BTC-USD", self.t + 1200, close=91)
        self.assertEqual(fresh["executions"][0]["side"], "sell")
        self.assertAlmostEqual(fresh["executions"][0]["price"], 91 * 0.9995)

    def test_entry_bar_low_does_not_retroactively_stop_close_entry(self):
        ledger = self.ledger(market="crypto")
        self.observe(ledger, "BTC-USD", self.t)
        self.observe(ledger, "BTC-USD", self.t + 300, sig=signal(self.t + 300))
        result = self.observe(ledger, "BTC-USD", self.t + 600, low=50)
        self.assertEqual([e["side"] for e in result["executions"]], ["buy"])
        self.assertIn("BTC-USD", result["snapshot"]["positions"])

    def test_crypto_fractional_same_day_sell_and_no_additions(self):
        ledger = self.ledger(market="crypto")
        buy = self.open_position(ledger, "BTC-USD")
        self.assertNotEqual(buy["qty"] % 1, 0)
        additions = self.observe(ledger, "BTC-USD", self.t + 900, sig=signal(self.t + 900))
        self.assertEqual(additions["events"][0]["kind"], "rejected_no_additions")
        self.observe(ledger, "BTC-USD", self.t + 1200, sig=signal(self.t + 1200, "sell"))
        result = self.observe(ledger, "BTC-USD", self.t + 1500, close=101)
        self.assertEqual(result["executions"][0]["side"], "sell")
        self.assertFalse(result["snapshot"]["positions"])
        self.assertEqual(result["executions"][0]["tax"], 0)

    def test_daily_loss_latches_and_resets_next_day(self):
        ledger = self.ledger(market="crypto")
        self.open_position(ledger, "BTC-USD", stop=99)
        # A gap through the stop can lose more than the planned stop risk.
        self.observe(ledger, "BTC-USD", self.t + 900, close=1)
        self.assertTrue(ledger.snapshot()["daily_loss_locked"])
        self.observe(ledger, "ETH-USD", self.t + 900)
        locked = self.observe(ledger, "ETH-USD", self.t + 1200,
                              sig=signal(self.t + 1200))
        self.assertEqual(locked["events"][0]["kind"], "rejected_daily_loss")
        self.observe(ledger, "ETH-USD", self.t + 1500, close=200)
        self.assertTrue(ledger.snapshot()["daily_loss_locked"])
        next_day = self.observe(ledger, "ETH-USD", timestamp("2026-11-03"),
                                sig=signal(timestamp("2026-11-03")))
        self.assertFalse(next_day["snapshot"]["daily_loss_locked"])
        self.assertIn("ETH-USD", next_day["snapshot"]["pending"])

    def test_portfolio_planned_risk_and_cash_remain_bounded(self):
        ledger = self.ledger(market="crypto", capital=100_000, allocation_limit=0.8,
                             trade_risk_limit=0.004, portfolio_risk_limit=0.005)
        self.open_position(ledger, "BTC-USD")
        self.observe(ledger, "ETH-USD", self.t + 600)
        self.observe(ledger, "ETH-USD", self.t + 900, sig=signal(self.t + 900))
        result = self.observe(ledger, "ETH-USD", self.t + 1200)
        snap = result["snapshot"]
        self.assertGreaterEqual(snap["cash"], 0)
        self.assertLessEqual(snap["planned_risk"], snap["equity"] * 0.005 + 1e-8)
        self.assertTrue(all(p["qty"] > 0 for p in snap["positions"].values()))

    def test_too_small_account_cannot_buy_one_ashare_lot(self):
        ledger = self.ledger(capital=1000)
        self.observe(ledger, "sh600000", self.t)
        self.observe(ledger, "sh600000", self.t + 300, sig=signal(self.t + 300))
        result = self.observe(ledger, "sh600000", self.t + 600)
        self.assertEqual(result["events"][0]["kind"], "rejected_size_or_risk")
        self.assertFalse(result["snapshot"]["positions"])
        self.assertEqual(result["snapshot"]["cash"], 1000)

    def test_invalid_symbols_currencies_and_configuration_rejected(self):
        ledger = self.ledger()
        for symbol in ("sh000001", "sz399001", "399001", "600000", "BTC-USD", "sh900901"):
            with self.subTest(symbol=symbol), self.assertRaises(ValueError):
                self.observe(ledger, symbol, self.t)
        with self.assertRaises(ValueError):
            Config(market="crypto", currency="USDT")
        with self.assertRaises(ValueError):
            Config(capital=math.nan)
        with self.assertRaises(ValueError):
            Config(quantity_step=1)
        with self.assertRaises(ValueError):
            QuantLedger(self.path, Config(market="crypto"))
        with self.assertRaises(ValueError):
            QuantLedger(self.path, Config(mode="replay"))
        with self.assertRaises(ValueError):
            QuantLedger(self.path, Config(capital=2_000_000))

    def test_invalid_values_leave_state_and_orders_unchanged(self):
        ledger = self.ledger()
        self.observe(ledger, "sh600000", self.t)
        baseline = ledger.snapshot()
        malformed = [bar(self.t + 300, close=math.nan), bar(self.t + 300, low=101),
                     {**bar(self.t + 300), "volume": -1}, {**bar(self.t + 300), "end": True}]
        for value in malformed:
            with self.assertRaises(ValueError):
                ledger.process_bar("sh600000", value, now=self.t + 300)
        with self.assertRaises(ValueError):
            self.observe(ledger, "sh600000", self.t + 300,
                         sig=signal(self.t + 300, stop=math.inf))
        self.assertEqual(ledger.snapshot(), baseline)

    def test_failure_rolls_back_cash_signal_watermark_and_execution(self):
        ledger = self.ledger()
        self.observe(ledger, "sh600000", self.t)
        self.observe(ledger, "sh600000", self.t + 300, sig=signal(self.t + 300))
        baseline = ledger.snapshot()
        with patch.object(ledger, "_execution", side_effect=RuntimeError("disk failure")):
            with self.assertRaises(RuntimeError):
                self.observe(ledger, "sh600000", self.t + 600)
        self.assertEqual(ledger.snapshot(), baseline)
        retried = self.observe(ledger, "sh600000", self.t + 600)
        self.assertEqual(len(retried["executions"]), 1)
        self.assertEqual(ledger.snapshot()["execution_count"], 1)

    def test_replay_is_explicit_and_uses_simulated_time(self):
        ledger = self.ledger(market="crypto", mode="replay")
        with self.assertRaises(ValueError):
            ledger.process_bar("BTC-USD", bar(self.t))
        fill = self.open_position(ledger, "BTC-USD")
        self.assertEqual(fill["mode"], "replay")
        self.assertEqual(fill["observed_at"], self.t + 600)

    def test_weekends_and_outside_stock_session_do_not_trade(self):
        ledger = self.ledger()
        t = timestamp("2026-11-07")  # Saturday
        self.observe(ledger, "sh600000", t)
        result = self.observe(ledger, "sh600000", t + 300, sig=signal(t + 300))
        self.assertEqual(result["status"], "outside_session")
        self.assertFalse(result["snapshot"]["pending"])

    def test_star_board_requires_at_least_200_shares(self):
        ledger = self.ledger(capital=150_000)
        self.observe(ledger, "sh688001", self.t)
        self.observe(ledger, "sh688001", self.t + 300, sig=signal(self.t + 300))
        result = self.observe(ledger, "sh688001", self.t + 600)
        self.assertFalse(result["executions"])  # 10% cap permits only a 100-share lot.
        self.assertFalse(result["snapshot"]["positions"])

    def test_no_volume_cancels_entry_and_does_not_execute_stop(self):
        ledger = self.ledger(market="crypto")
        self.observe(ledger, "BTC-USD", self.t)
        self.observe(ledger, "BTC-USD", self.t + 300, sig=signal(self.t + 300))
        no_volume = {**bar(self.t + 600), "volume": 0}
        result = ledger.process_bar("BTC-USD", no_volume, signal(self.t + 600), now=self.t + 600)
        self.assertEqual(result["status"], "no_volume")
        self.assertFalse(result["executions"])
        self.assertFalse(result["snapshot"]["pending"])
        self.observe(ledger, "BTC-USD", self.t + 900, sig=signal(self.t + 900))
        self.observe(ledger, "BTC-USD", self.t + 1200)
        no_volume = {**bar(self.t + 1500, close=90), "volume": 0}
        result = ledger.process_bar("BTC-USD", no_volume, now=self.t + 1500)
        self.assertFalse(result["executions"])
        self.assertIn("BTC-USD", result["snapshot"]["positions"])

    def test_cross_symbol_previous_day_does_not_roll_account_day_back(self):
        ledger = self.ledger(market="crypto")
        t = timestamp(clock="23:59:00")
        self.observe(ledger, "BTC-USD", t)
        self.observe(ledger, "ETH-USD", t)
        midnight = t + 60
        self.observe(ledger, "BTC-USD", midnight)
        old_day = ledger.process_bar("ETH-USD", bar(t + 30), signal(t + 30), now=midnight)
        self.assertEqual(old_day["status"], "older_account_day")
        self.assertEqual(old_day["snapshot"]["day"], "2026-11-03")
        self.assertFalse(old_day["snapshot"]["pending"])


if __name__ == "__main__":
    unittest.main()
