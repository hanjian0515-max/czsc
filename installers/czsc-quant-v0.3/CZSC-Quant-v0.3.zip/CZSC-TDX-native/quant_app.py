"""Tk control panel for the local CZSC paper ledger and historical replay."""
from datetime import datetime
import json
import os
from pathlib import Path
import queue
import re
import subprocess
import sys
import threading
import time

from quant_runner import bool_value, validate_config

ROOT = Path(__file__).resolve().parent
CONFIG_KEYS = ("source", "asset_market", "market", "code", "mode", "capital", "ledger", "online")
DISPLAY_CHOICES = {"asset_market": {"ashare": "沪深A股", "crypto": "BTC-USD"},
                   "mode": {"paper": "自动模拟", "replay": "历史回测"}}


def default_ledger(root, asset_market, mode, now=None, symbol=None):
    symbol = symbol or ("BTC-USD" if asset_market == "crypto" else "select-stock")
    symbol = re.sub(r"[^A-Za-z0-9-]", "", str(symbol)) or "select-stock"
    name = "quant-{}-{}-{}".format(mode, asset_market, symbol)
    if mode == "replay":
        name += "-" + (now or datetime.now()).strftime("%Y%m%d-%H%M%S-%f")
    return Path(root) / "runtime" / "accounts" / (name + ".sqlite")


def infer_source(path):
    """Never substitute a tradable stock for an index selected by the user."""
    identity = re.fullmatch(r"(sh|sz)([0-9]{6})\.lc5", Path(path).name.lower())
    if identity:
        return {"asset_market": "ashare", "market": identity.group(1), "code": identity.group(2)}
    return {}


def activity_error(runner_active, fetch_active):
    if runner_active:
        return "已有模拟任务；请先停止后再更改配置或下载行情。"
    if fetch_active:
        return "历史行情正在下载；请等待完成或先停止，再启动模拟。"
    return None


def build_command(config, root=ROOT, python=sys.executable):
    config = validate_config(config)
    command = [str(python), str(Path(root) / "quant_runner.py")]
    for key in ("source", "asset_market", "market", "code", "mode", "capital", "ledger", "interval"):
        command.extend(["--" + key.replace("_", "-"), str(config[key])])
    if config["mode"] == "paper":
        command.append("--watch")
        if config.get("online"):
            command.append("--online")
    elif config.get("report"):
        command.extend(["--report", config["report"]])
    return command


def save_settings(config, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = {key: config[key] for key in CONFIG_KEYS if key in config}
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def status_message(metadata, running, now=None):
    if metadata.get("errors"):
        return "模拟暂停：" + "；".join(str(error) for error in metadata["errors"])
    if metadata.get("mode") == "replay":
        if metadata.get("status") == "replay_complete":
            return "历史回放完成；期末持仓保留在独立账本中。"
        if not running:
            return "历史回放已停止；未完成的结果保留在其独立账本。"
        return "正在历史回放：{}/{}根K线".format(metadata.get("processed", 0), metadata.get("total", "—"))
    if not running:
        return "自动模拟已停止；账本已保存。"
    source = metadata.get("source_at_utc")
    if source is not None:
        age = (time.time() if now is None else now) - float(source)
        if age < 0 or age > 90:
            return "行情超过90秒或时间异常，自动模拟暂停；等待文件持续更新。"
    return metadata.get("message", "等待已有本地文件的最新收盘；尚未确认行情更新。")


class QuantControl:
    """Own a child runner process; no Tk calls happen on reader threads."""
    def __init__(self, window, root=ROOT):
        import tkinter as tk
        from tkinter import ttk
        self.window, self.root, self.tk, self.ttk = window, Path(root), tk, ttk
        self.config_path = self.root / "runtime" / "quant-config.json"
        self.process, self.fetch_process = None, None
        self.events, self.metadata = queue.Queue(), {}
        self.closing, self.stop_requested = False, False
        self.inputs = []
        self.running_config = None
        self.last_metadata = None
        defaults = {"source": "", "asset_market": "ashare", "market": "sz", "code": "",
                    "mode": "paper", "capital": "1000000", "ledger": "", "online": "1"}
        load_error = None
        try:
            if self.config_path.exists():
                loaded = json.loads(self.config_path.read_text(encoding="utf-8"))
                if not isinstance(loaded, dict):
                    raise ValueError("配置内容必须为对象。")
                defaults.update({key: str(loaded[key]) for key in CONFIG_KEYS if key in loaded})
        except (OSError, TypeError, ValueError) as error:
            load_error = str(error)
        try:
            defaults["online"] = "1" if bool_value(defaults["online"]) else "0"
        except ValueError:
            defaults["online"] = "0"
        self.values = {key: tk.StringVar(value=value) for key, value in defaults.items()}
        self.display_values = {key: tk.StringVar(value=choices.get(defaults[key], next(iter(choices.values())))) for key, choices in DISPLAY_CHOICES.items()}
        initial_symbol = "BTC-USD" if defaults["asset_market"] == "crypto" else defaults["market"] + defaults["code"] if defaults["code"] else "select-stock"
        self._suggested_ledger = str(default_ledger(self.root, defaults["asset_market"], defaults["mode"], symbol=initial_symbol))
        if not defaults["ledger"]:
            self.values["ledger"].set(self._suggested_ledger)
        self.state = tk.StringVar(value="未启动；只模拟，不连接券商或交易所账户。")
        self.account = tk.StringVar(value="账户：尚未读取账本")
        self.latest = tk.StringVar(value="数据源：尚未选择 / 更新状态未确认")
        self.market_note = tk.StringVar()
        self._set_market_note()
        window.title("CZSC 自动模拟交易 / 历史回放")
        window.geometry("1060x800")
        window.minsize(880, 700)
        window.protocol("WM_DELETE_WINDOW", self.close)
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text="CZSC 自动模拟交易与历史回放", font=("Microsoft YaHei UI", 14, "bold")).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(frame, text="仅模拟：策略委托延后一根有效收盘；保护退出按观测柱收盘（A股T+1可延期）。无真实账户下单。", wraplength=1000).grid(row=1, column=0, columnspan=3, sticky="w", pady=(4, 10))
        settings = ttk.Frame(frame)
        settings.grid(row=2, column=0, columnspan=3, sticky="w")
        for label, key, choices, width in (("资产", "asset_market", tuple(DISPLAY_CHOICES["asset_market"].values()), 9), ("模式", "mode", tuple(DISPLAY_CHOICES["mode"].values()), 8), ("沪深市场", "market", ("sh", "sz"), 5), ("证券代码", "code", None, 12)):
            ttk.Label(settings, text=label).pack(side="left", padx=(0, 4))
            variable = self.display_values.get(key, self.values[key])
            widget = ttk.Combobox(settings, textvariable=variable, values=choices, state="readonly", width=width) if choices else ttk.Entry(settings, textvariable=variable, width=width)
            widget.pack(side="left", padx=(0, 13))
            self.inputs.append(widget)
            if key in ("asset_market", "mode"):
                widget.bind("<<ComboboxSelected>>", lambda event, k=key: self._choice_changed(k))
        checkbox = ttk.Checkbutton(settings, text="BTC自动更新公开行情", variable=self.values["online"], onvalue="1", offvalue="0")
        checkbox.pack(side="left", padx=(0, 5))
        self.inputs.append(checkbox)
        ttk.Label(frame, textvariable=self.market_note, wraplength=1000).grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 8))
        self._file_row(frame, 4, "5分钟行情文件", "source", self.select_source)
        self._file_row(frame, 5, "SQLite模拟账本", "ledger", self.select_ledger)
        funds = ttk.Frame(frame)
        funds.grid(row=6, column=0, columnspan=3, sticky="w", pady=6)
        ttk.Label(funds, text="初始资金").pack(side="left", padx=(0, 6))
        capital = ttk.Entry(funds, textvariable=self.values["capital"], width=18)
        capital.pack(side="left", padx=(0, 12))
        self.inputs.append(capital)
        ttk.Label(funds, text="A股以CNY计价；BTC-USD以USD计价。已有账本必须使用原市场、模式及初始资金。").pack(side="left")
        actions = ttk.Frame(frame)
        actions.grid(row=7, column=0, columnspan=3, sticky="w", pady=(2, 8))
        for label, callback in (("启动模拟 / 回放", self.start), ("停止", self.stop), ("新建账本", self.new_ledger), ("下载BTC历史行情（7天）", self.fetch_crypto), ("打开结果目录", self.open_results)):
            button = ttk.Button(actions, text=label, command=callback)
            button.pack(side="left", padx=(0, 7))
            if label in ("新建账本", "下载BTC历史行情（7天）"):
                self.inputs.append(button)
        ttk.Label(frame, text="一次监视一个证券，每个账本绑定该证券。A股须选择通达信fzline下.lc5及同市场lday日线。BTC支持本地CSV/JSON，或先下载公开历史JSON再自动更新；失败暂停。", wraplength=1000).grid(row=8, column=0, columnspan=3, sticky="w", pady=(0, 8))
        status = ttk.LabelFrame(frame, text="模拟账户状态", padding=8)
        status.grid(row=9, column=0, columnspan=3, sticky="ew")
        for variable in (self.state, self.account, self.latest):
            ttk.Label(status, textvariable=variable, wraplength=990, justify="left").pack(anchor="w", pady=2)
        tables = ttk.Panedwindow(frame, orient="vertical")
        tables.grid(row=10, column=0, columnspan=3, sticky="nsew", pady=8)
        frame.rowconfigure(10, weight=1)
        positions = ttk.LabelFrame(tables, text="持仓（模拟）", padding=4)
        self.positions = self._tree(positions, ("symbol", "qty", "entry", "mark", "stop"), ("证券", "数量", "成本", "估值价格", "止损参考"), height=3)
        tables.add(positions, weight=1)
        trades = ttk.LabelFrame(tables, text="最近成交（模拟；策略委托延后一根收盘，保护退出按观测柱收盘）", padding=4)
        self.trades = self._tree(trades, ("at", "symbol", "action", "qty", "price", "fee"), ("时间", "证券", "方向", "数量", "价格", "费用"), height=5)
        tables.add(trades, weight=2)
        logs = ttk.LabelFrame(frame, text="日志", padding=4)
        logs.grid(row=11, column=0, columnspan=3, sticky="ew")
        self.log = tk.Text(logs, height=7, wrap="word", state="disabled")
        self.log.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(logs, command=self.log.yview)
        scroll.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=scroll.set)
        if load_error:
            self.append_log("配置读取失败，请重新设置：" + load_error)
        window.after(200, self.tick)

    def _file_row(self, frame, row, label, key, command):
        self.ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8))
        entry = self.ttk.Entry(frame, textvariable=self.values[key])
        entry.grid(row=row, column=1, sticky="ew", pady=3)
        button = self.ttk.Button(frame, text="选择…", command=command)
        button.grid(row=row, column=2, padx=(8, 0))
        self.inputs.extend((entry, button))

    def _tree(self, parent, columns, labels, height):
        tree = self.ttk.Treeview(parent, columns=columns, show="headings", height=height)
        for name, label in zip(columns, labels):
            tree.heading(name, text=label)
            tree.column(name, width=130, minwidth=70)
        tree.pack(fill="both", expand=True)
        return tree

    def current_config(self):
        return {key: value.get() for key, value in self.values.items()}

    def _set_market_note(self):
        asset, mode = self.values["asset_market"].get(), self.values["mode"].get()
        for key, choices in DISPLAY_CHOICES.items():
            self.display_values[key].set(choices.get(self.values[key].get(), "—"))
        self.market_note.set(("A股股票 / CNY，100股步长（科创板最少200股），T+1。" if asset == "ashare" else "BTC-USD现货 / USD，只做多，不使用杠杆。") + (" 自动模拟读取新收盘；BTC可选公开行情更新，失败暂停。" if mode == "paper" else " 历史回测只运行一次，独立账本，保留期末持仓。"))

    def _choice_changed(self, key):
        reverse = {label: value for value, label in DISPLAY_CHOICES[key].items()}
        self.values[key].set(reverse[self.display_values[key].get()])
        self.change_mode()

    def change_mode(self, event=None):
        if self.values["asset_market"].get() == "crypto":
            self.values["code"].set("BTC-USD")
        elif self.values["code"].get() == "BTC-USD":
            self.values["code"].set("")
        if self.values["ledger"].get() == self._suggested_ledger:
            self.new_ledger()
        self._set_market_note()

    def new_ledger(self):
        symbol = "BTC-USD" if self.values["asset_market"].get() == "crypto" else self.values["market"].get() + self.values["code"].get() if self.values["code"].get() else "select-stock"
        path = default_ledger(self.root, self.values["asset_market"].get(), self.values["mode"].get(), symbol=symbol)
        if self.values["mode"].get() == "paper" and path.exists():
            path = path.with_stem(path.stem + "-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
        self._suggested_ledger = str(path)
        self.values["ledger"].set(str(path))

    def select_source(self):
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self.window, title="选择已有5分钟行情文件", filetypes=[("行情文件", "*.lc5 *.json *.csv"), ("所有文件", "*.*")])
        if path:
            self.values["source"].set(path)
            for key, value in infer_source(path).items():
                self.values[key].set(value)
            self.change_mode()

    def select_ledger(self):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(parent=self.window, title="选择已有账本以恢复，或输入新文件名", defaultextension=".sqlite", filetypes=[("SQLite模拟账本", "*.sqlite *.db")], confirmoverwrite=False)
        if path:
            self.values["ledger"].set(path)

    def append_log(self, message):
        self.log.configure(state="normal")
        self.log.insert("end", datetime.now().strftime("%H:%M:%S ") + str(message).rstrip() + "\n")
        if int(self.log.index("end-1c").split(".")[0]) > 400:
            self.log.delete("1.0", "101.0")
        self.log.see("end")
        self.log.configure(state="disabled")

    def show_error(self, error):
        from tkinter import messagebox
        self.state.set("操作失败：" + str(error))
        self.append_log(error)
        messagebox.showerror("CZSC模拟操作失败", str(error), parent=self.window)

    def _spawn(self, command):
        flags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        environment = os.environ.copy()
        environment["PYTHONUTF8"] = "1"
        return subprocess.Popen(command, cwd=self.root, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace", bufsize=1,
                                shell=False, env=environment, creationflags=flags)

    def _set_busy(self, busy):
        for widget in self.inputs:
            widget.state(["disabled"] if busy else ["!disabled"])

    def start(self):
        conflict = activity_error(self.process is not None, self.fetch_process is not None)
        if conflict:
            self.append_log(conflict)
            return
        try:
            config = validate_config(self.current_config())
            if config["mode"] == "replay":
                if Path(config["ledger"]).exists() and Path(config["ledger"]).stat().st_size:
                    raise ValueError("历史回放须用新账本。请点击“新建账本”再启动。")
                config["report"] = str(self.root / "runtime" / "results" / (Path(config["ledger"]).stem + ".json"))
            command = build_command(config, self.root)
            save_settings(config, self.config_path)
            self.metadata = {}
            self.last_metadata = None
            self.stop_requested = False
            self.process = self._spawn(command)
            self.running_config = dict(config)
            self._set_busy(True)
            self.latest.set("本次任务：{} / {} / {}    正在读取指定行情和账本".format(config["symbol"], "自动模拟" if config["mode"] == "paper" else "历史回测", config["currency"]))
            self.state.set("正在初始化独立模拟账本；首次不补发历史交易信号。")
            self.append_log("启动{}：{} / {}，账本：{}".format("自动模拟" if config["mode"] == "paper" else "历史回放", config["symbol"], config["currency"], config["ledger"]))
            threading.Thread(target=self._read, args=(self.process, "runner", None), daemon=True).start()
        except (OSError, ValueError) as error:
            self.show_error(error)

    def fetch_crypto(self):
        conflict = activity_error(self.process is not None, self.fetch_process is not None)
        if conflict:
            self.append_log(conflict)
            return
        try:
            output = self.root / "runtime" / "quotes" / ("BTC-USD-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f") + ".json")
            command = [sys.executable, str(self.root / "quant_crypto.py"), "--fetch", "--product", "BTC-USD", "--days", "7", "--output", str(output)]
            self.stop_requested = False
            self.metadata = {}
            self.fetch_process = self._spawn(command)
            self._set_busy(True)
            self.state.set("正在下载公开历史行情；尚未确认网络可用性，未启动模拟。")
            self.append_log("正在只读下载Coinbase公开BTC-USD历史行情；网络可用性尚未确认。")
            threading.Thread(target=self._read, args=(self.fetch_process, "fetch", output), daemon=True).start()
        except OSError as error:
            self.show_error(error)

    def _read(self, process, purpose, output):
        try:
            for line in process.stdout:
                self.events.put((process, purpose, "line", line, output))
        except (OSError, ValueError) as error:
            self.events.put((process, purpose, "line", str(error), output))
        finally:
            process.stdout.close()
            self.events.put((process, purpose, "exit", process.wait(), output))

    def stop(self):
        self.stop_requested = True
        for process in (self.process, self.fetch_process):
            if process is not None and process.poll() is None:
                try:
                    process.terminate()
                    self.window.after(2000, lambda p=process: self._kill(p))
                except OSError as error:
                    self.append_log("停止失败：" + str(error))
        self.state.set("正在停止；已记录的模拟持仓保留在账本。")

    def _kill(self, process):
        try:
            if process.poll() is None:
                process.kill()
        except OSError:
            pass

    def _show_ledger(self, data):
        currency = data.get("currency", "—")
        self.account.set("模拟账户 {}    现金：{}    净值：{}    初始资金：{}    已成交：{}笔    日亏损锁定：{}".format(currency, self._num(data.get("cash")), self._num(data.get("equity")), self._num(data.get("capital")), data.get("execution_count", 0), "是" if data.get("daily_loss_locked") else "否"))
        for tree in (self.positions, self.trades):
            children = tree.get_children()
            if children:
                tree.delete(*children)
        for symbol, position in data.get("positions", {}).items():
            self.positions.insert("", "end", values=(symbol, self._num(position.get("qty")), self._num(position.get("entry")), self._num(position.get("mark")), self._num(position.get("stop"))))
        for execution in data.get("executions", [])[-40:]:
            stamp = execution.get("bar_end", execution.get("at", execution.get("end", execution.get("time", "—"))))
            if isinstance(stamp, (int, float)):
                stamp = datetime.fromtimestamp(stamp).strftime("%m-%d %H:%M:%S")
            action = {"buy": "模拟买入", "sell": "模拟卖出"}.get(execution.get("action"), execution.get("action", "—"))
            fees = execution.get("fee", execution.get("fees", 0)) + execution.get("tax", 0)
            self.trades.insert("", "end", values=(stamp, execution.get("symbol", "—"), action,
                                                 self._num(execution.get("qty")), self._num(execution.get("price")), self._num(fees)))

    @staticmethod
    def _num(value):
        return "—" if value is None else (f"{value:,.4f}".rstrip("0").rstrip(".") if isinstance(value, (int, float)) else str(value))

    def tick(self):
        if self.closing:
            return
        while True:
            try:
                process, purpose, kind, value, output = self.events.get_nowait()
            except queue.Empty:
                break
            if purpose == "fetch":
                if process is not self.fetch_process:
                    continue
                if kind == "line":
                    self.append_log(value)
                else:
                    self.fetch_process = None
                    self._set_busy(False)
                    if value == 0 and output.is_file() and not self.stop_requested:
                        self.values["source"].set(str(output))
                        self.values["asset_market"].set("crypto")
                        self.values["mode"].set("replay")
                        self.values["code"].set("BTC-USD")
                        self.new_ledger()
                        self._set_market_note()
                        self.append_log("历史行情已保存；可点击启动历史回放：" + str(output))
                        self.state.set("BTC历史文件已选择；尚未启动回放，未连接实时行情。")
                    else:
                        self.append_log("行情下载已停止或失败，退出码：" + str(value))
                        self.state.set("历史行情下载已停止或失败；未启动模拟，请查看日志。")
                continue
            if process is not self.process:
                continue
            if kind == "exit":
                self.process = None
                self._set_busy(False)
                self.append_log("模拟进程退出，退出码：" + str(value))
                if value and not self.stop_requested:
                    self.metadata["errors"] = self.metadata.get("errors") or ["模拟进程失败，退出码：" + str(value)]
                    self.state.set("模拟进程失败，请查看日志；无真实下单。")
                continue
            try:
                metadata = json.loads(value)
            except (TypeError, ValueError):
                self.append_log(value)
                continue
            if not isinstance(metadata, dict):
                self.append_log(value)
                continue
            self.metadata = metadata
            if metadata.get("ledger"):
                self._show_ledger(metadata["ledger"])
            if metadata.get("source_at"):
                self.latest.set("本次证券：{}    源K线收盘：{}    距处理时：{}秒    收盘价模拟，非盘口成交".format(metadata.get("symbol", "—"), metadata["source_at"], metadata.get("source_age", "—")))
            signature = (metadata.get("status"), metadata.get("source_at"), str(metadata.get("errors")), str(metadata.get("executions")))
            if signature != self.last_metadata:
                self.append_log(metadata.get("message", metadata.get("status", value)))
                if metadata.get("report"):
                    self.append_log("回放报告：" + metadata["report"])
                self.last_metadata = signature
        if self.metadata:
            self.state.set(status_message(self.metadata, self.process is not None))
        self.window.after(300, self.tick)

    def open_results(self):
        path = self.root / "runtime" / "results"
        try:
            path.mkdir(parents=True, exist_ok=True)
            if sys.platform != "win32":
                self.append_log("结果目录：" + str(path))
            else:
                os.startfile(str(path))
        except OSError as error:
            self.show_error(error)

    def close(self):
        self.closing = True
        for process in (self.process, self.fetch_process):
            if process is not None and process.poll() is None:
                try:
                    process.terminate()
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self._kill(process)
                except OSError:
                    pass
        try:
            save_settings(self.current_config(), self.config_path)
        except OSError:
            pass
        self.window.destroy()


def main():
    import tkinter as tk
    window = tk.Tk()
    QuantControl(window)
    window.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
