"""Read-only USD spot crypto candles for CZSC replay / paper simulation.

This module has no exchange order routes or account credentials. CSV Datetime
values are candle CLOSE times: aware values retain their timezone; naive values
are explicitly Shanghai local time. Native CZSC receives naive Shanghai time,
including 08:00 for a completed UTC daily candle. Missing bars are never filled.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timedelta, timezone
import io
import json
import math
import os
from pathlib import Path
import re
import tempfile
import time
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from export_czsc import Candle, SHANGHAI

UTC = timezone.utc
SOURCE = "coinbase_exchange_public"
SCHEMA = 1
TIMEFRAMES = (300, 1800, 86400)
MAX_ROWS = 200_000


def normalize_product(symbol):
    value = str(symbol).strip().upper().replace("/", "-")
    if "-" not in value and value.endswith("USD"):
        value = value[:-3] + "-USD"
    if not re.fullmatch(r"[A-Z0-9]{2,12}-USD", value):
        raise ValueError("Only explicit USD-quoted spot symbols such as BTC-USD are supported; USDT is not USD")
    return value


def _number(value, label):
    if isinstance(value, bool):
        raise ValueError(f"{label} cannot be boolean")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise ValueError(f"Invalid {label}") from error
    if not math.isfinite(result) or abs(result) > 1e30:
        raise ValueError(f"Nonfinite or unrepresentable {label}")
    return result


def _integer(value, label):
    number = _number(value, label)
    if int(number) != number:
        raise ValueError(f"{label} must be an integer")
    return int(number)


def _now_epoch(now=None):
    if now is None:
        return int(time.time())
    if isinstance(now, datetime):
        if now.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        return int(now.timestamp())
    return _integer(now, "now")


def _stamp_epoch(value):
    try:
        stamp = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError) as error:
        raise ValueError("Datetime must be an ISO candle closing timestamp") from error
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=SHANGHAI)
    epoch = stamp.timestamp()
    if int(epoch) != epoch:
        raise ValueError("Candle time must not have sub-second precision")
    return int(epoch)


def _validate_row(row, seconds):
    if not isinstance(row, dict):
        raise ValueError("Each candle must be an object")
    if "end" in row:
        end = _integer(row["end"], "end")
        if "start" in row and end != _integer(row["start"], "start") + seconds:
            raise ValueError("Candle start/end disagree")
    elif "start" in row:
        end = _integer(row["start"], "start") + seconds
    else:
        raise ValueError("Candle lacks an end timestamp")
    if "seconds" in row and _integer(row["seconds"], "seconds") != seconds:
        raise ValueError("Candle timeframe disagrees with its series")
    try:
        date = datetime.fromtimestamp(end, UTC)
    except (ValueError, OSError, OverflowError) as error:
        raise ValueError("Candle time out of range") from error
    if not 1970 <= date.year <= 2099 or end % seconds:
        raise ValueError("Candle close is unaligned or outside supported years")
    values = {name: _number(row[name], name) for name in ("open", "high", "low", "close", "volume")}
    if not (0 < values["low"] <= min(values["open"], values["close"]) <=
            max(values["open"], values["close"]) <= values["high"]) or values["volume"] < 0:
        raise ValueError("Invalid candle OHLCV")
    return {"end": end, **values}


def _series(rows, seconds, now, *, require_nonempty=False):
    if not isinstance(rows, list) or len(rows) > MAX_ROWS:
        raise ValueError("Invalid or oversized candle series")
    normalized = [_validate_row(row, seconds) for row in rows]
    if any(a["end"] >= b["end"] for a, b in zip(normalized, normalized[1:])):
        raise ValueError("Duplicate or unordered candle times")
    # Future/open rows are validated first, then excluded, never fabricated.
    closed = [row for row in normalized if row["end"] <= now]
    if require_nonempty and not closed:
        raise ValueError("No closed five-minute candles available")
    return closed


def _aggregate(five, seconds):
    groups = {}
    for row in five:
        # A close exactly at UTC midnight belongs to the preceding UTC day.
        bucket = ((row["end"]-1)//seconds + 1)*seconds
        groups.setdefault(bucket, []).append(row)
    result = []
    count = seconds//300
    for end, members in sorted(groups.items()):
        if [r["end"] for r in members] != list(range(end-seconds+300, end+1, 300)):
            continue
        if len(members) != count:
            continue
        result.append({"end": end, "open": members[0]["open"],
                       "high": max(r["high"] for r in members),
                       "low": min(r["low"] for r in members),
                       "close": members[-1]["close"],
                       "volume": sum(r["volume"] for r in members)})
    return result


def _candles(rows):
    return [Candle(datetime.fromtimestamp(r["end"], SHANGHAI).replace(tzinfo=None),
                   r["open"], r["high"], r["low"], r["close"], r["volume"]) for r in rows]


def _read_snapshot(path):
    before = path.stat()
    content = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("Source changed while reading; retry after its writer finishes")
    if len(content) > 120_000_000:
        raise ValueError("Source file is too large")
    try:
        return content.decode("utf-8-sig")
    except UnicodeDecodeError:
        return content.decode("gb18030")


def _load_csv(text, now):
    reader = csv.DictReader(io.StringIO(text))
    names = {str(k).strip().lower(): k for k in reader.fieldnames or []}
    if any(name not in names for name in ("datetime", "open", "high", "low", "close", "volume")):
        raise ValueError("CSV requires Datetime,Open,High,Low,Close,Volume")
    rows = []
    for line, row in enumerate(reader, 2):
        if line > MAX_ROWS+1:
            raise ValueError("CSV exceeds the candle limit")
        try:
            rows.append({"end": _stamp_epoch(row[names["datetime"]]),
                         **{name: row[names[name]] for name in ("open", "high", "low", "close", "volume")}})
        except (ValueError, TypeError, KeyError) as error:
            raise ValueError(f"CSV line {line}: {error}") from error
    five = _series(rows, 300, now, require_nonempty=True)
    return five, _aggregate(five, 1800), _aggregate(five, 86400)


def _load_json(text, symbol, now):
    dataset = json.loads(text)
    if not isinstance(dataset, dict) or dataset.get("schema") != SCHEMA:
        raise ValueError("Unsupported crypto dataset schema")
    if dataset.get("asset_market", "crypto") != "crypto":
        raise ValueError("Dataset is not a crypto dataset")
    if normalize_product(dataset.get("product", "")) != symbol:
        raise ValueError("Dataset product does not match the requested symbol")
    if dataset.get("source") not in (SOURCE, "user_imported_crypto", "synthetic_test_fixture"):
        raise ValueError("Unknown dataset source label")
    instrument = dataset.get("instrument")
    if instrument is not None:
        if not isinstance(instrument, dict) or instrument.get("multiplier") != 1 or instrument.get("quote_to_usd") != 1 or instrument.get("short_allowed") is not False:
            raise ValueError("Only unleveraged USD spot instrument metadata is accepted")
        for name in ("tick", "step"):
            if _number(instrument.get(name), name) <= 0:
                raise ValueError("Instrument increments must be positive")
    fetched = _integer(dataset.get("fetched_at"), "fetched_at")
    rows = dataset.get("series")
    if not isinstance(rows, dict) or "300" not in rows:
        raise ValueError("Dataset lacks five-minute candles")
    # A snapshot cannot contain a candle not yet closed when it was captured.
    for key in rows:
        if key not in ("300", "1800", "86400"):
            raise ValueError("Unsupported crypto candle timeframe")
    parsed = {}
    for key, values in rows.items():
        parsed[int(key)] = _series(values, int(key), min(now, fetched), require_nonempty=(key == "300"))
    five = parsed[300]
    return five, parsed.get(1800, _aggregate(five, 1800)), parsed.get(86400, _aggregate(five, 86400))


def load_crypto_data(source_path, symbol="BTC-USD", now=None):
    """Read closed 5m/30m/UTC-daily data as native-CZSC Shanghai Candles.

    Gaps in five-minute input remain gaps. Missing 30m/daily aggregation groups
    are skipped, so an insufficient daily history must leave strategy warm-up
    incomplete. Source labels are metadata, not cryptographic authenticity.
    """
    product, asof = normalize_product(symbol), _now_epoch(now)
    path = Path(source_path)
    text = _read_snapshot(path)
    if path.suffix.lower() == ".csv":
        data = _load_csv(text, asof)
    elif path.suffix.lower() == ".json":
        data = _load_json(text, product, asof)
    else:
        raise ValueError("Crypto input must be a five-minute CSV or a snapshot JSON")
    return tuple(_candles(rows) for rows in data)


def public_json(path, params=None):
    """Fixed-origin HTTPS GET only, with inherited proxy / TLS verification."""
    if not re.fullmatch(r"/products/[A-Z0-9]{2,12}-USD(?:/candles)?", path):
        raise ValueError("Unsupported public market-data route")
    url = "https://api.exchange.coinbase.com"+path
    if params:
        url += "?"+urlencode(params)
    request = Request(url, headers={"Accept": "application/json", "User-Agent": "CZSC-Paper-ReadOnly/0.1"})
    with urlopen(request, timeout=20) as response:
        body = response.read(2_000_001)
        if len(body) > 2_000_000:
            raise ValueError("Market-data response exceeded size limit")
        return json.loads(body)


def _product_instrument(product, request_json):
    spec = request_json("/products/"+product)
    if not isinstance(spec, dict) or spec.get("id") != product or spec.get("quote_currency") != "USD" or spec.get("status") != "online" or spec.get("trading_disabled"):
        raise ValueError("Product is not an available USD spot instrument")
    tick, step = _number(spec.get("quote_increment"), "quote_increment"), _number(spec.get("base_increment"), "base_increment")
    if tick <= 0 or step <= 0:
        raise ValueError("Invalid product increments")
    instrument = {"tick": tick, "step": step, "multiplier": 1, "quote_to_usd": 1, "short_allowed": False}
    if spec.get("min_market_funds") is not None:
        minimum = _number(spec["min_market_funds"], "min_market_funds")
        if minimum < 0:
            raise ValueError("Invalid minimum market funds")
        instrument["min_market_funds"] = minimum
    return instrument


def _fetch_window(product, seconds, first, end, asof, request_json, throttle):
    """Fetch bounded pages; provider ordering is not user-file ordering."""
    cursor, by_end = first, {}
    while cursor < end:
        stop = min(end, cursor+299*seconds)
        if throttle:
            time.sleep(throttle)
        response = request_json("/products/"+product+"/candles", {
            "granularity": seconds,
            "start": datetime.fromtimestamp(cursor, UTC).isoformat(),
            "end": datetime.fromtimestamp(stop, UTC).isoformat()})
        if not isinstance(response, list) or len(response) > 1000:
            raise ValueError("Invalid public candle response")
        seen = set()
        for raw in response:
            if not isinstance(raw, (list, tuple)) or len(raw) != 6:
                raise ValueError("Invalid Coinbase candle row")
            start = _integer(raw[0], "provider timestamp")
            if start in seen:
                raise ValueError("Provider returned duplicate candle timestamps")
            seen.add(start)
            normalized = _validate_row({"end": start+seconds, "open": raw[3], "high": raw[2], "low": raw[1], "close": raw[4], "volume": raw[5]}, seconds)
            if cursor <= start < stop and normalized["end"] <= asof:
                if normalized["end"] in by_end:
                    raise ValueError("Overlapping pages disagreed on a candle timestamp")
                by_end[normalized["end"]] = normalized
        cursor = stop
    return by_end


def fetch_crypto_history(product="BTC-USD", days=7, now=None, request_json=None, throttle=.15):
    """Download closed public candles. It never connects to an account.

    Each request spans at most299 bars; provider-returned extras are filtered.
    Daily warm-up covers180 UTC days and30m warm-up at least300 bars. CSV
    imports cannot synthesize these older bars when the source lacks them.
    """
    product, asof = normalize_product(product), _now_epoch(now)
    if isinstance(days, bool) or not isinstance(days, int) or not 1 <= days <= 365:
        raise ValueError("--days must be an integer from1 through365")
    if not math.isfinite(throttle) or throttle < 0:
        raise ValueError("Invalid request throttle")
    request_json = public_json if request_json is None else request_json
    instrument = _product_instrument(product, request_json)
    result = {}
    for seconds, count in ((300, days*288), (1800, max(300, days*48)), (86400, max(180, days))):
        end = asof//seconds*seconds
        first = end-count*seconds
        by_end = _fetch_window(product, seconds, first, end, asof, request_json, throttle)
        values = [by_end[key] for key in sorted(by_end)]
        if not values:
            raise ValueError("Provider returned no closed candles for a required timeframe")
        result[str(seconds)] = values
    return {"schema": SCHEMA, "asset_market": "crypto", "source": SOURCE,
            "product": product, "fetched_at": asof, "instrument": instrument,
            "series": result, "notice": "Read-only public USD spot history; no account access or orders. Missing candles remain missing. Source label is not an authenticity signature."}


def _official_snapshot(snapshot, asof, expected_product=None):
    """Validate an official-format seed. Labels are still not authenticity proof."""
    if not isinstance(snapshot, dict) or snapshot.get("schema") != SCHEMA or snapshot.get("source") != SOURCE or snapshot.get("asset_market") != "crypto":
        raise ValueError("Online refresh requires a Coinbase public-history JSON, not CSV or synthetic/user-labelled data")
    product = normalize_product(snapshot.get("product", ""))
    if expected_product is not None and product != normalize_product(expected_product):
        raise ValueError("The live output and source must have the same USD spot product")
    fetched = _integer(snapshot.get("fetched_at"), "fetched_at")
    if fetched > asof:
        raise ValueError("Snapshot capture time is in the future")
    instrument = snapshot.get("instrument")
    if (not isinstance(instrument, dict) or
            _number(instrument.get("multiplier"), "multiplier") != 1 or
            _number(instrument.get("quote_to_usd"), "quote_to_usd") != 1 or
            instrument.get("short_allowed") is not False or
            _number(instrument.get("tick"), "tick") <= 0 or
            _number(instrument.get("step"), "step") <= 0):
        raise ValueError("Refresh seed must describe an unleveraged USD spot instrument")
    series = snapshot.get("series")
    if not isinstance(series, dict) or set(series) != {"300", "1800", "86400"}:
        raise ValueError("Online refresh needs all three warm-up timeframes")
    clean = {}
    for seconds in TIMEFRAMES:
        original = series[str(seconds)]
        normalized = _series(original, seconds, fetched, require_nonempty=True)
        if len(normalized) != len(original):
            raise ValueError("Seed contains a candle that was open at capture time")
        clean[str(seconds)] = normalized
    return product, clean


def update_crypto_history(snapshot, now=None, request_json=None, throttle=.15):
    """Refresh public tails without mutating the seed or submitting orders.

    Normal polling reads only the latest three closed bars per timeframe. An
    interrupted feed catches up from one bar before the previous endpoint,
    in <=299-bar pages; a gap over90 days requires a new history download.
    Closed-bar provider revisions replace the same timestamp rather than create
    duplicates. Missing *new* bars fail closed instead of fabricating a bridge.
    """
    asof = _now_epoch(now)
    if not math.isfinite(throttle) or throttle < 0:
        raise ValueError("Invalid request throttle")
    product, old_series = _official_snapshot(snapshot, asof)
    request_json = public_json if request_json is None else request_json
    for seconds in TIMEFRAMES:
        if asof//seconds*seconds-old_series[str(seconds)][-1]["end"] > 90*86400:
            raise ValueError("History is more than90 days behind; download a new warm-up snapshot")
    instrument = _product_instrument(product, request_json)
    result, details = {}, {}
    for seconds in TIMEFRAMES:
        old = old_series[str(seconds)]
        previous_end = old[-1]["end"]
        end = asof//seconds*seconds
        first = min(end-3*seconds, previous_end-2*seconds)
        delta = _fetch_window(product, seconds, first, end, asof, request_json, throttle)
        # Every newly completed interval must actually be supplied. Existing
        # historical gaps remain explicit, but a refresh never invents new bars.
        required = range(previous_end+seconds, end+1, seconds)
        if any(stamp not in delta for stamp in required) or end not in delta:
            raise ValueError("Provider has not returned every newly closed candle; retry before processing paper orders")
        merged = {row["end"]: dict(row) for row in old}
        new_count = revised_count = 0
        for stamp, value in delta.items():
            if stamp not in merged:
                new_count += 1
            elif merged[stamp] != value:
                revised_count += 1
            merged[stamp] = value
        values = [merged[stamp] for stamp in sorted(merged)]
        if len(values) > MAX_ROWS:
            raise ValueError("Incremental history exceeded the supported size; archive and download a new warm-up file")
        result[str(seconds)] = values
        details[str(seconds)] = {"new_bars": new_count, "revised_bars": revised_count,
                                 "requested_start": first, "closed_end": end,
                                 "request_pages": (end-first+299*seconds-1)//(299*seconds)}
    return {"schema": SCHEMA, "asset_market": "crypto", "source": SOURCE,
            "product": product, "fetched_at": asof, "instrument": instrument,
            "series": result, "refresh_stats": details,
            "notice": "Read-only incrementally refreshed USD spot history. Historical revisions replace the same bar. Missing new bars pause processing. No exchange orders."}


def refresh_crypto_file(source_path, output_path, product=None, now=None, request_json=None, throttle=.15):
    """Atomically update a separate runner-owned live file; never alter source.

    Existing outputs must themselves be official-format history for the same
    product. A concurrent writer, protocol error or failed HTTP request leaves
    the previous file intact and propagates an exception to pause simulation.
    """
    source, output = Path(source_path), Path(output_path)
    if source.resolve() == output.resolve():
        raise ValueError("Live output must be separate from the user's history input")
    if output.is_symlink():
        raise ValueError("Refuse a symbolic-link live output")
    asof = _now_epoch(now)
    seed = json.loads(_read_snapshot(source))
    source_product, _ = _official_snapshot(seed, asof, product)
    before = None
    if output.exists():
        info = output.stat()
        before = (info.st_size, info.st_mtime_ns)
        seed = json.loads(_read_snapshot(output))
        _official_snapshot(seed, asof, source_product)
    updated = update_crypto_history(seed, asof, request_json=request_json, throttle=throttle)
    payload = json.dumps(updated, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".czsc-crypto-", delete=False) as file:
            temporary = Path(file.name)
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        if before is None:
            if output.exists():
                raise FileExistsError("Live output appeared during refresh; retry with a unique runner-owned path")
        else:
            info = output.stat()
            if (info.st_size, info.st_mtime_ns) != before:
                raise OSError("Live output changed during refresh; another writer may be running")
        os.replace(temporary, output)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return {"output": str(output), "product": updated["product"], "source": SOURCE,
            "fetched_at": updated["fetched_at"],
            "counts": {key: len(rows) for key, rows in updated["series"].items()},
            "updated_rows": updated["refresh_stats"], "paper_only": True}


def save_crypto_history(output, product="BTC-USD", days=7, now=None, **kwargs):
    """Fetch fully before creating a new file; never overwrite prior evidence."""
    output = Path(output)
    if output.exists():
        raise FileExistsError("Output exists; choose a new snapshot filename")
    dataset = fetch_crypto_history(product, days, now, **kwargs)
    content = json.dumps(dataset, ensure_ascii=False, indent=2, allow_nan=False)
    output.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with output.open("x", encoding="utf-8") as file:
            created = True
            file.write(content)
            file.flush()
    except BaseException:
        if created:
            output.unlink(missing_ok=True)
        raise
    return {"output": str(output), "source": SOURCE, "product": dataset["product"],
            "fetched_at": dataset["fetched_at"], "counts": {k: len(v) for k, v in dataset["series"].items()},
            "paper_only": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fetch", action="store_true", required=True, help="Explicitly request a read-only public history download")
    parser.add_argument("--product", default="BTC-USD")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(save_crypto_history(args.output, args.product, args.days), ensure_ascii=False))
    except (OSError, ValueError, KeyError, URLError) as error:
        parser.exit(1, f"Download failed; no successful snapshot produced: {error}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
