"""Formula text/encoding audits, not compilation in a Windows TDX client."""
from pathlib import Path
import re
import tempfile
import unittest

from make_formulas import COMMON, FORMULAS, LIVE_FIELDS, MAIN, generate, warning


def dll_fields(text):
    return {int(value) for value in re.findall(r"TDXDLL1\((\d+),", text)}


class VisualFormulaTests(unittest.TestCase):
    def test_all_sources_keep_slot_market_price_and_adjustment_guards(self):
        for name, text in FORMULAS.items():
            with self.subTest(name=name):
                self.assertTrue(text.startswith(COMMON))
                self.assertIn("1000000*SETCODE", text)
                self.assertIn("(SETCODE=0 OR SETCODE=1)", text)
                self.assertIn("(PERIOD=1 OR PERIOD=3 OR PERIOD=5)", text)
                self.assertIn("TQFLAG=0", text)
                self.assertIn("MATCH0:=SC0>0 AND ABS(C-SC0)", text)
                self.assertNotRegex(text, r"TDXDLL(?:[2-9]|\d{2,})\(")

    def test_visual_fields_match_the_sidecar_interface(self):
        expected = {
            "RP0": 11, "RK0": 12, "WP0": 13, "WK0": 14,
            "ZH0": 15, "ZL0": 16, "ZI0": 17,
            "VT0": 18, "VB0": 19, "VX0": 20,
            "F38": 21, "F50": 22, "F62": 23, "F79": 24,
            "SH0": 25, "SL0": 26, "ZS0": 27, "ZE0": 28,
        }
        for variable, field in expected.items():
            self.assertIn(f"{variable}:=TDXDLL1({field},DATE,TM0,KEY0);", MAIN)
        self.assertTrue(set(range(11, 29)).issubset(dll_fields(MAIN)))
        self.assertFalse({29, 30, 31} & dll_fields(MAIN))

    def test_rendering_switches_and_layer_order_preserve_candles(self):
        for switch in ("SHOWBI", "SHOWAUX", "SHOWZS", "SHOWFIB", "SHOWEVENT", "SHOWCONFIRM"):
            self.assertRegex(MAIN, rf"{switch}:=[01];")
        first_band = MAIN.index("STICKLINE(FG0")
        candles = MAIN.index("DRAWKLINE(H,O,L,C);")
        native_line = MAIN.index("DRAWLINE(BD0")
        self.assertLess(first_band, candles)
        self.assertLess(candles, native_line)
        self.assertIn("DRAWLINE(BD0=-1,BP0,BD0=1,BP0,0),COLORYELLOW", MAIN)
        self.assertIn("DRAWLINE(RA0=-1,RP0,RA0=1,RP0,0),COLORRED", MAIN)
        self.assertIn("DRAWLINE(WA0=-1,WP0,WA0=1,WP0,0),COLORBLUE", MAIN)

    def test_centers_have_paired_edges_and_candidate_events_are_not_moved(self):
        self.assertIn("ZV0:=SHOWZS AND OK0 AND ZI0>0", MAIN)
        self.assertIn("ZA0:=ZV0 AND ZS0>0;", MAIN)
        self.assertIn("ZB0:=ZV0 AND ZE0>0;", MAIN)
        self.assertIn("DRAWLINE(ZA0,ZH0,ZB0,ZH0,0),COLORMAGENTA", MAIN)
        self.assertIn("DRAWLINE(ZA0,ZL0,ZB0,ZL0,0),COLORMAGENTA", MAIN)
        self.assertIn("STICKLINE(ZA0 OR ZB0,ZH0,ZL0,0,0),COLORMAGENTA", MAIN)
        for field, label in (("VT0", "顶背驰候选"), ("VB0", "底背驰候选"), ("VX0", "区间扩宽")):
            marker = next(line for line in MAIN.splitlines() if line.startswith("DRAWTEXT(") and label in line)
            self.assertIn(f"SHOWEVENT AND OK0 AND {field}>0", marker)
            self.assertNotIn("REF(", marker)
        for forbidden in ("BACKSET(", "ZIG(", "PEAK(", "TROUGH(", "FILTERX("):
            self.assertNotIn(forbidden, MAIN)

    def test_live_warnings_are_separate_from_historical_visual_events(self):
        expected = {"CZSCUP": 5, "CZSCDN": 6, "CZSCTD": 29, "CZSCBD": 30, "CZSCWIDE": 31}
        self.assertEqual(set(LIVE_FIELDS), set(expected.values()))
        self.assertEqual(set(FORMULAS), {"CZSCMAIN", *expected})
        for name, field in expected.items():
            with self.subTest(name=name):
                text = FORMULAS[name]
                self.assertEqual(dll_fields(text), {7, 8, field})
                self.assertIn("MIN0:=PERIOD<>5 AND REF(EV0,1)>0 AND REF(RD0,1)>0 AND REF(MATCH0,1);", text)
                self.assertIn("DAY0:=PERIOD=5 AND EV0>0 AND RD0>0 AND MATCH0;", text)
                self.assertIn("XG:ALLOW0 AND (MIN0 OR DAY0);", text)
                for forbidden in ("DRAWLINE", "DRAWTEXT", "STICKLINE", "BACKSET", "VT0", "VB0", "VX0"):
                    self.assertNotIn(forbidden, text)
        for historical_field in (1, 2, 9, 10, 18, 19, 20, 27, 28):
            with self.assertRaises(ValueError):
                warning(historical_field)

    def test_main_identifies_itself_and_distinguishes_blocked_states(self):
        self.assertIn("DRAWTEXT_FIX(ISLASTBAR,0.01,0.01,0,'CZSC独立画线", MAIN)
        self.assertIn("历史端点可修订；背驰仅为候选", MAIN)
        self.assertIn("COUNT(MATCH0,2)=0", MAIN)
        self.assertIn("行情未匹配", MAIN)
        self.assertIn("COUNT(MATCH0,2)>0 AND COUNT(RD0>0,2)=0", MAIN)
        self.assertIn("缓存已过期", MAIN)
        self.assertIn("仍须在条件预警中添加并启用公式", MAIN)

    def test_utf8_and_gbk_outputs_exist_and_round_trip_with_crlf(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            generate(root)
            for encoding, folder in (("utf-8", "utf8"), ("gbk", "gbk")):
                self.assertEqual({path.stem for path in (root / folder).glob("*.txt")}, set(FORMULAS))
                for name, source in FORMULAS.items():
                    blob = (root / folder / (name + ".txt")).read_bytes()
                    self.assertFalse(blob.startswith(b"\xef\xbb\xbf"))
                    self.assertIn(b"\r\n", blob)
                    self.assertNotIn(b"\n", blob.replace(b"\r\n", b""))
                    self.assertNotIn(b"\r\r\n", blob)
                    self.assertEqual(blob.decode(encoding).replace("\r\n", "\n"), source)

    def test_distributed_sources_are_current(self):
        root = Path(__file__).resolve().parent / "formulas"
        for encoding, folder in (("utf-8", "utf8"), ("gbk", "gbk")):
            for name, source in FORMULAS.items():
                with self.subTest(folder=folder, formula=name):
                    path = root / folder / (name + ".txt")
                    self.assertTrue(path.is_file(), f"Missing generated formula: {path}")
                    self.assertEqual(path.read_bytes().decode(encoding).replace("\r\n", "\n"), source)


if __name__ == "__main__":
    unittest.main()
