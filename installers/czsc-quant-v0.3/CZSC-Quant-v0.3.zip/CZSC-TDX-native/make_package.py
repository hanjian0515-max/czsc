"""Create a reviewable source+Windows DLL ZIP without local data or credentials."""
import argparse
import hashlib
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from windows_launcher import pe_arch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    members = {}
    for source in sorted(root.glob("*.py")):
        members[source.name] = source.read_bytes()
    for name in ("README.md", "czsc_bridge.c", "check_windows_dll.c", "setup_bootstrap.c", "requirements-lock.txt", "INSTALL_AND_RUN.cmd", "CHECK_32BIT_DLL.cmd"):
        blob = (root/name).read_bytes()
        members[name] = blob.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n") if name.endswith(".cmd") else blob
    for source in sorted((root/"formulas").glob("*/*.txt")):
        members[source.relative_to(root).as_posix()] = source.read_bytes()
    for arch in ("x64", "x86"):
        source = root/"build"/arch/"CZSCBridge.dll"
        if pe_arch(source) != arch:
            raise ValueError("DLL architecture verification failed")
        members[f"bin/{arch}/CZSCBridge.dll"] = source.read_bytes()
        checker = root/"build"/arch/"CZSCCheck.exe"
        if pe_arch(checker) != arch:
            raise ValueError("Loader diagnostic architecture verification failed")
        members[f"bin/{arch}/CZSCCheck.exe"] = checker.read_bytes()
    members["START-HERE.txt"] = (
        "CZSC画线与自动模拟量化 v0.3（待Windows验收版）\r\n"
        "1. 准备Python3.12 64位；ZIP解压后运行INSTALL_AND_RUN.cmd。\r\n"
        "2. 点“自动量化：模拟/回测”，选择沪深股票或BTC-USD。\r\n"
        "3. 回测与模拟各用独立账户；行情过期不补单，无真实账户接口。\r\n"
        "4. 通达信画线另按README绑定新版DLL、复制公式，图表不复权。\r\n"
        "历史数据可回测；自动运行需持续行情。Windows与真实行情仍需实测。\r\n"
    ).encode("utf-8-sig")
    members["SHA256SUMS.txt"] = "".join(hashlib.sha256(blob).hexdigest()+"  "+name+"\n" for name, blob in sorted(members.items())).encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(args.output, "x", ZIP_DEFLATED) as archive:
        for name, blob in sorted(members.items()):
            archive.writestr("CZSC-TDX-native/"+name, blob)
        if archive.testzip() is not None:
            raise ValueError("ZIP integrity check failed")
    print(args.output)
    print("Files:", len(members), "ZIP SHA256:", hashlib.sha256(args.output.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
