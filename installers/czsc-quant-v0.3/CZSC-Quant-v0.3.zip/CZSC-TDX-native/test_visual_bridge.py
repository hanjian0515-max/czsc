"""Exercise the actual C visual-cache bridge using synthetic binary fixtures.

All prices, symbols, boxes and flags below are invented test data, not market
data or trading signals. GCC/Linux ctypes checks the cache ABI and read rules;
it does not validate loading the DLL in Windows or Tongdaxin.
"""
from __future__ import annotations

import ctypes as ct
from datetime import datetime, timedelta, timezone
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import time
import unittest


HEADER = struct.Struct("<8sIIIIQQ")
VISUAL_RECORD = struct.Struct("<II18f")
BASE_RECORD = struct.Struct("<IIfffffI")
SHANGHAI = timezone(timedelta(hours=8))
FLOATS = ct.POINTER(ct.c_float)
VISUAL_FIELDS = (
    "redPrice", "redKind", "bluePrice", "blueKind", "boxHigh", "boxLow",
    "boxID", "divTop", "divBottom", "expand", "fib382", "fib500",
    "fib618", "fib786", "swingHigh", "swingLow", "boxStart", "boxEnd",
)


def tdx_clock(epoch: int) -> tuple[int, int]:
    local = datetime.fromtimestamp(epoch, SHANGHAI)
    return ((local.year - 1900) * 10000 + local.month * 100 + local.day,
            local.hour * 100 + local.minute)


class VisualBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("gcc")
        if compiler is None:
            raise unittest.SkipTest("gcc is required to exercise the real C bridge")
        cls.build = tempfile.TemporaryDirectory(prefix="czsc-visual-bridge-build-")
        library = Path(cls.build.name) / "visual_bridge.so"
        subprocess.run(
            [compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-shared", "-fPIC",
             str(Path(__file__).with_name("czsc_bridge.c")), "-lm", "-o", str(library)],
            check=True, capture_output=True, text=True,
        )
        cls.bridge = ct.CDLL(str(library))
        cls.bridge.CZSC_SetTestDirectory.argtypes = [ct.c_char_p]
        cls.bridge.CZSC_SetTestDirectory.restype = None
        cls.bridge.CZSC_BridgeRead.argtypes = [ct.c_int, ct.c_int, FLOATS, FLOATS, FLOATS, FLOATS]
        cls.bridge.CZSC_BridgeRead.restype = None

    @classmethod
    def tearDownClass(cls):
        cls.build.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="czsc-visual-fixture-")
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name)
        self.bridge.CZSC_SetTestDirectory(str(self.path).encode())
        self.now = int(time.time())
        # A minute boundary is always less than 60 seconds old, avoiding a
        # wall-clock race at the source's 90-second live-alert cutoff.
        self.newest = self.now // 60 * 60
        self.previous_date, self.previous_time = tdx_clock(self.newest - 300)
        self.last_date, self.last_time = tdx_clock(self.newest)
        self.rows = [
            (self.previous_date, self.previous_time,
             111.25, -1, 101.5, 1, 109.5, 103.5, 7, 1, 0, 1,
             108.25, 106.5, 104.75, 102, 114, 99, 1, 0),
            (self.last_date, self.last_time,
             121.75, 1, 110.25, -1, 119, 112, 8, 0, 1, 0,
             118.25, 116.5, 114.75, 113, 124, 109, 0, 1),
        ]

    def write(self, *, rows=None, key=1600000, period=1, generated=None, newest=None,
              magic=b"CZTDV02\0", version=2, count=None, extra=b"",
              filename_key=None, filename_period=None):
        rows = self.rows if rows is None else rows
        header = HEADER.pack(
            magic, version, period, key, len(rows) if count is None else count,
            self.now if generated is None else generated,
            self.newest if newest is None else newest,
        )
        name = (f"{key if filename_key is None else filename_key}_"
                f"{period if filename_period is None else filename_period}_visual.bin")
        path = self.path / name
        path.write_bytes(header + b"".join(VISUAL_RECORD.pack(*row) for row in rows) + extra)
        return path

    def call(self, field, *, dates=None, packed=None, keys=None):
        dates = [self.previous_date, self.last_date] if dates is None else dates
        packed = [10000 + self.previous_time, 10000 + self.last_time] if packed is None else packed
        keys = [1600000] * len(dates) if keys is None else keys
        self.assertEqual(len(dates), len(packed))
        self.assertEqual(len(dates), len(keys))
        array = ct.c_float * len(dates)
        out = array(*([-999] * len(dates)))
        self.bridge.CZSC_BridgeRead(field, len(dates), out, array(*dates), array(*packed), array(*keys))
        return list(out)

    def assert_no_live_flags(self, **inputs):
        for field in (29, 30, 31):
            with self.subTest(live_field=field):
                self.assertEqual(self.call(field, **inputs), [0.0, 0.0])

    def assert_rejected(self):
        for field in range(11, 32):
            with self.subTest(rejected_field=field):
                self.assertEqual(self.call(field), [0.0, 0.0])

    def changed_rows(self, value_index, value, *, row_index=-1):
        rows = list(self.rows)
        row = list(rows[row_index])
        row[value_index + 2] = value
        rows[row_index] = tuple(row)
        return rows

    def test_visual_binary_contract_and_all_eighteen_field_mappings(self):
        self.assertEqual(HEADER.size, 40)
        self.assertEqual(VISUAL_RECORD.size, 80)
        self.assertEqual(len(VISUAL_FIELDS), 18)
        self.write()
        for offset, name in enumerate(VISUAL_FIELDS):
            with self.subTest(field=offset + 11, name=name):
                self.assertEqual(self.call(offset + 11), [float(row[offset + 2]) for row in self.rows])

    def test_live_flags_map_to_divergence_and_expansion_only_on_latest_row(self):
        rows = [tuple(list(row[:9]) + [1, 1, 1] + list(row[12:])) for row in self.rows]
        self.write(rows=rows)
        # Historical flags remain visible at fields 18..20. Live fields must
        # not re-emit the preceding row's identical flags.
        for historical, live in ((18, 29), (19, 30), (20, 31)):
            with self.subTest(historical=historical, live=live):
                self.assertEqual(self.call(historical), [1.0, 1.0])
                self.assertEqual(self.call(live), [0.0, 1.0])
        self.write()
        self.assertEqual(self.call(29), [0.0, 0.0])
        self.assertEqual(self.call(30), [0.0, 1.0])
        self.assertEqual(self.call(31), [0.0, 0.0])

    def test_historical_query_of_fresh_cache_cannot_reemit_live_flags(self):
        self.write()
        inputs = dict(dates=[self.previous_date] * 2,
                      packed=[10000 + self.previous_time] * 2)
        self.assertEqual(self.call(18, **inputs), [1.0, 1.0])
        self.assertEqual(self.call(20, **inputs), [1.0, 1.0])
        self.assert_no_live_flags(**inputs)

    def test_stale_generated_cache_retains_all_drawings_but_no_live_flags(self):
        self.write(generated=self.now - 16)
        for offset in range(18):
            with self.subTest(field=11 + offset):
                self.assertEqual(self.call(11 + offset), [float(row[2 + offset]) for row in self.rows])
        self.assert_no_live_flags()

    def test_fresh_generation_cannot_refresh_stale_source_candles(self):
        old_newest = self.newest - 1200
        self.previous_date, self.previous_time = tdx_clock(old_newest - 300)
        self.last_date, self.last_time = tdx_clock(old_newest)
        rows = [(self.previous_date, self.previous_time, *self.rows[0][2:]),
                (self.last_date, self.last_time, *self.rows[1][2:])]
        self.write(rows=rows, newest=old_newest)
        self.assertEqual(self.call(11), [111.25, 121.75])
        self.assertEqual(self.call(19), [0.0, 1.0])
        self.assert_no_live_flags()

    def test_future_generated_time_preserves_drawings_and_blocks_live_flags(self):
        self.write(generated=self.now + 3600)
        self.assertEqual(self.call(11), [111.25, 121.75])
        self.assert_no_live_flags()

    def test_future_source_with_matching_header_blocks_live_flags(self):
        future_newest = self.newest + 3600
        self.previous_date, self.previous_time = tdx_clock(future_newest - 300)
        self.last_date, self.last_time = tdx_clock(future_newest)
        rows = [(self.previous_date, self.previous_time, *self.rows[0][2:]),
                (self.last_date, self.last_time, *self.rows[1][2:])]
        self.write(rows=rows, newest=future_newest)
        self.assertEqual(self.call(11), [111.25, 121.75])
        self.assert_no_live_flags()

    def test_newest_header_must_match_last_row_even_when_both_look_fresh(self):
        for newest in (self.newest + 60, self.newest - 60, 0):
            with self.subTest(newest=newest):
                self.write(newest=newest)
                self.assert_rejected()

    def test_market_key_separates_same_numeric_symbol(self):
        self.write(key=1000001)
        other = self.changed_rows(0, 221.75)
        self.write(key=1, rows=other)
        self.assertEqual(self.call(11, keys=[1000001] * 2), [111.25, 121.75])
        self.assertEqual(self.call(11, keys=[1] * 2), [111.25, 221.75])
        self.assertEqual(self.call(11, keys=[2000001] * 2), [0.0, 0.0])
        # One request chooses its last row's market; earlier rows from a
        # different market cannot borrow that file's visual data.
        self.assertEqual(self.call(11, keys=[1000001, 1]), [0.0, 221.75])

    def test_period_files_are_separate_and_mixed_period_rows_do_not_leak(self):
        self.write()
        self.write(period=3, rows=self.changed_rows(0, 321.75))
        self.assertEqual(self.call(11), [111.25, 121.75])
        self.assertEqual(self.call(11, packed=[30000 + self.previous_time, 30000 + self.last_time]),
                         [111.25, 321.75])
        self.assertEqual(self.call(11, packed=[30000 + self.previous_time, 10000 + self.last_time]),
                         [0.0, 121.75])
        self.assertEqual(self.call(11, packed=[20000 + self.previous_time, 20000 + self.last_time]),
                         [0.0, 0.0])

    def test_date_and_minute_match_exactly_without_backfilling(self):
        self.write()
        before_date, before_time = tdx_clock(self.newest - 86400)
        gap_date, gap_time = tdx_clock(self.newest - 60)
        self.assertEqual(self.call(11, dates=[before_date, gap_date],
                                   packed=[10000 + before_time, 10000 + gap_time]), [0.0, 0.0])
        self.assertEqual(self.call(11, dates=[self.last_date, self.previous_date],
                                   packed=[10000 + self.last_time, 10000 + self.previous_time]),
                         [121.75, 111.25])

    def test_daily_cache_requires_zero_record_time_and_normalizes_input_time(self):
        close = datetime.fromtimestamp(self.now, SHANGHAI).replace(
            hour=15, minute=0, second=0, microsecond=0) - timedelta(days=2)
        newest = int(close.timestamp())
        previous_date, _ = tdx_clock(newest - 86400)
        last_date, _ = tdx_clock(newest)
        rows = [(previous_date, 0, *self.rows[0][2:]), (last_date, 0, *self.rows[1][2:])]
        inputs = dict(dates=[previous_date, last_date], packed=[50935, 51500])
        self.write(period=5, rows=rows, newest=newest)
        self.assertEqual(self.call(11, **inputs), [111.25, 121.75])
        self.assert_no_live_flags(**inputs)
        self.write(period=5, rows=[(row[0], 1500, *row[2:]) for row in rows], newest=newest)
        self.assertEqual(self.call(11, **inputs), [0.0, 0.0])

    def test_missing_short_trailing_and_corrupt_header_fail_closed(self):
        self.assert_rejected()
        cases = [dict(magic=b"CZTDX01\0"), dict(magic=b"CZTDV02x"), dict(version=1),
                 dict(count=0), dict(count=3), dict(count=250001), dict(extra=b"x"),
                 dict(key=1600001, filename_key=1600000), dict(period=3, filename_period=1)]
        for kwargs in cases:
            with self.subTest(**kwargs):
                self.write(**kwargs)
                self.assert_rejected()
        path = self.path / "1600000_1_visual.bin"
        valid = self.write().read_bytes()
        for length in (0, 1, 39, 40, 119, len(valid) - 1):
            with self.subTest(length=length):
                path.write_bytes(valid[:length])
                self.assert_rejected()

    def test_nonfinite_values_in_every_visual_column_reject_entire_cache(self):
        for index, name in enumerate(VISUAL_FIELDS):
            for bad in (float("nan"), float("inf"), float("-inf")):
                with self.subTest(name=name, bad=bad):
                    self.write(rows=self.changed_rows(index, bad))
                    self.assert_rejected()

    def test_endpoint_price_and_kind_must_be_consistent(self):
        for price_index in (0, 2):
            for price, kind in ((10, 2), (10, -2), (10, 0.5), (-1, 1), (0, 1), (10, 0)):
                with self.subTest(price_index=price_index, price=price, kind=kind):
                    rows = self.changed_rows(price_index, price)
                    row = list(rows[-1]); row[price_index + 3] = kind; rows[-1] = tuple(row)
                    self.write(rows=rows)
                    self.assert_rejected()
        zero = [(*row[:2], 0, 0, 0, 0, *row[6:]) for row in self.rows]
        self.write(rows=zero)
        for field in (11, 12, 13, 14):
            self.assertEqual(self.call(field), [0.0, 0.0])
        self.assertEqual(self.call(15), [109.5, 119.0])

    def test_box_bounds_and_integer_identity_are_validated(self):
        invalid = ((111, 112, 8), (119, 0, 8), (0, 0, 8), (119, 112, 0),
                   (119, 112, -1), (119, 112, 0.5), (119, 112, 250001),
                   (-1, -2, 8))
        for high, low, identity in invalid:
            with self.subTest(high=high, low=low, identity=identity):
                row = list(self.rows[-1]); row[6:9] = [high, low, identity]
                self.write(rows=[self.rows[0], tuple(row)])
                self.assert_rejected()
        # A zero-width overlap is a legitimate CZSC box boundary.
        row = list(self.rows[-1]); row[6:9] = [112, 112, 250000]
        self.write(rows=[self.rows[0], tuple(row)])
        self.assertEqual(self.call(15), [109.5, 112.0])
        self.assertEqual(self.call(17), [7.0, 250000.0])

    def test_boolean_flags_and_nonnegative_fibonacci_and_swing_prices(self):
        for index in (7, 8, 9, 16, 17):
            for bad in (-1, 0.5, 2):
                with self.subTest(name=VISUAL_FIELDS[index], bad=bad):
                    self.write(rows=self.changed_rows(index, bad))
                    self.assert_rejected()
        for index in range(10, 16):
            with self.subTest(name=VISUAL_FIELDS[index]):
                self.write(rows=self.changed_rows(index, -0.25))
                self.assert_rejected()

    def test_no_box_accepts_zero_start_end_flags_but_rejects_orphan_flags(self):
        empty_rows = []
        for row in self.rows:
            values = list(row)
            values[6:9] = [0, 0, 0]
            values[18:20] = [0, 0]
            empty_rows.append(tuple(values))
        self.write(rows=empty_rows)
        for field in (15, 16, 17, 27, 28):
            self.assertEqual(self.call(field), [0.0, 0.0])
        self.assertEqual(self.call(11), [111.25, 121.75])
        for column in (18, 19):
            with self.subTest(column=column):
                row = list(empty_rows[-1]); row[column] = 1
                self.write(rows=[empty_rows[0], tuple(row)])
                self.assert_rejected()

    def test_invalid_calendar_time_and_nonincreasing_records_are_rejected(self):
        for column, bad in ((0, 1260230), (0, 1261301), (0, 1260001), (0, 1261100),
                            (0, 690101), (0, 3000101), (1, 2360), (1, 1260), (1, 2400)):
            with self.subTest(column=column, bad=bad):
                row = list(self.rows[-1]); row[column] = bad
                self.write(rows=[self.rows[0], tuple(row)])
                self.assert_rejected()
        for rows in (list(reversed(self.rows)), [self.rows[-1], self.rows[-1]]):
            with self.subTest(rows=rows):
                self.write(rows=rows)
                self.assert_rejected()

    def test_invalid_formula_inputs_and_unknown_fields_do_not_leak_values(self):
        self.write()
        for bad in (float("nan"), float("inf"), -1, 0.5, 3000001):
            for argument, valid in (("dates", self.last_date), ("packed", 10000 + self.last_time),
                                    ("keys", 1600000)):
                with self.subTest(argument=argument, bad=bad):
                    # Preserve a valid final array row so the row-level check
                    # is exercised, rather than just the initial file choice.
                    inputs = {argument: [bad, valid]}
                    self.assertEqual(self.call(11, **inputs), [0.0, 121.75])
                    self.assertEqual(self.call(30, **inputs), [0.0, 1.0])
        for field in (-1, 0, 32, 99):
            self.assertEqual(self.call(field), [0.0, 0.0])

    def test_v1_fields_are_independent_of_missing_valid_or_corrupt_visual_sidecar(self):
        rows = [(self.previous_date, self.previous_time, 10, 9.5, -1, 10.5, 9.5, 2),
                (self.last_date, self.last_time, 11, 11.5, 1, 10.5, 9.5, 1)]
        header = HEADER.pack(b"CZTDX01\0", 1, 1, 1600000, 2, self.now, self.newest)
        base = self.path / "1600000_1.bin"
        base.write_bytes(header + b"".join(BASE_RECORD.pack(*row) for row in rows))
        expected = {1: [9.5, 11.5], 2: [-1.0, 1.0], 3: [10.5, 10.5], 4: [9.5, 9.5],
                    5: [0.0, 1.0], 6: [0.0, 0.0], 7: [0.0, 1.0], 8: [10.0, 11.0],
                    9: [0.0, 1.0], 10: [1.0, 0.0]}
        for sidecar in ("missing", "valid", "corrupt"):
            if sidecar == "valid":
                self.write()
            elif sidecar == "corrupt":
                self.write(rows=self.changed_rows(0, float("nan")))
            for field, values in expected.items():
                with self.subTest(sidecar=sidecar, field=field):
                    self.assertEqual(self.call(field), values)
        self.write()
        base.write_bytes(b"broken v1 cache")
        self.assertEqual(self.call(8), [0.0, 0.0])
        self.assertEqual(self.call(11), [111.25, 121.75])


if __name__ == "__main__":
    unittest.main()
