/* CZSC Windows 10/11 self-extracting installer. No CRT or network access.
 * Container: PE || validated ZIP || "CZSCSFX1" || uint64 offset || uint64 size.
 * ZIP validation and SHA256 manifest verification happen in build_installer.py.
 * Paths travel through Win32 Unicode APIs and process environment variables.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>
#include "payload_config.h"

DWORD _tls_index;
#define PATH_CAP 32768
#define MAX_PAYLOAD (64ULL * 1024ULL * 1024ULL)
static wchar_t self_path[PATH_CAP], temp_path[PATH_CAP], zip_path[PATH_CAP];
static wchar_t destination[PATH_CAP], product_path[PATH_CAP];
static wchar_t program_path[PATH_CAP], command_line[PATH_CAP];
static BYTE transfer_buffer[65536];
static BOOL temp_owned, zip_owned;

static void print(const char *message) {
    DWORD length = 0, written = 0;
    while (message[length]) ++length;
    WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), message, length, &written, NULL);
}

static void print_number(DWORD number) {
    char reverse[16], buffer[16];
    unsigned n = 0, i = 0;
    do { reverse[n++] = (char)('0' + number % 10); number /= 10; } while (number);
    while (n) buffer[i++] = reverse[--n];
    buffer[i] = 0;
    print(buffer);
}

static DWORD wide_length(const wchar_t *text) {
    DWORD n = 0;
    while (n < PATH_CAP && text[n]) ++n;
    return n;
}

static BOOL append(wchar_t *buffer, const wchar_t *value) {
    DWORD n = wide_length(buffer), size = wide_length(value);
    if (n >= PATH_CAP || size >= PATH_CAP || size > PATH_CAP - 1 - n) return FALSE;
    for (DWORD i = 0; i <= size; ++i) buffer[n+i] = value[i];
    return TRUE;
}

static BOOL copy(wchar_t *buffer, const wchar_t *value) {
    buffer[0] = 0;
    return append(buffer, value);
}

static BOOL append_hex(wchar_t *buffer, DWORD number) {
    wchar_t digits[9];
    for (unsigned i = 0; i < 8; ++i) {
        unsigned digit = (number >> ((7 - i) * 4)) & 15;
        digits[i] = (wchar_t)(digit < 10 ? L'0' + digit : L'a' + digit - 10);
    }
    digits[8] = 0;
    return append(buffer, digits);
}

static void cleanup(void) {
    if (zip_owned && zip_path[0]) DeleteFileW(zip_path);
    if (temp_owned && temp_path[0]) RemoveDirectoryW(temp_path);
}

static void fail(const char *message) {
    DWORD error = GetLastError();
    cleanup();
    print("\r\nINSTALL_FAILED: "); print(message);
    print("\r\nWindows error: "); print_number(error);
    print("\r\nNo alarms are assumed active. Press Enter to close.\r\n");
    char input[2];
    DWORD read = 0;
    ReadFile(GetStdHandle(STD_INPUT_HANDLE), input, 1, &read, NULL);
    ExitProcess(1);
}

static uint64_t read_u64(const BYTE *bytes) {
    uint64_t value = 0;
    for (unsigned i = 0; i < 8; ++i) value |= ((uint64_t)bytes[i]) << (8 * i);
    return value;
}

static BOOL seek_file(HANDLE file, uint64_t offset) {
    LARGE_INTEGER position;
    position.QuadPart = (LONGLONG)offset;
    return SetFilePointerEx(file, position, NULL, FILE_BEGIN);
}

static void extract_payload(void) {
    HANDLE source = CreateFileW(self_path, GENERIC_READ, FILE_SHARE_READ, NULL,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (source == INVALID_HANDLE_VALUE) fail("Cannot open this installer.");
    LARGE_INTEGER file_size;
    BYTE trailer[24];
    DWORD count = 0;
    if (!GetFileSizeEx(source, &file_size) || file_size.QuadPart < 88 ||
        !seek_file(source, (uint64_t)file_size.QuadPart - 24) ||
        !ReadFile(source, trailer, 24, &count, NULL) || count != 24) {
        CloseHandle(source); fail("Cannot read installer trailer.");
    }
    const BYTE magic[] = {'C','Z','S','C','S','F','X','1'};
    for (unsigned i = 0; i < 8; ++i) {
        if (trailer[i] != magic[i]) { CloseHandle(source); fail("Invalid installer magic."); }
    }
    uint64_t offset = read_u64(trailer + 8), remaining = read_u64(trailer + 16);
    uint64_t end = (uint64_t)file_size.QuadPart - 24;
    if (offset < 64 || offset > end || !remaining || remaining > MAX_PAYLOAD ||
        remaining != end - offset || !seek_file(source, offset)) {
        CloseHandle(source); fail("Invalid payload boundaries.");
    }
    HANDLE output = CreateFileW(zip_path, GENERIC_WRITE, 0, NULL, CREATE_NEW,
                                FILE_ATTRIBUTE_NORMAL, NULL);
    if (output == INVALID_HANDLE_VALUE) { CloseHandle(source); fail("Cannot create temporary ZIP."); }
    zip_owned = TRUE;
    while (remaining) {
        DWORD wanted = remaining > sizeof(transfer_buffer) ? sizeof(transfer_buffer) : (DWORD)remaining;
        DWORD read = 0, written = 0;
        if (!ReadFile(source, transfer_buffer, wanted, &read, NULL) || read != wanted ||
            !WriteFile(output, transfer_buffer, read, &written, NULL) || written != read) {
            CloseHandle(output); CloseHandle(source); fail("Cannot extract ZIP payload.");
        }
        remaining -= read;
    }
    CloseHandle(output);
    CloseHandle(source);
}

static DWORD run_process(const wchar_t *program, wchar_t *command, const wchar_t *directory) {
    STARTUPINFOW startup;
    PROCESS_INFORMATION process;
    volatile BYTE *p = (volatile BYTE *)&startup;
    for (unsigned i = 0; i < sizeof(startup); ++i) p[i] = 0;
    p = (volatile BYTE *)&process;
    for (unsigned i = 0; i < sizeof(process); ++i) p[i] = 0;
    startup.cb = sizeof(startup);
    if (!CreateProcessW(program, command, NULL, NULL, FALSE, 0, NULL,
                        directory, &startup, &process)) fail("Cannot start installation process.");
    CloseHandle(process.hThread);
    DWORD code = 1;
    if (WaitForSingleObject(process.hProcess, INFINITE) != WAIT_OBJECT_0 ||
        !GetExitCodeProcess(process.hProcess, &code)) {
        CloseHandle(process.hProcess); fail("Cannot wait for installation process.");
    }
    CloseHandle(process.hProcess);
    return code;
}

static BOOL system_program(const wchar_t *name) {
    DWORD n = GetSystemDirectoryW(program_path, PATH_CAP);
    return n && n < PATH_CAP && append(program_path, name);
}

void mainCRTStartup(void) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
    print("CZSC Visual installer - Windows 10/11\r\n");
    print("Installing program files; existing runtime and market data are preserved.\r\n");
    DWORD n = GetModuleFileNameW(NULL, self_path, PATH_CAP);
    if (!n || n >= PATH_CAP) fail("Cannot locate this installer.");
    n = GetEnvironmentVariableW(L"LOCALAPPDATA", destination, PATH_CAP);
    if (!n || n >= PATH_CAP || n < 3 || destination[1] != L':' || destination[2] != L'\\' ||
        !((destination[0] >= L'A' && destination[0] <= L'Z') || (destination[0] >= L'a' && destination[0] <= L'z')))
        fail("LOCALAPPDATA must be a local absolute drive path; UNC profiles are unsupported.");
    if (!append(destination, L"\\CZSC-TDX-Visual") ||
        !copy(product_path, destination) || !append(product_path, L"\\CZSC-TDX-native"))
        fail("Cannot determine per-user installation directory.");
    wchar_t temp_root[PATH_CAP];
    n = GetTempPathW(PATH_CAP, temp_root);
    if (!n || n >= PATH_CAP) fail("Cannot locate user TEMP.");
    BOOL created = FALSE;
    for (DWORD attempt = 0; attempt < 100; ++attempt) {
        if (!copy(temp_path, temp_root) || !append(temp_path, L"CZSCSetup-") ||
            !append_hex(temp_path, GetCurrentProcessId()) || !append(temp_path, L"-") ||
            !append_hex(temp_path, GetTickCount()) || !append_hex(temp_path, attempt))
            fail("Temporary path is too long.");
        if (CreateDirectoryW(temp_path, NULL)) { created = TRUE; temp_owned = TRUE; break; }
        if (GetLastError() != ERROR_ALREADY_EXISTS) break;
    }
    if (!created) { temp_path[0] = 0; fail("Cannot create independent temporary directory."); }
    if (!copy(zip_path, temp_path) || !append(zip_path, L"\\payload.zip")) fail("ZIP path is too long.");
    extract_payload();
    if (!SetEnvironmentVariableW(L"CZSC_SETUP_ZIP", zip_path) ||
        !SetEnvironmentVariableW(L"CZSC_SETUP_DEST", destination)) fail("Cannot pass installation paths.");
    if (!system_program(L"\\WindowsPowerShell\\v1.0\\powershell.exe") ||
        !copy(command_line, L"\"") || !append(command_line, program_path) ||
        !append(command_line, L"\"") || !append(command_line, CZSC_SETUP_COMMAND))
        fail("PowerShell path is too long.");
    print("Expanding verified package to LOCALAPPDATA\\CZSC-TDX-Visual...\r\n");
    DWORD code = run_process(program_path, command_line, NULL);
    cleanup();
    zip_path[0] = 0; temp_path[0] = 0;
    SetEnvironmentVariableW(L"CZSC_SETUP_ZIP", NULL);
    SetEnvironmentVariableW(L"CZSC_SETUP_DEST", NULL);
    if (code) { print("PowerShell exit code: "); print_number(code); fail("ZIP installation did not complete."); }
    /* Fixed CMD name + explicit working directory: no user path enters shell text. */
    if (!system_program(L"\\cmd.exe") || !copy(command_line, L"\"") ||
        !append(command_line, program_path) || !append(command_line, L"\" /d /c INSTALL_AND_RUN.cmd"))
        fail("CMD path is too long.");
    print("Program files installed. Starting INSTALL_AND_RUN.cmd...\r\n");
    code = run_process(program_path, command_line, product_path);
    if (code) { print("Launcher exit code: "); print_number(code); fail("Program launcher reported failure."); }
    ExitProcess(0);
}
