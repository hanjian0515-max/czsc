"""Compile and exercise the real C cache bridge with synthetic binary fixtures.

These are Linux ABI/cache tests, not a claim of Windows Tongdaxin validation.
No fixture in this module represents market data.
"""
from __future__ import annotations

import ctypes as ct
from datetime import datetime, timedelta, timezone
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import time
import unittest


HEADER = struct.Struct("<8sIIIIQQ")
RECORD = struct.Struct("<IIfffffI")
SHANGHAI = timezone(timedelta(hours=8))
FLOATS = ct.POINTER(ct.c_float)
CALLBACK = ct.CFUNCTYPE(None, ct.c_int, FLOATS, FLOATS, FLOATS, FLOATS)


class FunctionInfo(ct.Structure):
    _pack_ = 1
    _fields_ = [("id", ct.c_uint16), ("function", CALLBACK)]


def tdx_clock(epoch: int) -> tuple[int, int]:
    local = datetime.fromtimestamp(epoch, SHANGHAI)
    return (local.year - 1900) * 10000 + local.month * 100 + local.day, local.hour * 100 + local.minute


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("gcc")
        if compiler is None:
            raise unittest.SkipTest("gcc is required to test the actual C bridge")
        cls.build_dir = tempfile.TemporaryDirectory(prefix="czsc-bridge-build-")
        library = Path(cls.build_dir.name) / "bridge.so"
        subprocess.run([compiler, "-std=c11", "-O2", "-Wall", "-Wextra", "-shared", "-fPIC",
                        str(Path(__file__).with_name("czsc_bridge.c")), "-lm", "-o", str(library)],
                       check=True, capture_output=True, text=True)
        cls.bridge = ct.CDLL(str(library))
        cls.bridge.CZSC_SetTestDirectory.argtypes = [ct.c_char_p]
        cls.bridge.CZSC_SetTestDirectory.restype = None
        cls.bridge.CZSC_BridgeRead.argtypes = [ct.c_int, ct.c_int, FLOATS, FLOATS, FLOATS, FLOATS]
        cls.bridge.CZSC_BridgeRead.restype = None
        cls.bridge.RegisterTdxFunc.argtypes = [ct.POINTER(ct.POINTER(FunctionInfo))]
        cls.bridge.RegisterTdxFunc.restype = ct.c_int

    @classmethod
    def tearDownClass(cls):
        cls.build_dir.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="czsc-bridge-fixture-")
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name)
        self.bridge.CZSC_SetTestDirectory(str(self.path).encode())
        self.now = int(time.time())
        self.last_end = self.now // 60 * 60
        self.previous_date, self.previous_time = tdx_clock(self.last_end - 300)
        self.last_date, self.last_time = tdx_clock(self.last_end)
        self.rows = [
            (self.previous_date, self.previous_time, 10.0, 9.5, -1.0, 10.5, 9.5, 2),
            (self.last_date, self.last_time, 11.0, 11.5, 1.0, 10.5, 9.5, 1),
        ]

    def write(self, *, key=1600000, period=1, rows=None, generated=None,
              newest=None, magic=b"CZTDX01\0", version=1, count=None, extra=b"",
              filename_key=None, filename_period=None):
        rows = self.rows if rows is None else rows
        header = HEADER.pack(magic, version, period, key,
                             len(rows) if count is None else count,
                             self.now if generated is None else generated,
                             self.last_end if newest is None else newest)
        filename = self.path / f"{key if filename_key is None else filename_key}_{period if filename_period is None else filename_period}.bin"
        filename.write_bytes(header + b"".join(RECORD.pack(*row) for row in rows) + extra)
        return filename

    def call(self, field, dates=None, packed=None, keys=None, callback=None):
        dates = [self.previous_date, self.last_date] if dates is None else dates
        packed = [10000+self.previous_time, 10000+self.last_time] if packed is None else packed
        keys = [1600000] * len(dates) if keys is None else keys
        self.assertEqual(len(dates), len(packed))
        self.assertEqual(len(dates), len(keys))
        n = len(dates)
        array = ct.c_float * n
        out, a, b, c = array(*([-999] * n)), array(*dates), array(*packed), array(*keys)
        if callback is None:
            self.bridge.CZSC_BridgeRead(field, n, out, a, b, c)
        else:
            callback(n, out, a, b, c)
        return list(out)

    def assert_no_alarm(self):
        for field in (5, 6, 7):
            with self.subTest(field=field):
                self.assertEqual(self.call(field), [0.0, 0.0])

    def test_binary_contract_sizes_and_real_registration_table(self):
        self.assertEqual(HEADER.size, 40)
        self.assertEqual(RECORD.size, 32)
        self.assertEqual(ct.sizeof(FunctionInfo), 2 + ct.sizeof(ct.c_void_p))
        functions = ct.POINTER(FunctionInfo)()
        self.assertEqual(self.bridge.RegisterTdxFunc(ct.byref(functions)), 1)
        self.assertEqual([functions[i].id for i in range(32)], list(range(1, 32)) + [0])
        self.assertTrue(all(bool(functions[i].function) for i in range(31)))
        self.assertFalse(bool(functions[31].function))
        self.assertEqual(self.bridge.RegisterTdxFunc(ct.byref(functions)), 0)
        self.assertEqual(self.bridge.RegisterTdxFunc(None), 0)

    def test_registered_callbacks_match_direct_fields(self):
        self.write()
        functions = ct.POINTER(FunctionInfo)()
        self.assertEqual(self.bridge.RegisterTdxFunc(ct.byref(functions)), 1)
        for index in range(31):
            with self.subTest(field=index+1):
                self.assertEqual(self.call(index+1, callback=functions[index].function), self.call(index+1))

    def test_price_structure_and_causal_markers_align_to_date_time(self):
        self.write()
        self.assertEqual(self.call(1), [9.5, 11.5])
        self.assertEqual(self.call(2), [-1.0, 1.0])
        self.assertEqual(self.call(3), [10.5, 10.5])
        self.assertEqual(self.call(4), [9.5, 9.5])
        self.assertEqual(self.call(8), [10.0, 11.0])
        self.assertEqual(self.call(9), [0.0, 1.0])
        self.assertEqual(self.call(10), [1.0, 0.0])
        # No interpolation or backward filling of missing candle timestamps.
        self.assertEqual(self.call(8, dates=[self.last_date], packed=[10000+1], keys=[1600000]), [0.0])
        self.assertEqual(self.call(8, dates=[self.last_date-10000], packed=[10000+self.last_time], keys=[1600000]), [0.0])

    def test_live_alert_fields_only_expose_last_fresh_record(self):
        self.write()
        self.assertEqual(self.call(5), [0.0, 1.0])
        self.assertEqual(self.call(6), [0.0, 0.0])
        self.assertEqual(self.call(7), [0.0, 1.0])
        rows = [self.rows[0], (*self.rows[1][:-1], 2)]
        self.write(rows=rows)
        self.assertEqual(self.call(5), [0.0, 0.0])
        self.assertEqual(self.call(6), [0.0, 1.0])

    def test_old_cache_keeps_drawing_but_cannot_alarm(self):
        self.write(generated=self.now-100)
        self.assert_no_alarm()
        self.assertEqual(self.call(1), [9.5, 11.5])
        self.assertEqual(self.call(9), [0.0, 1.0])
        self.assertEqual(self.call(10), [1.0, 0.0])

    def test_old_source_close_cannot_be_renewed_by_fresh_generation(self):
        self.previous_date, self.previous_time = tdx_clock(self.last_end-1500)
        self.last_date, self.last_time = tdx_clock(self.last_end-1200)
        rows = [(self.previous_date, self.previous_time, *self.rows[0][2:]),
                (self.last_date, self.last_time, *self.rows[1][2:])]
        self.write(rows=rows, newest=self.last_end-1200)
        self.assert_no_alarm()
        self.assertEqual(self.call(8), [10.0, 11.0])

    def test_future_header_times_fail_closed_for_alarms(self):
        for kwargs in ({"generated": self.now+1000}, {"newest": self.now+1000}):
            with self.subTest(**kwargs):
                self.write(**kwargs)
                self.assert_no_alarm()

    def test_same_numeric_stock_code_in_shanghai_and_shenzhen_never_crosses(self):
        self.write(key=1000001)
        other = [(*row[:2], row[2]+100, *row[3:]) for row in self.rows]
        self.write(key=1, rows=other)
        self.assertEqual(self.call(8, keys=[1000001, 1000001]), [10.0, 11.0])
        self.assertEqual(self.call(8, keys=[1, 1]), [110.0, 111.0])
        self.assertEqual(self.call(8, keys=[2000001, 2000001]), [0.0, 0.0])

    def test_period_is_part_of_lookup_and_mixed_array_rows_are_rejected(self):
        self.write()
        self.write(period=3, rows=[(*r[:2], r[2]+20, *r[3:]) for r in self.rows])
        self.assertEqual(self.call(8), [10.0, 11.0])
        self.assertEqual(self.call(8, packed=[30000+self.previous_time, 30000+self.last_time]), [30.0, 31.0])
        self.assertEqual(self.call(8, packed=[30000+self.previous_time, 10000+self.last_time]), [0.0, 11.0])
        self.assertEqual(self.call(8, keys=[600000, 1600000]), [0.0, 11.0])

    def test_daily_input_time_is_normalized_to_zero(self):
        close = datetime.fromtimestamp(self.now, SHANGHAI).replace(hour=15, minute=0, second=0, microsecond=0)
        if close.timestamp() > self.now:
            close -= timedelta(days=1)
        newest = int(close.timestamp())
        previous, _ = tdx_clock(newest-86400)
        last, _ = tdx_clock(newest)
        rows = [(previous, 0, 10.0, 9.5, -1.0, 10.5, 9.5, 0),
                (last, 0, 11.0, 11.5, 1.0, 10.5, 9.5, 1)]
        self.write(period=5, rows=rows, newest=newest)
        self.assertEqual(self.call(8, dates=[previous, last], packed=[50000+935, 50000+1500]), [10.0, 11.0])
        expected_alarm = float(self.now-newest <= 90)
        self.assertEqual(self.call(5, dates=[previous, last], packed=[50000, 50000]), [0.0, expected_alarm])
        self.write(period=5, rows=[(*row[:1], 1500, *row[2:]) for row in rows], newest=newest)
        self.assertEqual(self.call(8, dates=[previous, last], packed=[50000, 50000]), [0.0, 0.0])

    def test_calendar_and_header_last_record_consistency_fail_closed(self):
        for bad_date in (1260230, 1261301, 1260001, 1261100, 690101, 3000101):
            with self.subTest(date=bad_date):
                rows = [self.rows[0], (bad_date, *self.rows[1][1:])]
                self.write(rows=rows)
                self.assertEqual(self.call(8), [0.0, 0.0])
                self.assert_no_alarm()
        self.write(newest=self.last_end+60)
        self.assertEqual(self.call(8), [0.0, 0.0])
        self.assert_no_alarm()

    def test_missing_short_trailing_and_header_count_corruption_fail_closed(self):
        self.assertEqual(self.call(8), [0.0, 0.0])
        cases = [dict(magic=b"BADMAGIC"), dict(version=2), dict(count=3), dict(count=0),
                 dict(extra=b"x"), dict(key=1600001, filename_key=1600000),
                 dict(period=3, filename_period=1)]
        for kwargs in cases:
            with self.subTest(**kwargs):
                self.write(**kwargs)
                for field in range(1, 11): self.assertEqual(self.call(field), [0.0, 0.0])
        path = self.path / "1600000_1.bin"
        for length in (0, 1, 39, 40, 71):
            with self.subTest(length=length):
                path.write_bytes(b"x"*length)
                self.assertEqual(self.call(8), [0.0, 0.0])

    def test_corrupt_record_values_and_ordering_fail_closed(self):
        changes = [(2, float("nan")), (2, -1), (3, float("inf")), (3, -1),
                   (4, 2), (5, 9), (6, 12), (7, 3), (1, 2360), (0, 0)]
        for column, bad in changes:
            with self.subTest(column=column, bad=bad):
                row = list(self.rows[-1]); row[column] = bad
                self.write(rows=[self.rows[0], tuple(row)])
                self.assertEqual(self.call(8), [0.0, 0.0])
        for rows in (list(reversed(self.rows)), [self.rows[0], self.rows[0]]):
            self.write(rows=rows)
            self.assertEqual(self.call(8), [0.0, 0.0])

    def test_invalid_float_inputs_unknown_fields_and_null_arrays_are_safe(self):
        self.write()
        for bad in (float("nan"), float("inf"), -1.0, 1600000.5, 4000000):
            with self.subTest(key=bad):
                self.assertEqual(self.call(8, keys=[bad, bad]), [0.0, 0.0])
        for packed in (0, 20000+self.last_time, 10000.5, float("nan")):
            self.assertEqual(self.call(8, packed=[packed, packed]), [0.0, 0.0])
        self.assertEqual(self.call(11), [0.0, 0.0])
        out = (ct.c_float*2)(-999, -999)
        self.bridge.CZSC_BridgeRead(8, 2, out, None, None, None)
        self.assertEqual(list(out), [0.0, 0.0])
        self.bridge.CZSC_BridgeRead(8, 0, None, None, None, None)


if __name__ == "__main__":
    unittest.main()
